package com.particlesdevs.photoncamera.processing.processor;

import android.graphics.Bitmap;
import android.graphics.Point;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CaptureResult;

import com.particlesdevs.photoncamera.api.ParseExif;
import com.particlesdevs.photoncamera.capture.CaptureController;
import com.particlesdevs.photoncamera.control.GyroBurst;
import com.particlesdevs.photoncamera.processing.ImageFrame;
import com.particlesdevs.photoncamera.processing.ImagePath;
import com.particlesdevs.photoncamera.processing.ImageSaver;
import com.particlesdevs.photoncamera.processing.IrisNightBatch;
import com.particlesdevs.photoncamera.processing.ProcessingEventsListener;
import com.particlesdevs.photoncamera.processing.opengl.postpipeline.PostPipeline;
import com.particlesdevs.photoncamera.processing.render.Parameters;
import com.particlesdevs.photoncamera.util.Allocator;
import com.particlesdevs.photoncamera.util.Log;

import java.nio.ByteBuffer;
import java.nio.file.Path;
import java.util.ArrayList;

/**
 * IRIS_26540_NIGHT_PROCESSOR_SOLE_OWNER
 *
 * Standalone Night processor. It never enters DefaultSaver, HdrxProcessor.Run(),
 * Camera2ApiAutoFix.ApplyRes(), Parameters.FillDynamicParameters(), Photon NoiseModeler,
 * or the legacy Photon Night graph. The immutable IrisNightBatch is the complete authority.
 */
public final class IrisNightProcessor {
    private static final String TAG = "IrisNightProcessor";

    private IrisNightProcessor() {}

    public static void process(IrisNightBatch batch,
                               ProcessingEventsListener listener) {
        final long startNs = System.nanoTime();
        CaptureController.isProcessing = true;
        listener.onProcessingStarted("Iris Night");
        try {
            if (batch == null || batch.characteristics == null || batch.frames.size() < 2) {
                throw new IllegalStateException("26540 Iris Night requires immutable Camera2 batch");
            }
            final CameraCharacteristics characteristics = batch.characteristics;
            final ArrayList<ImageFrame> images = new ArrayList<>(batch.frames);
            images.sort(java.util.Comparator.comparingLong(ImageFrame::getTimestamp));
            final ImageFrame base = images.stream()
                    .filter(f -> f.motionV2FrameRole == ImageFrame.MotionV2FrameRole.NORMAL)
                    .findFirst()
                    .orElseThrow(() -> new IllegalStateException("26541 Night SHORT reference missing"));
            final int width = base.motionV2PlaneLogicalWidth;
            final int height = base.motionV2PlaneLogicalHeight;
            if (width <= 0 || height <= 0) {
                throw new IllegalStateException("26540 Night logical RAW geometry invalid " + width + "x" + height);
            }
            for (int i = 0; i < images.size(); i++) {
                ImageFrame frame = images.get(i);
                if (!frame.motionV2PlaneLayoutValid
                        || frame.motionV2PlaneLogicalWidth != width
                        || frame.motionV2PlaneLogicalHeight != height
                        || frame.irisNightExactCaptureResult == null
                        || frame.irisNightExactCaptureRequest == null
                        || frame.motionV2ResultSensorTimestampNs != frame.timestamp
                        || frame.motionV2ActualExposureNs <= 0L
                        || frame.motionV2ActualIso <= 0
                        || !frame.motionV2NoiseProfileValid
                        || !frame.motionV2BlackLevelValid
                        || !frame.motionV2WhiteLevelValid) {
                    throw new IllegalStateException("26540 Night immutable frame contract failed index=" + i);
                }
                frame.number = i;
                frame.pair = null;
                frame.irisRelativeExposureMpy = (float) (
                        base.motionV2ExposureEnergy / Math.max(1.0e-12, frame.motionV2ExposureEnergy));
                if (!Float.isFinite(frame.irisRelativeExposureMpy) || frame.irisRelativeExposureMpy <= 0.0f)
                    throw new IllegalStateException("26541 Night relative exposure invalid index=" + i);
                if (!batch.gyro.isEmpty()) {
                    frame.frameGyro = batch.gyro.get(i % batch.gyro.size());
                }
            }

            final Parameters p = new Parameters();
            p.FillIrisNightParameters(characteristics, batch.referenceResult,
                    batch.referenceRequest, new Point(width, height), batch);
            p.cameraRotation = batch.rotation;
            p.motionV2WronskiNoiseS = base.motionV2NoiseS;
            p.motionV2WronskiNoiseO = base.motionV2NoiseO;
            p.motionV2StrictWronskiSensorValid = true;
            p.motionV2GlobalZoom = 1.0f;
            p.motionV2OpticalZoomAnchor = 1.0f;
            p.motionV2OutputZoom = 1.0f;
            p.motionV2SpatialReconstructionZoom = 1.0f;
            p.motionV2RenderResidualZoom = 1.0f;
            p.motionV2SuperResOutputEnabled = batch.superResEnabled;
            p.motionV2SuperResOutputScale = batch.superResEnabled ? 2.0f : 1.0f;

            final Path dngFile = ImagePath.newDNGFilePath();
            final Path imageFile = ImagePath.newImageFilePath();
            final ParseExif.ExifData exif = ParseExif.parse(batch.referenceResult, batch.referenceRequest);
            final long ref = base.getTimestamp();
            Log.i(TAG, "IRIS_26541_NIGHT_12_PLUS_3_DIRECT_PROCESS_ENTRY frames=" + images.size()
                    + " shortActual=" + batch.shortFrameCount + " longActual=" + batch.longFrameCount
                    + " shortRequested=" + batch.requestedShortFrames + " longRequested=" + batch.requestedLongFrames
                    + " frameBudget=" + batch.frameBudget + " exactReferenceTimestamp=" + ref
                    + " referenceRole=SHORT zsl=false motionRing=false preShutterRaw=false"
                    + " staticImageBuffer=false defaultSaver=false hdrxRun=false"
                    + " applyRes=false fillDynamic=false photonNoiseModeler=false"
                    + " superRes=" + batch.superResEnabled);

            final long mergeStartNs = System.nanoTime();
            final MotionV2Merger.Result r = PhotonMotionMgc1271Bridge.reconstruct(
                    new Point(width, height), images, ref, p, null, batch.saveRaw >= 1);
            final long mergeMs = (System.nanoTime() - mergeStartNs) / 1_000_000L;
            if (r == null || r.raw == null) {
                throw new IllegalStateException("26540 Night Spatial RGB carrier missing");
            }
            if (r.inputFrames < images.size()) {
                throw new IllegalStateException("26540 Night MGC scheduled-frame mismatch scheduled="
                        + r.inputFrames + " expectedAtLeast=" + images.size());
            }
            ByteBuffer rgb = r.raw;
            rgb.position(0);
            final long expectedRgbBytes = (long) width * (long) height * 4L * 2L;
            if (rgb.capacity() < expectedRgbBytes) {
                throw new IllegalStateException("26540 Night RGB carrier too small bytes="
                        + rgb.capacity() + " expectedAtLeast=" + expectedRgbBytes);
            }
            if (r.stackedDngRaw16 != null && rgb == r.stackedDngRaw16) {
                throw new IllegalStateException("26540 Night RGB carrier aliases DNG sidecar");
            }
            p.motionV2EffectiveSupport = r.effectiveSupport;

            if (batch.saveRaw >= 1) {
                boolean rawSaved = false;
                try {
                    if (p.motionV2SuperResOutputEnabled && r.superResLinearRawPath != null
                            && r.superResLinearRawWidth > 0 && r.superResLinearRawHeight > 0) {
                        rawSaved = com.particlesdevs.photoncamera.processing.IrisMotionSuperResDngWriter.write(
                                dngFile, java.nio.file.Paths.get(r.superResLinearRawPath),
                                r.superResLinearRawWidth, r.superResLinearRawHeight, p,
                                r.dngNoiseProfile, r.dngStackFrames, r.dngSupportMin, r.dngSupportP01,
                                r.dngSupportP10, r.dngSupportMedian, r.dngSupportMean, r.dngSupportMax,
                                r.dngNoiseEquivalentSupport);
                    } else {
                        if (r.stackedDngRaw16 == null) {
                            throw new IllegalStateException("26540 Night normalized16 DNG sidecar missing");
                        }
                        ByteBuffer dngBayer = r.stackedDngRaw16;
                        dngBayer.position(0);
                        rawSaved = ImageSaver.Util.saveNormalized16StackedRaw(
                                dngFile, dngBayer, p, r.dngNoiseProfile, r.dngStackFrames,
                                r.dngSupportMin, r.dngSupportP01, r.dngSupportP10,
                                r.dngSupportMedian, r.dngSupportMean, r.dngSupportMax,
                                r.dngNoiseEquivalentSupport);
                    }
                } catch (Throwable rawFailure) {
                    Log.e(TAG, "IRIS_26540_NIGHT_DNG_SAVE_FAILED_CONTINUE_JPEG", rawFailure);
                } finally {
                    if (r.stackedDngRaw16 != null) {
                        try { Allocator.free(r.stackedDngRaw16); } catch (Throwable ignored) {}
                    }
                    if (r.superResLinearRawPath != null) {
                        try { java.nio.file.Files.deleteIfExists(java.nio.file.Paths.get(r.superResLinearRawPath)); }
                        catch (Throwable ignored) {}
                    }
                }
                listener.notifyImageSavedStatus(rawSaved, dngFile);
            }

            exif.IMAGE_DESCRIPTION = p.toString()
                    + "\nIRIS_26541_NIGHT_12_PLUS_3 irisCaptureOwner=true exactTimestampMetadata=true"
                    + " shortFrames=" + batch.shortFrameCount + "/" + batch.requestedShortFrames
                    + " longFrames=" + batch.longFrameCount + "/" + batch.requestedLongFrames
                    + " referenceRole=SHORT zsl=false motionRing=false preShutterRaw=false"
                    + " photonNight=false staticImageBuffer=false defaultSaver=false hdrxRun=false"
                    + " applyRes=false photonNoiseModeler=false liveTunableInjection=false"
                    + " mgcSpatialRgb=true pecanProfileSnr=referencePreMerge"
                    + " denoiseMagnitude=propagatedResidual readShotCorrelationStrength=true"
                    + " isoDenoiseAuthority=false darknessDenoiseAuthority=false"
                    + " autoLowLightLumaFloor=false ultraHdr=false superRes="
                    + p.motionV2SuperResOutputEnabled;

            final PostPipeline pipeline = new PostPipeline(true);
            final long postStartNs = System.nanoTime();
            Log.i(TAG, "IRIS_26543_NIGHT_POST_RGB_BEGIN dngStageComplete=true");
            final Point crop;
            Bitmap img;
            try {
                img = pipeline.RunIrisNightRgb(rgb, p);
                crop = pipeline.cropSize == null ? new Point(p.rawSize) : new Point(pipeline.cropSize);
                Log.i(TAG, "IRIS_26543_NIGHT_POST_RGB_COMPLETE bitmap="
                        + (img == null ? "null" : (img.getWidth() + "x" + img.getHeight())));
            } finally {
                try { Allocator.free(rgb); } catch (Throwable ignored) {}
            }
            Log.i(TAG, "IRIS_26540_NIGHT_RGBA16F_RELEASED_BEFORE_JIN bytes=" + expectedRgbBytes);
            if (android.os.Build.VERSION.SDK_INT >= 34 && img != null
                    && !img.isRecycled() && img.hasGainmap()) {
                throw new IllegalStateException("26540 Night pre-Jin UltraHDR is forbidden");
            }

            final String srDetailPath = r.superResDetailPath;
            final int srDetailWidth = r.superResDetailWidth;
            final int srDetailHeight = r.superResDetailHeight;
            Log.i(TAG, "IRIS_26543_NIGHT_BASE_JPEG_BEGIN");
            final boolean baseSaved = ImageSaver.Util.saveBitmapAsJPGIrisNightCheckpoint(
                    imageFile, img, ImageSaver.JPG_QUALITY, exif);
            Log.i(TAG, "IRIS_26543_NIGHT_BASE_JPEG_COMPLETE saved=" + baseSaved);
            if (baseSaved) listener.notifyImageSavedStatus(true, imageFile);
            else Log.w(TAG, "IRIS_26540_NIGHT_BASE_CHECKPOINT_FAILED continueFinalAttempt=true");

            img = IrisNightNeuralEnhancer.enhanceInPlace(img);
            final long postPlusJinMs = (System.nanoTime() - postStartNs) / 1_000_000L;
            final boolean finalSaved = ImageSaver.Util.saveBitmapAsJPGIrisNightAtomicFinal(
                    imageFile, img, ImageSaver.JPG_QUALITY, exif,
                    srDetailPath, srDetailWidth, srDetailHeight, p, crop);
            final boolean imageSaved = finalSaved || baseSaved;
            if (finalSaved || !baseSaved) listener.notifyImageSavedStatus(imageSaved, imageFile);
            if (srDetailPath != null) {
                try { java.nio.file.Files.deleteIfExists(java.nio.file.Paths.get(srDetailPath)); }
                catch (Throwable ignored) {}
            }
            Log.i(TAG, "IRIS_26540_NIGHT_PUBLICATION_OWNERSHIP baseSaved=" + baseSaved
                    + " finalSaved=" + finalSaved + " imageSaved=" + imageSaved
                    + " jinOptional=true baseSurvivesJinFailure=true ultraHdr=false"
                    + " mergeMs=" + mergeMs + " postPlusJinMs=" + postPlusJinMs
                    + " totalMs=" + ((System.nanoTime() - startNs) / 1_000_000L));
            listener.onProcessingFinished("Iris Night Processing Finished");
        } catch (Throwable failure) {
            Log.e(TAG, "IRIS_26540_NIGHT_PROCESS_FAILED", failure);
            listener.onProcessingError(failure.getClass().getSimpleName() + ": "
                    + String.valueOf(failure.getMessage()));
        } finally {
            if (batch != null && batch.frames != null) {
                for (ImageFrame frame : batch.frames) {
                    if (frame != null) try { frame.close(); } catch (Throwable ignored) {}
                }
            }
            CaptureController.isProcessing = false;
        }
    }


}
