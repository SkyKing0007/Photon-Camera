#define LAYOUT //
LAYOUT
precision highp float;
precision highp image2D;
precision highp usampler2D;
uniform highp usampler2D rawTexture;
layout(rgba32f,binding=0) uniform highp writeonly image2D outputCov;
uniform ivec2 rawSize;
uniform ivec2 rawHalf;
uniform ivec2 guideSize;
uniform int cfaPattern;
uniform vec4 blackLevel;
uniform float whiteLevel;
uniform float exposureScale;
uniform float wbR;
uniform float wbB;
uniform float noiseS;
uniform float noiseO;
uniform float kDetail;
uniform float kDenoise;
uniform float Dth;
uniform float Dtr;
uniform float kStretch;
uniform float kShrink;

int phaseIndex(ivec2 p){return ((p.y&1)<<1)|(p.x&1);}
int colorFromPhase(int phase){if(cfaPattern==0){if(phase==0)return 0;if(phase==3)return 2;return 1;}if(cfaPattern==1){if(phase==1)return 0;if(phase==2)return 2;return 1;}if(cfaPattern==2){if(phase==2)return 0;if(phase==1)return 2;return 1;}if(phase==3)return 0;if(phase==0)return 2;return 1;}
float wbForColor(int color){return color==0?wbR:(color==2?wbB:1.0);}
int clampPhase(int value,int extent){int phase=value&1;if(phase>=extent)return extent-1;int last=phase+2*((extent-1-phase)/2);return clamp(value,phase,last);}
ivec2 phaseClamp(ivec2 p){return ivec2(clampPhase(p.x,rawSize.x),clampPhase(p.y,rawSize.y));}
float nativeCalculationSample(ivec2 p){p=phaseClamp(p);int phase=phaseIndex(p);float rawValue=float(texelFetch(rawTexture,p,0).r);float black=blackLevel[phase];float sensor=max(rawValue-black,0.0)/max(whiteLevel-black,1.0);return sensor*exposureScale*wbForColor(colorFromPhase(phase));}
vec4 qAt(ivec2 q){ivec2 p=clamp(q*2,ivec2(0),rawSize-ivec2(2));return vec4(nativeCalculationSample(p),nativeCalculationSample(p+ivec2(1,0)),nativeCalculationSample(p+ivec2(0,1)),nativeCalculationSample(p+ivec2(1,1)));}

/* IRIS_26542_IPOL_FIGURE7_ACTIVE_KERNEL
 * Direct public Wronski/IPOL kernel-selection law, evaluated from the current native RAW owner:
 * GAT -> 2x2 Bayer-quad grey -> published gradients -> 2x2 structure tensor -> linear A/D law
 * with k_stretch=4 and k_shrink=2 supplied by the host. The published implementation produces
 * covariance; current Spatial-RGB consumes precision, so the final 2x2 matrix is explicitly inverted.
 * This changes only reconstruction-kernel geometry. Alignment, robustness/rejection and semantic
 * G/R-G/B-G accumulation remain owned by the existing 26541 graph.
 */
float vst(float x){
    float a=max(noiseS,1.0e-7);
    float b=max(noiseO,0.0);
    float q=max(a*x+0.375*a*a+b,0.0);
    return 2.0/a*sqrt(q);
}
float greyVst(ivec2 p){
    p=clamp(p,ivec2(0),rawHalf-ivec2(1));
    vec4 v=qAt(p);
    return 0.25*(vst(v.r)+vst(v.g)+vst(v.b)+vst(v.a));
}
vec2 publicGrad(ivec2 p){
    float g00=greyVst(p);
    float g01=greyVst(p+ivec2(1,0));
    float g10=greyVst(p+ivec2(0,1));
    float g11=greyVst(p+ivec2(1,1));
    return vec2(
        0.25*(-g00+g01-g10+g11),
        0.25*(-g00-g01+g10+g11));
}
void main(){
    ivec2 p=ivec2(gl_GlobalInvocationID.xy);
    if(any(greaterThanEqual(p,guideSize)))return;

    float jxx=0.0,jxy=0.0,jyy=0.0;
    for(int iy=0;iy<2;iy++)for(int ix=0;ix<2;ix++){
        ivec2 q=p-ivec2(1)+ivec2(ix,iy);
        if(q.x<0||q.y<0||q.x>=rawHalf.x-1||q.y>=rawHalf.y-1)continue;
        vec2 g=publicGrad(q);
        jxx+=g.x*g.x;
        jxy+=g.x*g.y;
        jyy+=g.y*g.y;
    }

    float tr=jxx+jyy;
    float disc=sqrt(max((jxx-jyy)*(jxx-jyy)+4.0*jxy*jxy,0.0));
    float l1=max(0.5*(tr+disc),0.0);
    float l2=max(0.5*(tr-disc),0.0);
    vec2 va=vec2(jxy,l1-jxx);
    vec2 vb=vec2(l1-jyy,jxy);
    float na=dot(va,va),nb=dot(vb,vb);
    vec2 e1;
    if(max(na,nb)>1.0e-20)e1=normalize(na>=nb?va:vb);
    else e1=jxx>=jyy?vec2(1.0,0.0):vec2(0.0,1.0);
    vec2 e2=vec2(-e1.y,e1.x);

    float A=1.0+sqrt(max((l1-l2)/max(l1+l2,1.0e-20),0.0));
    float D=clamp(1.0-sqrt(max(l1,0.0))/max(Dtr,1.0e-8)+Dth,0.0,1.0);
    float sk1=1.0+0.5*A*(1.0/max(kShrink,1.0e-8)-1.0);
    float sk2=1.0+0.5*A*(kStretch-1.0);
    float k1=max(kDetail*((1.0-D)*sk1+D*kDenoise),1.0e-5);
    float k2=max(kDetail*((1.0-D)*sk2+D*kDenoise),1.0e-5);
    float k1s=k1*k1,k2s=k2*k2;

    float xx=k1s*e1.x*e1.x+k2s*e2.x*e2.x;
    float xy=k1s*e1.x*e1.y+k2s*e2.x*e2.y;
    float yy=k1s*e1.y*e1.y+k2s*e2.y*e2.y;
    float det=max(xx*yy-xy*xy,1.0e-12);
    mat2 P=mat2(yy,-xy,-xy,xx)/det;
    imageStore(outputCov,p,vec4(P[0][0],P[0][1],P[1][0],P[1][1]));
}
