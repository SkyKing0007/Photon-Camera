package com.particlesdevs.photoncamera.processing;

import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;

import com.particlesdevs.photoncamera.control.GyroBurst;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * IRIS_26540_NIGHT_IMMUTABLE_BATCH_OWNER
 *
 * One shutter-frozen Night capture. RAW copies, exact timestamp-matched Camera2 metadata,
 * gyro observations and every processing-affecting Night setting are frozen together before
 * processing starts. No Photon static IMAGE_BUFFER or live mode/settings read owns this batch.
 */
public final class IrisNightBatch {
    public final List<ImageFrame> frames;
    public final List<GyroBurst> gyro;
    public final Map<Long, Double> exposures;
    public final Map<Long, TotalCaptureResult> results;
    public final Map<Long, CaptureRequest> requests;
    public final TotalCaptureResult referenceResult;
    public final CaptureRequest referenceRequest;
    public final CameraCharacteristics characteristics;
    public final int imageFormat;
    public final int rotation;
    public final int frameBudget;
    public final int saveRaw;
    public final boolean superResEnabled;
    public final boolean aspect169;
    public final boolean energySaving;
    public final boolean watermarkEnabled;
    public final boolean binning;
    public final String cameraId;
    public final com.particlesdevs.photoncamera.processing.processor.IrisMotionSettings.Snapshot irisSettings;

    public IrisNightBatch(
            List<ImageFrame> frames,
            List<GyroBurst> gyro,
            Map<Long, Double> exposures,
            Map<Long, TotalCaptureResult> results,
            Map<Long, CaptureRequest> requests,
            CameraCharacteristics characteristics,
            int imageFormat,
            int rotation,
            int frameBudget,
            int saveRaw,
            boolean superResEnabled,
            boolean aspect169,
            boolean energySaving,
            boolean watermarkEnabled,
            boolean binning,
            String cameraId,
            com.particlesdevs.photoncamera.processing.processor.IrisMotionSettings.Snapshot irisSettings) {
        if (frames == null || frames.size() < 2) {
            throw new IllegalArgumentException("26540 NightBatch requires at least two RAW frames");
        }
        if (results == null || requests == null || characteristics == null) {
            throw new IllegalArgumentException("26540 NightBatch exact metadata/characteristics are required");
        }
        ArrayList<ImageFrame> ordered = new ArrayList<>(frames);
        ordered.sort(java.util.Comparator.comparingLong(ImageFrame::getTimestamp));
        HashMap<Long, Double> expoCopy = new HashMap<>();
        HashMap<Long, TotalCaptureResult> resultCopy = new HashMap<>();
        HashMap<Long, CaptureRequest> requestCopy = new HashMap<>();
        for (ImageFrame frame : ordered) {
            if (frame == null || !frame.motionV2PlaneLayoutValid) {
                throw new IllegalArgumentException("26540 NightBatch RAW layout missing");
            }
            TotalCaptureResult result = results.get(frame.timestamp);
            CaptureRequest request = requests.get(frame.timestamp);
            if (result == null || request == null) {
                throw new IllegalArgumentException(
                        "26540 NightBatch exact metadata missing timestamp=" + frame.timestamp);
            }
            Long resultTimestamp = result.get(android.hardware.camera2.CaptureResult.SENSOR_TIMESTAMP);
            if (resultTimestamp == null || resultTimestamp.longValue() != frame.timestamp) {
                throw new IllegalArgumentException(
                        "26540 NightBatch timestamp mismatch image=" + frame.timestamp
                                + " result=" + resultTimestamp);
            }
            if (frame.motionV2ActualExposureNs <= 0L || frame.motionV2ActualIso <= 0
                    || !frame.motionV2NoiseProfileValid || !frame.motionV2BlackLevelValid
                    || !frame.motionV2WhiteLevelValid) {
                throw new IllegalArgumentException(
                        "26540 NightBatch exact radiometric metadata missing timestamp=" + frame.timestamp);
            }
            expoCopy.put(frame.timestamp, frame.motionV2ExposureEnergy);
            resultCopy.put(frame.timestamp, result);
            requestCopy.put(frame.timestamp, request);
        }
        this.frames = Collections.unmodifiableList(ordered);
        this.gyro = Collections.unmodifiableList(new ArrayList<>(gyro == null
                ? Collections.emptyList() : gyro));
        this.exposures = Collections.unmodifiableMap(expoCopy);
        this.results = Collections.unmodifiableMap(resultCopy);
        this.requests = Collections.unmodifiableMap(requestCopy);
        ImageFrame reference = ordered.get(0);
        this.referenceResult = resultCopy.get(reference.timestamp);
        this.referenceRequest = requestCopy.get(reference.timestamp);
        this.characteristics = characteristics;
        this.imageFormat = imageFormat;
        this.rotation = rotation;
        this.frameBudget = frameBudget;
        this.saveRaw = saveRaw;
        this.superResEnabled = superResEnabled;
        this.aspect169 = aspect169;
        this.energySaving = energySaving;
        this.watermarkEnabled = watermarkEnabled;
        this.binning = binning;
        this.cameraId = cameraId == null ? "0" : cameraId;
        if (irisSettings == null || irisSettings.customNoiseModelEnabled) {
            throw new IllegalArgumentException("26540 NightBatch requires exact-Camera2 Iris settings");
        }
        this.irisSettings = irisSettings;
    }
}
