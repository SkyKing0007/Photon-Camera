package com.particlesdevs.photoncamera.processing.parameters;

import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.util.Range;

import com.particlesdevs.photoncamera.capture.CaptureController;
import com.particlesdevs.photoncamera.util.Log;

/** IRIS_26540_NIGHT_EXPOSURE_SOLE_OWNER
 * One equal-exposure Night plan is frozen once at shutter time from Camera2 sensor bounds,
 * shutter-time preview metering and gyro state. Photon IsoExpoSelector logic/state is not called.
 */
public final class IrisNightExposureSelector {
    private static final String TAG = "IrisNightExposure";
    public static final class Plan {
        public final long exposureNs;
        public final int iso;
        public final long exposureLowNs;
        public final long exposureHighNs;
        public final int isoLow;
        public final int isoHigh;
        public final int analogIso;
        public final boolean tripod;
        public final int shakiness;
        public final int antibandingMode;

        Plan(long exposureNs, int iso, long exposureLowNs, long exposureHighNs,
             int isoLow, int isoHigh, int analogIso, boolean tripod, int shakiness,
             int antibandingMode) {
            this.exposureNs = exposureNs;
            this.iso = iso;
            this.exposureLowNs = exposureLowNs;
            this.exposureHighNs = exposureHighNs;
            this.isoLow = isoLow;
            this.isoHigh = isoHigh;
            this.analogIso = analogIso;
            this.tripod = tripod;
            this.shakiness = shakiness;
            this.antibandingMode = antibandingMode;
        }
    }

    private IrisNightExposureSelector() {}

    private static long clamp(long v, long lo, long hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static long motionCap(boolean tripod, int shakiness, long sensorHigh) {
        if (tripod) return Math.min(sensorHigh, ExposureIndex.sec * 2L);
        if (shakiness <= 30) return Math.min(sensorHigh, ExposureIndex.sec / 4L);
        if (shakiness <= 70) return Math.min(sensorHigh, ExposureIndex.sec / 8L);
        if (shakiness <= 150) return Math.min(sensorHigh, ExposureIndex.sec / 15L);
        return Math.min(sensorHigh, ExposureIndex.sec / 30L);
    }

    private static long antiFlicker(long desired, long cap, int antibandingMode) {
        long q = antibandingMode == CaptureResult.CONTROL_AE_ANTIBANDING_MODE_50HZ
                ? ExposureIndex.sec / 100L : ExposureIndex.sec / 120L;
        desired = Math.min(desired, cap);
        if (desired < q) return desired;
        long n = Math.max(1L, Math.round((double) desired / q));
        while (n * q > cap && n > 1L) n--;
        return n * q;
    }

    public static Plan freezePlan(CaptureController controller,
                                  CameraCharacteristics characteristics,
                                  float exposureCompensationEv,
                                  boolean tripod,
                                  int shakiness,
                                  CaptureResult previewResult) {
        Range<Long> exposureRange = characteristics == null ? null
                : characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
        Range<Integer> isoRange = characteristics == null ? null
                : characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
        Integer analogObj = characteristics == null ? null
                : characteristics.get(CameraCharacteristics.SENSOR_MAX_ANALOG_SENSITIVITY);
        long exposureLow = exposureRange == null ? ExposureIndex.sec / 1000L : exposureRange.getLower();
        long exposureHigh = exposureRange == null ? ExposureIndex.sec : exposureRange.getUpper();
        int isoLow = isoRange == null ? 100 : isoRange.getLower();
        int isoHigh = isoRange == null ? 3200 : isoRange.getUpper();
        int analogIso = analogObj == null ? 100 : analogObj;
        Integer ab = previewResult == null ? null
                : previewResult.get(CaptureResult.CONTROL_AE_ANTIBANDING_MODE);
        int antibanding = ab == null ? CaptureResult.CONTROL_AE_ANTIBANDING_MODE_AUTO : ab;

        double compensation = Math.pow(2.0, exposureCompensationEv);
        // Preserve 26533's 0.70 EV highlight-protection target, but own it entirely in Iris.
        double meteredEnergy = Math.max(1.0,
                controller.mPreviewExposureTime * (double) Math.max(1, controller.mPreviewIso));
        double targetEnergy = meteredEnergy * compensation / Math.pow(2.0, 0.70);
        long cap = motionCap(tripod, Math.max(0, shakiness), exposureHigh);
        long desired = (long) Math.round(targetEnergy / Math.max(100, isoLow));
        long exposure = clamp(antiFlicker(clamp(desired, exposureLow, cap), cap, antibanding),
                exposureLow, exposureHigh);
        int iso = (int) Math.round(targetEnergy / Math.max(1.0, exposure));
        iso = Math.max(isoLow, Math.min(isoHigh, iso));

        double manualExposure = controller.getParamController().getCurrentExposureValue();
        double manualIso = controller.getParamController().getCurrentISOValue();
        if (manualExposure != 0.0) exposure = clamp((long) manualExposure, exposureLow, exposureHigh);
        if (manualIso != 0.0) iso = Math.max(isoLow, Math.min(isoHigh, (int) manualIso));

        Plan plan = new Plan(exposure, iso, exposureLow, exposureHigh, isoLow, isoHigh,
                analogIso, tripod, Math.max(0, shakiness), antibanding);
        String diagnostics = "IRIS_26540_NIGHT_EXPOSURE requestedNs=" + exposure
                + " iso=" + iso + " capNs=" + cap + " tripod=" + tripod
                + " shakiness=" + shakiness + " equalExposure=true"
                + " photonIsoExpoSelector=false planFrozenAtShutter=true";
        Log.i(TAG, diagnostics);
        return plan;
    }

    public static void applyPlan(CaptureRequest.Builder builder, Plan plan) {
        if (plan == null) throw new IllegalArgumentException("26540 Night exposure plan is null");
        builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF);
        builder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, plan.exposureNs);
        builder.set(CaptureRequest.SENSOR_SENSITIVITY, plan.iso);
    }
}
