package com.particlesdevs.photoncamera.processing.parameters;

/** IRIS_26540_NIGHT_FRAME_BUDGET_OWNER
 * Night frame count is the user-requested temporal stacking budget. ISO and scene darkness do not
 * increase/decrease it. Alignment/rejection and spatial confidence decide local effective support.
 */
public final class IrisNightFrameSelector {
    private IrisNightFrameSelector() {}
    public static int getFrames(int requestedMaximum) {
        return Math.max(2, Math.min(35, requestedMaximum));
    }
}
