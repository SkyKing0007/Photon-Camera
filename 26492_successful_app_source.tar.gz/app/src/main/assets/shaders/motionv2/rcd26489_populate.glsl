#define LAYOUT //
LAYOUT
precision highp float;
precision highp int;
precision highp sampler2D;

uniform highp sampler2D InputBayer;
uniform highp sampler2D HighlightProvenance;
uniform highp sampler2D LensShadingMap;
layout(std430, binding = 0) buffer CfaBuf {
    float cfa[];
};
layout(std430, binding = 1) buffer RedBuf {
    float red[];
};
layout(std430, binding = 2) buffer GreenBuf {
    float green[];
};
layout(std430, binding = 3) buffer BlueBuf {
    float blue[];
};
uniform ivec2 rawSize;
uniform ivec2 bandSize;
uniform int bandOriginY;
uniform int cfaPattern;
uniform vec3 calculationWb;
uniform vec3 sensorGains;
uniform float sensorClipLevel;
uniform float highlightThreshold;
uniform float highlightCeiling;
uniform int useLensShading;

const float PROVENANCE_NORMAL = 0.0;
const float PROVENANCE_CENSORED = 1.0;
const float PROVENANCE_SHORT_VALIDATED = 2.0;

int phaseAt(ivec2 p) { return (p.x & 1) | ((p.y & 1) << 1); }
int colorAt(ivec2 p) {
    int q = phaseAt(p);
    if (cfaPattern == 0) return q == 0 ? 0 : (q == 3 ? 2 : 1);
    if (cfaPattern == 1) return q == 1 ? 0 : (q == 2 ? 2 : 1);
    if (cfaPattern == 2) return q == 2 ? 0 : (q == 1 ? 2 : 1);
    return q == 3 ? 0 : (q == 0 ? 2 : 1);
}
ivec2 clampGlobal(ivec2 p) { return clamp(p, ivec2(0), rawSize - ivec2(1)); }
float provenanceAt(ivec2 p) {
    return texelFetch(HighlightProvenance, clampGlobal(p) >> 1, 0).r;
}
float fusedAt(ivec2 p) {
    p = clampGlobal(p);
    vec4 v = texelFetch(InputBayer, p >> 1, 0);
    int q = phaseAt(p);
    return q == 0 ? v.r : (q == 1 ? v.g : (q == 2 ? v.b : v.a));
}
vec3 shadingRgb(ivec2 p) {
    if (useLensShading == 0) return vec3(1.0);
    vec2 uv = (vec2(clampGlobal(p)) + vec2(0.5)) / vec2(rawSize);
    vec4 g = texture(LensShadingMap, clamp(uv, vec2(0.0), vec2(1.0)));
    return max(vec3(g.r, 0.5 * (g.g + g.b), g.a), vec3(0.0));
}
float wbForColor(int col) {
    return col == 0 ? calculationWb.r : (col == 2 ? calculationWb.b : calculationWb.g);
}
float gainForColor(int col) {
    return col == 0 ? sensorGains.r : (col == 2 ? sensorGains.b : sensorGains.g);
}
float rawCalculationAt(ivec2 p) {
    p = clampGlobal(p);
    int col = colorAt(p);
    vec3 lsc = shadingRgb(p);
    return clamp(fusedAt(p) * lsc[col] * max(wbForColor(col), 1.0e-6),
            0.0, highlightCeiling);
}
float rawBalancedAt(ivec2 p) {
    int col = colorAt(clampGlobal(p));
    return rawCalculationAt(p) * gainForColor(col) /
            max(wbForColor(col), 1.0e-6);
}

/* IRIS_26492_CENSORED_PACKED_NEUTRAL_LOWER_BOUND
 * CENSORED does not mean black/zero: retain the strongest physical lower-bound
 * brightness in a common balanced domain, then map that same scalar back to each
 * CFA color. This preserves brightness while refusing to invent clipped chroma.
 */
float censoredNeutralBalanced(ivec2 p) {
    ivec2 origin = (clampGlobal(p) >> 1) << 1;
    float lowerBound = 0.0;
    for (int py = 0; py < 2; ++py) {
        for (int px = 0; px < 2; ++px) {
            ivec2 q = clampGlobal(origin + ivec2(px, py));
            lowerBound = max(lowerBound, rawBalancedAt(q));
        }
    }
    return lowerBound;
}

float provenanceCalculationAt(ivec2 p) {
    int col = colorAt(clampGlobal(p));
    float measured = rawCalculationAt(p);
    float state = provenanceAt(p);
    if (abs(state - PROVENANCE_CENSORED) > 0.25) return measured;
    float neutralBalanced = censoredNeutralBalanced(p);
    float neutralCalculation = neutralBalanced * wbForColor(col) /
            max(gainForColor(col), 1.0e-6);
    return min(max(neutralCalculation, 0.0), highlightCeiling);
}

/* IRIS_26492_RCD_PROVENANCE_CONSUMER_ONLY
 * RCD consumes the upstream measurement state. It is forbidden to promote a
 * CENSORED observation because a numerical CFA value happens to exceed 1.0.
 * NORMAL and SHORT_VALIDATED both remain measured radiance and pass unchanged.
 */
void main() {
    ivec2 lp = ivec2(gl_GlobalInvocationID.xy);
    if (any(greaterThanEqual(lp, bandSize))) return;
    ivec2 gp = ivec2(lp.x, bandOriginY + lp.y);
    int idx = lp.y * bandSize.x + lp.x;
    int col = colorAt(gp);
    float value = provenanceCalculationAt(gp);
    cfa[idx] = value;
    red[idx] = col == 0 ? value : 0.0;
    green[idx] = col == 1 ? value : 0.0;
    blue[idx] = col == 2 ? value : 0.0;
}
