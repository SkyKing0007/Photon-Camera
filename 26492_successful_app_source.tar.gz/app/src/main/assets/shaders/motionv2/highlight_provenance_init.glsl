#define LAYOUT //
LAYOUT
precision highp float;
precision highp int;
precision highp sampler2D;
precision highp image2D;

uniform highp sampler2D normalCfa;
layout(r32f, binding = 0) uniform highp writeonly image2D outProvenance;
uniform ivec2 packedSize;
uniform float referenceExposureScale;
uniform float physicalClipThreshold;

float max4(vec4 v) { return max(max(v.r, v.g), max(v.b, v.a)); }

/* IRIS_26492_EXPLICIT_HIGHLIGHT_PROVENANCE_INIT
 * 0 = NORMAL_MEASURED
 * 1 = CENSORED_UNKNOWN_CHROMA
 * 2 = SHORT_VALIDATED (written only by the short-validation stage)
 */
void main() {
    ivec2 p = ivec2(gl_GlobalInvocationID.xy);
    if (any(greaterThanEqual(p, packedSize))) return;
    vec4 normal = texelFetch(normalCfa, p, 0);
    vec4 sensor = normal / max(referenceExposureScale, 1.0e-6);
    float state = max4(sensor) >= physicalClipThreshold ? 1.0 : 0.0;
    imageStore(outProvenance, p, vec4(state, 0.0, 0.0, 0.0));
}
