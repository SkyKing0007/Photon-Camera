precision highp float;
precision mediump sampler2D;
uniform sampler2D HdrBuffer;
uniform sampler2D SdrBuffer;
uniform ivec2 gainMapSize;
uniform float hdrExposureScale;
uniform float maxGainRatio;
out vec4 Output;

/*
 * IRIS_26472_SDR_AUTHORITATIVE_UHDR_HEADROOM
 * IRIS_26472_EDGE_CONSTRAINED_GAIN_SPIKE_LIMITER
 *
 * UHDR contract:
 * - SDR/base is the sole spatial-detail authority.
 * - No UHDR denoise, blur, sharpening, microcontrast, texture enhancement,
 *   texture suppression, or normal spatial smoothing.
 * - The center raw log-gain passes through unchanged by default.
 * - A compact 3x3 SDR-guided neighborhood is used ONLY to identify an
 *   isolated/thin pathological gain excursion that could render as the
 *   26470 razor halo.
 * - Strong SDR luminance boundaries exclude cross-surface neighbors so HDR
 *   headroom cannot bleed across walls/window frames.
 */
const float UHDR_OFFSET=0.015625;
const float SAME_SURFACE_LOG_LUMA=0.20;
const float SPIKE_BASE_LOG2=0.18;
const float SPIKE_SIGMA_MULT=2.25;

float luminance(vec3 c){return dot(c,vec3(0.2126,0.7152,0.0722));}
float srgbDecode(float x){
    x=clamp(x,0.0,1.0);
    return x<=0.04045?x/12.92:pow((x+0.055)/1.055,2.4);
}
vec3 srgbDecode(vec3 c){
    return vec3(srgbDecode(c.r),srgbDecode(c.g),srgbDecode(c.b));
}
float sdrLogLuma(vec2 uv){
    uv=clamp(uv,vec2(0.0),vec2(1.0));
    vec3 sdr=srgbDecode(texture(SdrBuffer,uv).rgb);
    return log(UHDR_OFFSET+max(luminance(sdr),0.0));
}
float rawLogGain(vec2 uv,float maxLog){
    uv=clamp(uv,vec2(0.0),vec2(1.0));
    vec3 hdr=max(texture(HdrBuffer,uv).rgb,vec3(0.0))*hdrExposureScale;
    vec3 sdr=srgbDecode(texture(SdrBuffer,uv).rgb);
    float ratio=clamp(
        (max(luminance(hdr),0.0)+UHDR_OFFSET)/
        (max(luminance(sdr),0.0)+UHDR_OFFSET),
        1.0,max(maxGainRatio,1.001));
    return clamp(log2(ratio),0.0,maxLog);
}
void main(){
    vec2 gm=max(vec2(gainMapSize),vec2(1.0));
    vec2 uv=gl_FragCoord.xy/gm;
    float maxLog=max(log2(max(maxGainRatio,1.001)),1.0e-6);

    float centerGain=rawLogGain(uv,maxLog);
    float centerGuide=sdrLogLuma(uv);

    float sum=0.0;
    float sumSq=0.0;
    float weight=0.0;
    float support=0.0;

    for(int oy=-1;oy<=1;oy++) for(int ox=-1;ox<=1;ox++){
        if(ox==0 && oy==0) continue;
        vec2 q=uv+vec2(float(ox),float(oy))/gm;
        float guide=sdrLogLuma(q);
        float dg=abs(guide-centerGuide);
        float sameSurface=1.0-smoothstep(
            SAME_SURFACE_LOG_LUMA*0.70,
            SAME_SURFACE_LOG_LUMA,
            dg);
        if(sameSurface<=0.0) continue;

        float g=rawLogGain(q,maxLog);
        sum+=sameSurface*g;
        sumSq+=sameSurface*g*g;
        weight+=sameSurface;
        support+=step(0.50,sameSurface);
    }

    // Default path: exact center gain is preserved.
    float outGain=centerGain;

    // Correct only a statistically isolated/thin same-surface gain spike.
    if(weight>2.5 && support>=3.0){
        float mean=sum/weight;
        float variance=max(sumSq/weight-mean*mean,0.0);
        float sigma=sqrt(variance);
        float residual=abs(centerGain-mean);
        float threshold=max(SPIKE_BASE_LOG2,SPIKE_SIGMA_MULT*sigma);
        float spike=smoothstep(threshold,threshold+0.12,residual);
        outGain=mix(centerGain,mean,spike);
    }

    float encoded=clamp(outGain/maxLog,0.0,1.0);
    Output=vec4(encoded,encoded,encoded,1.0);
}
