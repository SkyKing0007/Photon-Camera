package com.particlesdevs.photoncamera.processing;

import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;

import com.particlesdevs.photoncamera.processing.processor.RawVideoProcessor;
import com.particlesdevs.photoncamera.util.Log;
import com.particlesdevs.photoncamera.api.ParseExif;
import com.particlesdevs.photoncamera.api.CameraMode;
import com.particlesdevs.photoncamera.app.PhotonCamera;
import com.particlesdevs.photoncamera.control.GyroBurst;
import com.particlesdevs.photoncamera.processing.processor.HdrxProcessor;
import com.particlesdevs.photoncamera.processing.processor.UnlimitedProcessor;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;

public class DefaultSaver extends SaverImplementation {
    private static final String TAG = "DefaultSaver";
    final UnlimitedProcessor mUnlimitedProcessor;
    final RawVideoProcessor mRawVideoProcessor;
    private CameraMode activeContinuousMode = null;
    final HdrxProcessor hdrxProcessor;

    public DefaultSaver(ProcessingEventsListener processingEventsListener) {
        super(processingEventsListener);
        this.hdrxProcessor = new HdrxProcessor(processingEventsListener);
        this.mUnlimitedProcessor = new UnlimitedProcessor(processingEventsListener);
        this.mRawVideoProcessor = new RawVideoProcessor(processingEventsListener);
    }

    /* IRIS_26486_DEFAULTSAVER_MOTIONBATCH_SOLE_OWNER
     * Motion owns copied RAWs in the immutable batch. No static IMAGE_BUFFER,
     * no busy-wait, and no cross-shot slicing/reassignment are involved.
     */
    public void runMotionBatch(CameraCharacteristics characteristics, MotionBatch batch) {
        if (batch == null || batch.frames == null || batch.frames.size() < 2) {
            throw new IllegalStateException("26486 MotionBatch requires at least two normal RAW frames");
        }
        /* IRIS_26486_SERIALIZED_LEGACY_METADATA_COMPATIBILITY
         * These globals are written only here, on the one serialized processing lane.
         * Capture of the next shot never mutates them.
         */
        com.particlesdevs.photoncamera.processing.parameters.FrameNumberSelector.frameCount =
                batch.retainedCount;
        com.particlesdevs.photoncamera.processing.parameters.IsoExpoSelector.fullpairs.clear();
        for (com.particlesdevs.photoncamera.processing.parameters.IsoExpoSelector.ExpoPair source
                : batch.exposurePairs) {
            com.particlesdevs.photoncamera.processing.parameters.IsoExpoSelector.ExpoPair copy =
                    new com.particlesdevs.photoncamera.processing.parameters.IsoExpoSelector.ExpoPair(source);
            copy.curlayer = com.particlesdevs.photoncamera.processing.parameters.IsoExpoSelector
                    .ExpoPair.exposureLayer.Normal;
            copy.layerMpy = 1.0f;
            com.particlesdevs.photoncamera.processing.parameters.IsoExpoSelector.fullpairs.add(copy);
        }
        super.runRaw(batch.imageFormat, characteristics, batch.referenceResult,
                batch.referenceRequest, new ArrayList<>(batch.gyro), batch.rotation,
                new HashMap<>(batch.exposures));
        hdrxProcessor.configure(
                PhotonCamera.getSettings().alignAlgorithm,
                PhotonCamera.getSettings().rawSaver,
                PhotonCamera.getSettings().selectedMode);
        Path dngFile = ImagePath.newDNGFilePath();
        Path imageFile = ImagePath.newImageFilePath();
        ArrayList<ImageFrame> ownedFrames = new ArrayList<>(batch.frames);
        hdrxProcessor.startMotion(
                dngFile,
                imageFile,
                ParseExif.parse(batch.referenceResult, batch.referenceRequest),
                new ArrayList<>(batch.gyro),
                ownedFrames,
                new HashMap<>(batch.exposures),
                batch.imageFormat,
                batch.rotation,
                characteristics,
                batch.referenceResult,
                batch.referenceRequest,
                batch.exposurePairs,
                batch.shortHighlightSlot,
                processingCallback);
    }

    public void runRaw(int imageFormat, CameraCharacteristics characteristics, CaptureResult captureResult, CaptureRequest captureRequest, ArrayList<GyroBurst> burstShakiness, int cameraRotation, HashMap<Long, Double> exposures) {
        super.runRaw(imageFormat, characteristics, captureResult,captureRequest, burstShakiness, cameraRotation, exposures);
        //Wait for one frame at least.
        Log.d(TAG, "Acquiring:" + IMAGE_BUFFER.size());
        while (bufferLock || IMAGE_BUFFER.isEmpty()){}
        Log.d(TAG, "Acquired:" + IMAGE_BUFFER.size());
        bufferLock = true;
        Log.d(TAG,"Size:"+IMAGE_BUFFER.size());
        /*if (PhotonCamera.getSettings().frameCount == 1) {
            Path dngFile = ImagePath.newDNGFilePath();
            Log.d(TAG, "Size:" + IMAGE_BUFFER.size());
            boolean imageSaved = ImageSaver.Util.saveSingleRaw(dngFile, IMAGE_BUFFER.get(0),
                    characteristics, captureResult, cameraRotation);
            processingEventsListener.notifyImageSavedStatus(imageSaved, dngFile);
            processingEventsListener.onProcessingFinished("Saved Unprocessed RAW");
            IMAGE_BUFFER.clear();
            bufferLock = false;
            return;
        }*/
        Path dngFile = ImagePath.newDNGFilePath();
        Path imageFile = ImagePath.newImageFilePath();
        //Remove broken images
            /*for(int i =0; i<IMAGE_BUFFER.size();i++){
                try{
                    IMAGE_BUFFER.get(i).getFormat();
                } catch (IllegalStateException e){
                    IMAGE_BUFFER.remove(i);
                    i--;
                    Log.d(TAG,"IMGBufferSize:"+IMAGE_BUFFER.size());
                    e.printStackTrace();
                }
            }*/
        hdrxProcessor.configure(
                PhotonCamera.getSettings().alignAlgorithm,
                PhotonCamera.getSettings().rawSaver,
                PhotonCamera.getSettings().selectedMode
        );
        ArrayList<ImageFrame> slicedBuffer = new ArrayList<>();
        ArrayList<ImageFrame> imagebuffer = new ArrayList<>();
        for(int i =0; i<frameCount;i++){
            slicedBuffer.add(IMAGE_BUFFER.get(i));
        }
        for(int i = frameCount; i<IMAGE_BUFFER.size();i++){
            imagebuffer.add(IMAGE_BUFFER.get(i));
        }
        IMAGE_BUFFER.clear();
        IMAGE_BUFFER = imagebuffer;
        bufferLock = false;
        for(int i =0; i<slicedBuffer.size();i++){
            if (slicedBuffer.get(i) == null) {
                slicedBuffer.remove(i);
                i--;
                Log.d(TAG, "IMGBufferSize:" + slicedBuffer.size());
            }
        }

        Log.d(TAG,"moving images");
        //Log.d(TAG,"moved images:"+slicedBuffer.size());
        hdrxProcessor.start(
                dngFile,
                imageFile,
                ParseExif.parse(captureResult, captureRequest),
                burstShakiness,
                slicedBuffer,
                exposures,
                imageFormat,
                cameraRotation,
                characteristics,
                captureResult,
                captureRequest,
                processingCallback
        );
        slicedBuffer.clear();
    }

    public void processStart(int imageFormat, CameraCharacteristics characteristics, CaptureResult captureResult, CaptureRequest captureRequest, int cameraRotation) {
        super.processStart(imageFormat, characteristics, captureResult, captureRequest, cameraRotation);
        Path dngFile = ImagePath.newDNGFilePath();
        Path jpgFile = ImagePath.newImageFilePath();
        activeContinuousMode = PhotonCamera.getSettings().selectedMode;
        Log.d(TAG, "processStart continuousMode=" + activeContinuousMode);
        switch (activeContinuousMode) {
            case UNLIMITED:
                mUnlimitedProcessor.configure(PhotonCamera.getSettings().rawSaver);
                mUnlimitedProcessor.unlimitedStart(
                        dngFile,
                        jpgFile,
                        ParseExif.parse(captureResult, captureRequest),
                        characteristics,
                        captureResult,
                        captureRequest,
                        cameraRotation,
                        processingCallback
                );
                break;
            case RAWVIDEO:
                mRawVideoProcessor.videoStart(
                        ImagePath.getNewVideoFolderPath(),
                        ParseExif.parse(captureResult, captureRequest),
                        characteristics,
                        captureResult,
                        captureRequest,
                        cameraRotation,
                        processingCallback
                );
                break;
        }
    }

    public void processEnd() {
        CameraMode modeToEnd = activeContinuousMode;
        Log.d(TAG, "processEnd activeContinuousMode=" + modeToEnd
                + " selectedMode=" + PhotonCamera.getSettings().selectedMode);
        if (modeToEnd == null) {
            return;
        }
        switch (modeToEnd) {
            case UNLIMITED:
                mUnlimitedProcessor.unlimitedEnd();
                break;
            case RAWVIDEO:
                mRawVideoProcessor.videoEnd();
                break;
        }
    }
}
