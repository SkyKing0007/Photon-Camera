package com.particlesdevs.photoncamera.processing.opengl.postpipeline;

import android.graphics.Point;
import com.particlesdevs.photoncamera.util.Log;

import com.particlesdevs.photoncamera.app.PhotonCamera;
import com.particlesdevs.photoncamera.processing.opengl.GLDrawParams;
import com.particlesdevs.photoncamera.processing.opengl.GLFormat;
import com.particlesdevs.photoncamera.processing.opengl.GLImage;
import com.particlesdevs.photoncamera.processing.opengl.GLTexture;
import com.particlesdevs.photoncamera.processing.opengl.nodes.Node;
import com.particlesdevs.photoncamera.settings.annotations.Tunable;
import com.particlesdevs.photoncamera.util.BufferUtils;
import java.io.IOException;

import static android.opengl.GLES20.GL_CLAMP_TO_EDGE;
import static android.opengl.GLES20.GL_LINEAR;
import static android.opengl.GLES20.GL_MIRRORED_REPEAT;
import static android.opengl.GLES20.GL_NEAREST;

public class Bayer2Float extends Node {

    /*
     * IRIS_26404_MOTION_IQ_LAB
     * Runtime-injected before every node Run(), so these can be changed
     * between captures without rebuilding the APK.
     */
    @Tunable(
            title = "Highlight Shoulder Enable",
            description = "Motion only. 0 restores the pre-26403 hard-clamp behavior; 1 enables the highlight-preserving shoulder.",
            category = "Motion IQ Highlight",
            min = 0.0f, max = 1.0f, defaultValue = 1.0f, step = 1.0f
    )
    boolean motionHighlightShoulderEnable = true;

    @Tunable(
            title = "Highlight Shoulder Start",
            description = "Motion only. Linear signal below this value is left unchanged.",
            category = "Motion IQ Highlight",
            min = 0.75f, max = 0.98f, defaultValue = 0.84f, step = 0.01f
    )
    float motionHighlightShoulderStart = 0.84f;

    @Tunable(
            title = "Highlight Shoulder Strength",
            description = "Motion only. 0 = no shoulder, 1 = exact 26403 shoulder strength.",
            category = "Motion IQ Highlight",
            min = 0.0f, max = 1.0f, defaultValue = 1.0f, step = 0.05f
    )
    float motionHighlightShoulderStrength = 1.0f;

    public Bayer2Float() {
        super("", "Bayer2Float");
    }

    @Override
    public void Compile() {
    }
    boolean testPattern = false;
    @Override
    public void AfterRun(){
        if(testPattern) {
            kodbm.close();
            kod.close();
        }
    }
    GLImage kodbm;
    GLTexture kod;
    @Override
    public void Run() {
        if (com.particlesdevs.photoncamera.settings.MotionIqLab.active()) {
            motionHighlightShoulderEnable =
                    com.particlesdevs.photoncamera.settings.MotionIqLab.getBool(
                            "highlight_shoulder_enable", true);
            motionHighlightShoulderStart =
                    com.particlesdevs.photoncamera.settings.MotionIqLab.getFloat(
                            "highlight_shoulder_start", 0.84f);
            motionHighlightShoulderStrength =
                    com.particlesdevs.photoncamera.settings.MotionIqLab.getFloat(
                            "highlight_shoulder_strength", 1.0f);
        }
        PostPipeline postPipeline = (PostPipeline) basePipeline;
        Point rawSize = basePipeline.mParameters.rawSize;

        GLTexture in;
        if(basePipeline.mSettings.alignAlgorithm != 2) {
            in = new GLTexture(rawSize, new GLFormat(GLFormat.DataType.UNSIGNED_16),
                    ((PostPipeline) (basePipeline)).stackFrame, GL_NEAREST, GL_MIRRORED_REPEAT);
        } else {
            in = new GLTexture(rawSize, new GLFormat(GLFormat.DataType.UNSIGNED_16, 3),
                    ((PostPipeline) (basePipeline)).stackFrame, GL_NEAREST, GL_MIRRORED_REPEAT);
        }
        GLTexture GainMapTex = new GLTexture(basePipeline.mParameters.mapSize, new GLFormat(GLFormat.DataType.FLOAT_16, 4),
                BufferUtils.getFrom(basePipeline.mParameters.gainMap), GL_LINEAR, GL_CLAMP_TO_EDGE);

        if (PhotonCamera.getSettings().aspect169) {
            if (rawSize.x > rawSize.y) {
                glProg.setDefine("OFFSET", 0, 2 * (((rawSize.y - rawSize.x * 9 / 16) / 2) / 2));
            } else {
                glProg.setDefine("OFFSET", 2 * (((rawSize.x - rawSize.y * 9 / 16) / 2) / 2), 0);
            }
        }

        float[] BL = new float[3];
        glProg.setDefine("BLR", BL[0]);
        glProg.setDefine("BLG", BL[1]);
        glProg.setDefine("BLB", BL[2]);
        glProg.setDefine("QUAD", basePipeline.mSettings.cfaPattern == -2);
        glProg.setDefine("RGBLAYOUT",basePipeline.mSettings.alignAlgorithm == 2);
        glProg.setDefine("TESTPATTERN",testPattern);

        /*
         * IRIS_26403_MOTION_HIGHLIGHT_PRESERVATION
         * Motion only. Keep Photo/Night on the exact legacy Bayer normalization.
         * The shader applies a smooth high-end shoulder instead of destroying
         * highlight ordering with a hard 1.0 clamp.
         */
        /* IRIS_26410_MOTION_V2_HIGHLIGHT_OWNER */
        boolean iris26410V2Highlight = basePipeline.mParameters.motionV2Active;
        boolean iris26403MotionHighlightPreservation =
                iris26410V2Highlight
                        || com.particlesdevs.photoncamera.processing.MotionMetrics.isActive();
        glProg.setDefine(
                "IRIS_26403_MOTION_HIGHLIGHT_SHOULDER",
                iris26403MotionHighlightPreservation ? 1 : 0);
        glProg.setDefine("IRIS_26412_MOTION_V2_WIDE_LINEAR",
                basePipeline.mParameters.motionV2Active ? 1 : 0);

        glProg.useAssetProgram("tofloat");

        /*
         * IRIS_26404_MOTION_IQ_LAB
         * Use uniforms rather than compile-time constants so values selected
         * in Tunables are consumed on the next capture.
         */
        glProg.setVar(
                "MotionHighlightShoulderEnable",
                iris26410V2Highlight
                        ? 1
                        : (iris26403MotionHighlightPreservation && motionHighlightShoulderEnable ? 1 : 0));
        glProg.setVar(
                "MotionHighlightShoulderStart",
                iris26410V2Highlight
                        ? 0.84f
                        : com.particlesdevs.photoncamera.util.Math2.clamp(
                                motionHighlightShoulderStart, 0.75f, 0.98f));
        glProg.setVar(
                "MotionHighlightShoulderStrength",
                iris26410V2Highlight
                        ? 1.0f
                        : com.particlesdevs.photoncamera.util.Math2.clamp(
                                motionHighlightShoulderStrength, 0.0f, 1.0f));
        glProg.setTexture("InputBuffer", in);
        glProg.setVar("CfaPattern", basePipeline.mParameters.cfaPattern);
        glProg.setVar("patSize", 2);
        glProg.setVar("whitePoint", basePipeline.mParameters.whitePoint);
        glProg.setVar("RawSize", basePipeline.mParameters.rawSize);
        glProg.setVar("RawInvSize", 1.0f/basePipeline.mParameters.rawSize.x, 1.0f/basePipeline.mParameters.rawSize.y);
        Log.d(Name, "whitelevel:" + basePipeline.mParameters.whiteLevel);
        glProg.setVarU("whitelevel", (basePipeline.mParameters.whiteLevel));
        glProg.setTexture("GainMap", GainMapTex);
        if(testPattern) {
            try {
                kodbm = new GLImage(PhotonCamera.getAssetLoader().getInputStream("kodim19.png"));
                kod = new GLTexture(kodbm);
                glProg.setTexture("Kodak", kod);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        for (int i = 0; i < 4; i++) {
            basePipeline.mParameters.blackLevel[i] /= basePipeline.mParameters.whiteLevel * postPipeline.regenerationSense;
        }
        glProg.setVar("blackLevel", basePipeline.mParameters.blackLevel);
        Log.d(Name, "CfaPattern:" + basePipeline.mParameters.cfaPattern);
        postPipeline.regenerationSense = 10.f;
        int minimal = -1;
        for (int i = 0; i < basePipeline.mParameters.whitePoint.length; i++) {
            if (i == 1) continue;
            if (basePipeline.mParameters.whitePoint[i] < postPipeline.regenerationSense) {
                postPipeline.regenerationSense = basePipeline.mParameters.whitePoint[i];
                minimal = i;
            }
        }
        if (basePipeline.mParameters.cfaPattern == 4) postPipeline.regenerationSense = 1.f;
        postPipeline.regenerationSense = 1.f / postPipeline.regenerationSense;
        postPipeline.regenerationSense = 1.f;
        Log.d(Name, "Regeneration:" + postPipeline.regenerationSense);
        glProg.setVar("Regeneration", postPipeline.regenerationSense);
        glProg.setVar("CanonicalExposureGain",
                Math.max(1.0f, basePipeline.mParameters.motionCanonicalExposureGain));
        Log.d(Name, "IRIS_26394 CanonicalExposureGain:"
                + basePipeline.mParameters.motionCanonicalExposureGain);
        glProg.setVar("MinimalInd", minimal);
        Point wsize = new Point(basePipeline.mParameters.rawSize);
        basePipeline.main2 = new GLTexture(wsize, new GLFormat(GLFormat.DataType.FLOAT_16, GLDrawParams.WorkDim), null, GL_LINEAR, GL_CLAMP_TO_EDGE);
        WorkingTexture = basePipeline.main2;

        glProg.drawBlocks(WorkingTexture);
        basePipeline.main1 = new GLTexture(wsize, new GLFormat(GLFormat.DataType.FLOAT_16, GLDrawParams.WorkDim), null, GL_LINEAR, GL_CLAMP_TO_EDGE);
        basePipeline.main3 = new GLTexture(wsize, new GLFormat(GLFormat.DataType.FLOAT_16, GLDrawParams.WorkDim), null, GL_LINEAR, GL_CLAMP_TO_EDGE);
        ((PostPipeline) basePipeline).GainMap = GainMapTex;
        glProg.closed = true;
        in.close();
        //GainMapTex.close();
    }
}
