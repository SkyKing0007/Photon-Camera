precision highp float;
precision highp int;
precision mediump sampler2D;
uniform sampler2D HdrBuffer;
uniform sampler2D SdrBuffer;
uniform ivec2 gainMapSize;
uniform ivec2 sourceSize;
uniform float hdrExposureScale;
uniform float maxGainRatio;
out vec4 Output;

/* IRIS_26496_GUIDED_LOG_GAIN_DECIMATION
 * 26495 blurred HDR and SDR independently before division. Across a strong edge,
 * those two fields do not share the same tone relationship, so their quotient can
 * create a broad gain halo. 26496 forms the physical multiplicative relationship
 * FIRST at full resolution, converts it to log2 gain, then anti-aliases that gain
 * field for 4:1 decimation. SDR luminance is only a guide that prevents large gain
 * from bleeding across a strong object edge; the full-resolution SDR base is never
 * filtered or changed.
 */
const float UHDR_OFFSET = 0.015625;
const int DOWNSAMPLE = 4;
const int FILTER_TAPS = 10;
const int FILTER_START = -3; /* -3..+6 is centered on the 4x4 cell center at 1.5. */
const float GUIDE_SIGMA_EV = 0.90;
const float KERNEL[FILTER_TAPS] = float[FILTER_TAPS](
        0.042229693589,
        0.070339090351,
        0.103129012812,
        0.133097613729,
        0.151204589518,
        0.151204589518,
        0.133097613729,
        0.103129012812,
        0.070339090351,
        0.042229693589);

float luminance(vec3 c){return dot(c,vec3(0.2126,0.7152,0.0722));}
float srgbDecode(float x){
    x=clamp(x,0.0,1.0);
    return x<=0.04045?x/12.92:pow((x+0.055)/1.055,2.4);
}
vec3 srgbDecode(vec3 c){return vec3(srgbDecode(c.r),srgbDecode(c.g),srgbDecode(c.b));}
float sdrLumaAt(ivec2 p) {
    p=clamp(p,ivec2(0),sourceSize-ivec2(1));
    return max(luminance(srgbDecode(texelFetch(SdrBuffer,p,0).rgb)),0.0);
}
float hdrLumaAt(ivec2 p) {
    p=clamp(p,ivec2(0),sourceSize-ivec2(1));
    return max(luminance(max(texelFetch(HdrBuffer,p,0).rgb,vec3(0.0))*hdrExposureScale),0.0);
}
float centerGuideLuma(ivec2 base) {
    return 0.25*(sdrLumaAt(base+ivec2(1,1))+sdrLumaAt(base+ivec2(2,1))
            +sdrLumaAt(base+ivec2(1,2))+sdrLumaAt(base+ivec2(2,2)));
}
float guideWeight(float centerLuma,float sampleLuma) {
    float ev=abs(log2((sampleLuma+UHDR_OFFSET)/(centerLuma+UHDR_OFFSET)));
    float z=ev/GUIDE_SIGMA_EV;
    return exp(-0.5*z*z);
}
void main(){
    ivec2 gp=ivec2(gl_FragCoord.xy);
    if(any(greaterThanEqual(gp,gainMapSize))){
        Output=vec4(0.0,0.0,0.0,1.0);
        return;
    }
    ivec2 base=gp*DOWNSAMPLE;
    float maxLog=max(log2(max(maxGainRatio,1.001)),1.0e-6);
    float centerLuma=centerGuideLuma(base);
    float sum=0.0;
    float weightSum=0.0;
    for(int ky=0;ky<FILTER_TAPS;++ky){
        for(int kx=0;kx<FILTER_TAPS;++kx){
            ivec2 sp=clamp(base+ivec2(FILTER_START+kx,FILTER_START+ky),
                    ivec2(0),sourceSize-ivec2(1));
            float spatial=KERNEL[kx]*KERNEL[ky];
            float sdr=sdrLumaAt(sp);
            float hdr=hdrLumaAt(sp);
            float ratio=clamp((hdr+UHDR_OFFSET)/(sdr+UHDR_OFFSET),
                    1.0,max(maxGainRatio,1.001));
            float logGain=clamp(log2(ratio),0.0,maxLog);
            float guide=guideWeight(centerLuma,sdr);
            float w=spatial*guide;
            sum+=w*logGain;
            weightSum+=w;
        }
    }
    float filteredLogGain=sum/max(weightSum,1.0e-12);
    float encoded=clamp(filteredLogGain/maxLog,0.0,1.0);
    Output=vec4(encoded,encoded,encoded,1.0);
}
