#define LAYOUT //
LAYOUT
precision highp float;
precision highp int;
precision highp sampler2D;

uniform highp sampler2D HighlightProvenance;
layout(std430, binding = 1) buffer RedBuf { float red[]; };
layout(std430, binding = 2) readonly buffer GreenBuf { float green[]; };
layout(std430, binding = 3) buffer BlueBuf { float blue[]; };
/* Reuse buffers whose 26494 directional jobs are complete. No new full-band buffers. */
layout(std430, binding = 4) buffer AffectedBuf { float affected[]; };
layout(std430, binding = 5) buffer RedSeedBuf { float redSeed[]; };
layout(std430, binding = 6) buffer RedWeightBuf { float redWeight[]; };
layout(std430, binding = 7) buffer BlueSeedBuf { float blueSeed[]; };
layout(std430, binding = 8) buffer BlueWeightBuf { float blueWeight[]; };

uniform ivec2 rawSize;
uniform ivec2 bandSize;
uniform int bandOriginY;
uniform int cfaPattern;
uniform int mode;

const float PROVENANCE_CENSORED = 1.0;
const int FILTER_RADIUS = 5;

int idxAt(ivec2 p) {
    p = clamp(p, ivec2(0), bandSize - ivec2(1));
    return p.y * bandSize.x + p.x;
}
ivec2 globalAt(ivec2 p) { return ivec2(p.x, bandOriginY + p.y); }
int phaseAtGlobal(ivec2 gp) { return (gp.x & 1) | ((gp.y & 1) << 1); }
int colorAt(ivec2 p) {
    int q = phaseAtGlobal(globalAt(p));
    if (cfaPattern == 0) return q == 0 ? 0 : (q == 3 ? 2 : 1);
    if (cfaPattern == 1) return q == 1 ? 0 : (q == 2 ? 2 : 1);
    if (cfaPattern == 2) return q == 2 ? 0 : (q == 1 ? 2 : 1);
    return q == 3 ? 0 : (q == 0 ? 2 : 1);
}
float phaseDivisor(int q) {
    return q == 0 ? 1.0 : (q == 1 ? 3.0 : (q == 2 ? 9.0 : 27.0));
}
float provenanceAtGlobal(ivec2 gp) {
    gp = clamp(gp, ivec2(0), rawSize - ivec2(1));
    float code = texelFetch(HighlightProvenance, gp >> 1, 0).r;
    float digit = floor(code / phaseDivisor(phaseAtGlobal(gp)));
    return mod(digit, 3.0);
}
bool ownCensored(ivec2 p) {
    return abs(provenanceAtGlobal(globalAt(p)) - PROVENANCE_CENSORED) < 0.25;
}
bool packedCodeHasCensored(float encoded) {
    int code = clamp(int(floor(encoded + 0.5)), 0, 80);
    for (int i = 0; i < 4; ++i) {
        int state = code % 3;
        if (state == 1) return true;
        code /= 3;
    }
    return false;
}
bool nearbyCensored(ivec2 p) {
    ivec2 packedSize = rawSize / 2;
    ivec2 pc = globalAt(p) >> 1;
    /* 3x3 packed neighborhood covers the physical support that can feed the
     * original RCD color interpolation around a clipped Bayer site. */
    for (int oy = -1; oy <= 1; ++oy) {
        for (int ox = -1; ox <= 1; ++ox) {
            ivec2 q = clamp(pc + ivec2(ox, oy), ivec2(0), packedSize - ivec2(1));
            if (packedCodeHasCensored(texelFetch(HighlightProvenance, q, 0).r)) return true;
        }
    }
    return false;
}
float g(ivec2 p) { return green[idxAt(p)]; }

void seedPass(ivec2 p) {
    int i = idxAt(p);
    int c = colorAt(p);
    bool trusted = !ownCensored(p);
    redSeed[i] = (trusted && c == 0) ? red[i] - green[i] : 0.0;
    redWeight[i] = (trusted && c == 0) ? 1.0 : 0.0;
    blueSeed[i] = (trusted && c == 2) ? blue[i] - green[i] : 0.0;
    blueWeight[i] = (trusted && c == 2) ? 1.0 : 0.0;
    affected[i] = nearbyCensored(p) ? 1.0 : 0.0;
}

float spatialWeight(ivec2 d) {
    float d2 = float(d.x * d.x + d.y * d.y);
    return exp(-0.18 * d2);
}
float guideWeight(float centerGreen, float sampleGreen) {
    float scale = max(max(abs(centerGreen), abs(sampleGreen)), 0.05);
    float rel = abs(sampleGreen - centerGreen) / scale;
    return exp(-10.0 * rel * rel);
}
float confidenceFromWeight(float w) {
    return smoothstep(0.15, 0.75, w);
}

void completionPass(ivec2 p) {
    int i = idxAt(p);
    if (affected[i] < 0.5) return; /* Exact 26494 output outside censor influence. */

    float gc = green[i];
    float sumR = 0.0, sumRw = 0.0;
    float sumB = 0.0, sumBw = 0.0;
    for (int oy = -FILTER_RADIUS; oy <= FILTER_RADIUS; ++oy) {
        for (int ox = -FILTER_RADIUS; ox <= FILTER_RADIUS; ++ox) {
            ivec2 d = ivec2(ox, oy);
            ivec2 q = clamp(p + d, ivec2(0), bandSize - ivec2(1));
            int qi = idxAt(q);
            float sw = spatialWeight(d) * guideWeight(gc, green[qi]);
            float rw = sw * redWeight[qi];
            float bw = sw * blueWeight[qi];
            sumR += rw * redSeed[qi];
            sumRw += rw;
            sumB += bw * blueSeed[qi];
            sumBw += bw;
        }
    }

    float dr = sumRw > 1.0e-6 ? sumR / sumRw : 0.0;
    float db = sumBw > 1.0e-6 ? sumB / sumBw : 0.0;
    dr *= confidenceFromWeight(sumRw);
    db *= confidenceFromWeight(sumBw);

    int c = colorAt(p);
    bool ownTrusted = !ownCensored(p);
    /* A real NORMAL/SHORT_VALIDATED physical R or B observation is immutable.
     * Only missing/interpolated opponent chroma is completed. When support is
     * weak, the residual smoothly approaches neutral instead of snapping at a
     * binary threshold. Green/luminance geometry remains the exact 26494 RCD result. */
    if (!(ownTrusted && c == 0)) red[i] = max(0.0, gc + dr);
    if (!(ownTrusted && c == 2)) blue[i] = max(0.0, gc + db);
}

/* IRIS_26496_RCD_MISSING_CHROMA_NORMALIZED_CONVOLUTION
 * mode=0 seeds only physically measured NORMAL/SHORT_VALIDATED R-G/B-G and an
 * affected mask. mode=1 completes missing opponent chroma around censored sites
 * using the already-reconstructed green field as an edge guide. The original
 * nine 26494 RCD directional passes run first and are byte-identical. */
void main() {
    ivec2 p = ivec2(gl_GlobalInvocationID.xy);
    if (any(greaterThanEqual(p, bandSize))) return;
    if (mode == 0) seedPass(p); else completionPass(p);
}
