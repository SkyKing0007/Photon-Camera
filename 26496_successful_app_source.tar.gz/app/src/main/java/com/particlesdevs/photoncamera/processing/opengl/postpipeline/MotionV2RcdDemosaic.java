package com.particlesdevs.photoncamera.processing.opengl.postpipeline;

import android.graphics.Point;

import com.particlesdevs.photoncamera.processing.opengl.GLBuffer;
import com.particlesdevs.photoncamera.processing.opengl.GLFormat;
import com.particlesdevs.photoncamera.processing.opengl.GLTexture;
import com.particlesdevs.photoncamera.processing.opengl.nodes.Node;
import com.particlesdevs.photoncamera.util.Log;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import static android.opengl.GLES20.GL_CLAMP_TO_EDGE;
import static android.opengl.GLES20.GL_LINEAR;
import static android.opengl.GLES31.GL_ALL_BARRIER_BITS;
import static android.opengl.GLES31.GL_DYNAMIC_DRAW;
import static android.opengl.GLES31.glMemoryBarrier;

/**
 * IRIS_26489_POSTMERGE_RCD_DEMOSAIC_OWNER
 *
 * Motion's temporal owner stops at a fused Bayer lattice. This node runs a banded, full
 * directional RCD reconstruction after the burst is complete. The equations are split into the
 * same physical stages as the reference RCD pipeline: calculation-domain populate, VH direction,
 * low-pass support, green reconstruction, diagonal residual/direction, opposite colour,
 * red/blue-at-green, then one camera-RGB write. PPG is confined to the true photo border.
 */
public final class MotionV2RcdDemosaic extends Node {
    private static final int BAND_CORE_ROWS = 256;
    private static final int RCD_HALO_ROWS = 12;

    public MotionV2RcdDemosaic() {
        super("", "MotionV2RcdDemosaic");
    }

    @Override
    public void Compile() {}

    private GLBuffer scratch(int pixels) {
        return new GLBuffer(
                pixels,
                new GLFormat(GLFormat.DataType.FLOAT_32),
                GL_DYNAMIC_DRAW,
                false);
    }

    private void dispatch(Point size) {
        glProg.computeAutoDeferred(size, 1);
    }

    @Override
    public void Run() {
        if (!basePipeline.mParameters.motionV2Active) {
            throw new IllegalStateException("MotionV2RcdDemosaic used outside Motion V2");
        }
        if (previousNode == null || previousNode.WorkingTexture == null) {
            throw new IllegalStateException("26489 fused Bayer input is missing");
        }
        Point raw = basePipeline.mParameters.rawSize;
        Point packed = new Point(raw.x / 2, raw.y / 2);
        if (!previousNode.WorkingTexture.mSize.equals(packed)) {
            throw new IllegalStateException(
                    "26489 packed Bayer dimensions mismatch expected=" + packed
                            + " actual=" + previousNode.WorkingTexture.mSize);
        }
        if (raw.x <= 0 || raw.y <= 0 || (raw.x & 1) != 0 || (raw.y & 1) != 0) {
            throw new IllegalStateException("26489 RCD requires even native Bayer dimensions");
        }

        float[] gains = basePipeline.mParameters.motionV2ColorGains;
        if (!basePipeline.mParameters.motionV2DirectColorValid
                || gains == null || gains.length != 4) {
            throw new IllegalStateException("26489 RCD requires timestamp-owned HAL color gains");
        }
        float greenGain = Math.max(0.5f * (gains[1] + gains[2]), 1.0e-6f);
        float wbR = Math.max(gains[0] / greenGain, 1.0e-6f);
        float wbB = Math.max(gains[3] / greenGain, 1.0e-6f);

        boolean hasLsc = basePipeline.mParameters.hasGainMap
                && basePipeline.mParameters.mapSize != null
                && basePipeline.mParameters.mapSize.x > 0
                && basePipeline.mParameters.mapSize.y > 0
                && basePipeline.mParameters.gainMap != null
                && basePipeline.mParameters.gainMap.length
                        >= basePipeline.mParameters.mapSize.x * basePipeline.mParameters.mapSize.y * 4;
        Point lscSize = hasLsc ? new Point(basePipeline.mParameters.mapSize) : new Point(1, 1);
        float[] lscValues = hasLsc
                ? basePipeline.mParameters.gainMap
                : new float[]{1.0f, 1.0f, 1.0f, 1.0f};
        int lscFloatCount = lscSize.x * lscSize.y * 4;
        ByteBuffer lscUpload = ByteBuffer.allocateDirect(lscFloatCount * 4)
                .order(ByteOrder.nativeOrder());
        lscUpload.asFloatBuffer().put(lscValues, 0, lscFloatCount);
        lscUpload.position(0);
        GLTexture lsc = new GLTexture(
                lscSize,
                new GLFormat(GLFormat.DataType.FLOAT_32, 4),
                lscUpload,
                GL_LINEAR,
                GL_CLAMP_TO_EDGE);

        PostPipeline postPipeline = (PostPipeline) basePipeline;
        if (postPipeline.motionV2HighlightProvenanceTexture == null) {
            lsc.close();
            throw new IllegalStateException(
                    "26492 RCD missing explicit highlight provenance texture");
        }

        WorkingTexture = basePipeline.getMain();
        if (WorkingTexture == null) {
            lsc.close();
            throw new IllegalStateException("26489 full RCD output allocation failed");
        }

        int bands = 0;
        long maxScratchBytes = 0L;
        Log.d(Name, "IRIS_26490_RCD_EXPOSURE_DOMAIN"
                + " sensorDomainWhite=1.0"
                + " displayGain=" + basePipeline.mParameters.motionV2DisplayGain
                + " displayGainInsideRcd=false"
                + " highlightThreshold=0.985"
                + " fusedBayerPhysicalSensorNormalized=true"
                + " shortRecoveryExecuted="
                + basePipeline.mParameters.motionV2ShortHighlightRecoveryExecuted);
        try {
            for (int coreY = 0; coreY < raw.y; coreY += BAND_CORE_ROWS) {
                int coreRows = Math.min(BAND_CORE_ROWS, raw.y - coreY);
                int bandTop = Math.max(0, coreY - RCD_HALO_ROWS);
                int bandBottom = Math.min(raw.y, coreY + coreRows + RCD_HALO_ROWS);
                int bandRows = bandBottom - bandTop;
                int coreLocalY = coreY - bandTop;
                Point bandSize = new Point(raw.x, bandRows);
                int pixels = Math.multiplyExact(raw.x, bandRows);
                long scratchBytes = (long) pixels * 9L * Float.BYTES;
                maxScratchBytes = Math.max(maxScratchBytes, scratchBytes);

                try (GLBuffer cfa = scratch(pixels);
                     GLBuffer red = scratch(pixels);
                     GLBuffer green = scratch(pixels);
                     GLBuffer blue = scratch(pixels);
                     GLBuffer vh = scratch(pixels);
                     GLBuffer lpf = scratch(pixels);
                     GLBuffer pdiff = scratch(pixels);
                     GLBuffer qdiff = scratch(pixels);
                     GLBuffer pq = scratch(pixels)) {

                    glProg.setLayout(8, 8, 1);
                    glProg.useAssetProgram("motionv2/rcd26489_populate", true);
                    glProg.setTexture("InputBayer", previousNode.WorkingTexture);
                    glProg.setTexture("HighlightProvenance",
                            postPipeline.motionV2HighlightProvenanceTexture);
                    glProg.setTexture("LensShadingMap", lsc);
                    glProg.setBufferCompute("CfaBuf", cfa);
                    glProg.setBufferCompute("RedBuf", red);
                    glProg.setBufferCompute("GreenBuf", green);
                    glProg.setBufferCompute("BlueBuf", blue);
                    glProg.setVar("rawSize", raw);
                    glProg.setVar("bandSize", bandSize);
                    glProg.setVar("bandOriginY", bandTop);
                    glProg.setVar("cfaPattern", (int) basePipeline.mParameters.cfaPattern);
                    glProg.setVar("calculationWb", wbR, 1.0f, wbB);
                    /* IRIS_26491_NEUTRAL_CENSOR_SENSOR_GAIN_BRIDGE */
                    glProg.setVar("sensorGains", gains[0], greenGain, gains[3]);
                    final float iris26490PhysicalSensorWhite = 1.0f;
                    glProg.setVar("sensorClipLevel", iris26490PhysicalSensorWhite);
                    glProg.setVar("highlightThreshold", 0.985f);
                    glProg.setVar("highlightCeiling", 8.0f);
                    glProg.setVar("useLensShading", hasLsc ? 1 : 0);
                    dispatch(bandSize);

                    glProg.setLayout(8, 8, 1);
                    glProg.useAssetProgram("motionv2/rcd26489_vh_direction", true);
                    glProg.setBufferCompute("CfaBuf", cfa);
                    glProg.setBufferCompute("VhBuf", vh);
                    glProg.setVar("bandSize", bandSize);
                    dispatch(bandSize);

                    glProg.setLayout(8, 8, 1);
                    glProg.useAssetProgram("motionv2/rcd26489_lpf", true);
                    glProg.setBufferCompute("CfaBuf", cfa);
                    glProg.setBufferCompute("LpfBuf", lpf);
                    glProg.setVar("bandSize", bandSize);
                    dispatch(bandSize);

                    glProg.setLayout(8, 8, 1);
                    glProg.useAssetProgram("motionv2/rcd26489_green", true);
                    glProg.setBufferCompute("CfaBuf", cfa);
                    glProg.setBufferCompute("GreenBuf", green);
                    glProg.setBufferCompute("VhBuf", vh);
                    glProg.setBufferCompute("LpfBuf", lpf);
                    glProg.setVar("bandSize", bandSize);
                    glProg.setVar("bandOriginY", bandTop);
                    glProg.setVar("cfaPattern", (int) basePipeline.mParameters.cfaPattern);
                    dispatch(bandSize);

                    glProg.setLayout(8, 8, 1);
                    glProg.useAssetProgram("motionv2/rcd26489_diag_residual", true);
                    glProg.setBufferCompute("CfaBuf", cfa);
                    glProg.setBufferCompute("PBuf", pdiff);
                    glProg.setBufferCompute("QBuf", qdiff);
                    glProg.setVar("bandSize", bandSize);
                    dispatch(bandSize);

                    glProg.setLayout(8, 8, 1);
                    glProg.useAssetProgram("motionv2/rcd26489_diag_direction", true);
                    glProg.setBufferCompute("PBuf", pdiff);
                    glProg.setBufferCompute("QBuf", qdiff);
                    glProg.setBufferCompute("PqBuf", pq);
                    glProg.setVar("bandSize", bandSize);
                    dispatch(bandSize);

                    glProg.setLayout(8, 8, 1);
                    glProg.useAssetProgram("motionv2/rcd26489_opposite", true);
                    glProg.setBufferCompute("RedBuf", red);
                    glProg.setBufferCompute("GreenBuf", green);
                    glProg.setBufferCompute("BlueBuf", blue);
                    glProg.setBufferCompute("PqBuf", pq);
                    glProg.setVar("bandSize", bandSize);
                    glProg.setVar("bandOriginY", bandTop);
                    glProg.setVar("cfaPattern", (int) basePipeline.mParameters.cfaPattern);
                    dispatch(bandSize);

                    glProg.setLayout(8, 8, 1);
                    glProg.useAssetProgram("motionv2/rcd26489_green_rb", true);
                    glProg.setBufferCompute("RedBuf", red);
                    glProg.setBufferCompute("GreenBuf", green);
                    glProg.setBufferCompute("BlueBuf", blue);
                    glProg.setBufferCompute("VhBuf", vh);
                    glProg.setVar("bandSize", bandSize);
                    glProg.setVar("bandOriginY", bandTop);
                    glProg.setVar("cfaPattern", (int) basePipeline.mParameters.cfaPattern);
                    dispatch(bandSize);

                    /* IRIS_26496_RCD_CHROMA_COMPLETION_REUSE
                     * The original nine-pass 26494 RCD directional geometry above is untouched.
                     * After green_rb, vh/lpf/pdiff/qdiff/pq have completed their original jobs,
                     * so reuse those five existing buffers for a two-dispatch missing-chroma
                     * completion. Peak scratch remains exactly nine FLOAT32 band buffers.
                     */
                    glProg.setLayout(8, 8, 1);
                    glProg.useAssetProgram("motionv2/rcd26496_chroma_complete", true);
                    glProg.setTexture("HighlightProvenance",
                            postPipeline.motionV2HighlightProvenanceTexture);
                    glProg.setBufferCompute("RedBuf", red);
                    glProg.setBufferCompute("GreenBuf", green);
                    glProg.setBufferCompute("BlueBuf", blue);
                    glProg.setBufferCompute("AffectedBuf", vh);
                    glProg.setBufferCompute("RedSeedBuf", lpf);
                    glProg.setBufferCompute("RedWeightBuf", pdiff);
                    glProg.setBufferCompute("BlueSeedBuf", qdiff);
                    glProg.setBufferCompute("BlueWeightBuf", pq);
                    glProg.setVar("rawSize", raw);
                    glProg.setVar("bandSize", bandSize);
                    glProg.setVar("bandOriginY", bandTop);
                    glProg.setVar("cfaPattern", (int) basePipeline.mParameters.cfaPattern);
                    glProg.setVar("mode", 0);
                    dispatch(bandSize);
                    glProg.setVar("mode", 1);
                    dispatch(bandSize);

                    glProg.setLayout(8, 8, 1);
                    glProg.useAssetProgram("motionv2/rcd26489_write", true);
                    glProg.setBufferCompute("CfaBuf", cfa);
                    glProg.setBufferCompute("RedBuf", red);
                    glProg.setBufferCompute("GreenBuf", green);
                    glProg.setBufferCompute("BlueBuf", blue);
                    glProg.setTextureCompute("OutputRgb", WorkingTexture, true);
                    glProg.setVar("rawSize", raw);
                    glProg.setVar("bandSize", bandSize);
                    glProg.setVar("bandOriginY", bandTop);
                    glProg.setVar("coreLocalY", coreLocalY);
                    glProg.setVar("coreRows", coreRows);
                    glProg.setVar("cfaPattern", (int) basePipeline.mParameters.cfaPattern);
                    glProg.setVar("calculationWb", wbR, 1.0f, wbB);
                    dispatch(new Point(raw.x, coreRows));
                }
                bands++;
            }
            /* No per-band CPU fence: one GL context owns all nine-pass bands and later post nodes.
             * A barrier is sufficient to publish the last imageStore to downstream GPU consumers. */
            glMemoryBarrier(GL_ALL_BARRIER_BITS);
            glProg.closed = true;
        } finally {
            lsc.close();
        }

        Log.d(Name, "IRIS_26489_POSTMERGE_RCD_DOMAIN"
                + " implementation=bandedDirectionalRcdPlusProvenanceChromaCompletion"
                + " passes=11"
                + " bands=" + bands
                + " haloRows=" + RCD_HALO_ROWS
                + " maxScratchMiB=" + (maxScratchBytes / (1024L * 1024L))
                + " ppg=truePhotoBorderOnly"
                + " temporalRgbSynthesis=false"
                + " calculationWbRemovedAtOutput=true"
                + " explicitHighlightProvenance=true"
                + " original26494DirectionalPassesByteIdentical=true"
                + " censoredChromaCompletion=edgeGuidedNormalizedConvolution"
                + " chromaSeeds=normalOrShortValidatedPhysicalSitesOnly"
                + " weakSupportSmoothlyNeutral=true"
                + " extraFullBandScratchBuffers=0"
                + " reusedScratchBuffers=vh,lpf,pdiff,qdiff,pq"
                + " rcdReclassificationForbidden=true"
                + " neutralCensoredFallback=true"
                + " neutralFallbackUsesTimestampOwnedSensorGains=true"
                + " lensShading=" + hasLsc
                + " oldCrossPhasePlateauActive=false");
        try {
            com.particlesdevs.photoncamera.util.MotionTrace.processingState(
                    "IRIS_26489_POSTMERGE_RCD_DOMAIN",
                    "implementation=bandedDirectionalRcdPlusProvenanceChromaCompletion"
                            + " bands=" + bands
                            + " halo=" + RCD_HALO_ROWS
                            + " maxScratchMiB=" + (maxScratchBytes / (1024L * 1024L))
                            + " ppgBorderOnly=true");
        } catch (Throwable ignored) {}
    }
}
