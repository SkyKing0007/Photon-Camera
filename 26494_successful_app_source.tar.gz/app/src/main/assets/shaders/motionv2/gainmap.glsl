precision highp float;
precision highp int;
precision mediump sampler2D;
uniform sampler2D HdrBuffer;
uniform sampler2D SdrBuffer;
uniform ivec2 gainMapSize;
uniform ivec2 sourceSize;
uniform float hdrExposureScale;
uniform float maxGainRatio;
out vec4 Output;

/* IRIS_26494_MATCHED_FOOTPRINT_UHDR_GAINMAP
 * Each 1/4-resolution gain value represents its exact corresponding 4x4 source
 * footprint. HDR and SDR luminance are integrated first; the ratio is formed once
 * afterward. This is anti-aliased decimation, not a blur of an aliased gain map.
 * SDR remains the sole full-resolution spatial-detail authority.
 */
const float UHDR_OFFSET = 0.015625;
const int FOOTPRINT = 4;
float luminance(vec3 c){return dot(c,vec3(0.2126,0.7152,0.0722));}
float srgbDecode(float x){
    x=clamp(x,0.0,1.0);
    return x<=0.04045?x/12.92:pow((x+0.055)/1.055,2.4);
}
vec3 srgbDecode(vec3 c){return vec3(srgbDecode(c.r),srgbDecode(c.g),srgbDecode(c.b));}
void footprintLuminance(ivec2 gainPixel, out float hdrMean, out float sdrMean) {
    ivec2 base = gainPixel * FOOTPRINT;
    float hdrSum = 0.0;
    float sdrSum = 0.0;
    for (int oy = 0; oy < FOOTPRINT; ++oy) {
        for (int ox = 0; ox < FOOTPRINT; ++ox) {
            ivec2 sp = clamp(base + ivec2(ox, oy), ivec2(0), sourceSize - ivec2(1));
            vec3 hdr = max(texelFetch(HdrBuffer, sp, 0).rgb, vec3(0.0)) * hdrExposureScale;
            vec3 sdr = srgbDecode(texelFetch(SdrBuffer, sp, 0).rgb);
            hdrSum += max(luminance(hdr), 0.0);
            sdrSum += max(luminance(sdr), 0.0);
        }
    }
    hdrMean = hdrSum / float(FOOTPRINT * FOOTPRINT);
    sdrMean = sdrSum / float(FOOTPRINT * FOOTPRINT);
}
void main(){
    ivec2 gp = ivec2(gl_FragCoord.xy);
    if (any(greaterThanEqual(gp, gainMapSize))) {
        Output = vec4(0.0,0.0,0.0,1.0);
        return;
    }
    float hdrMean;
    float sdrMean;
    footprintLuminance(gp, hdrMean, sdrMean);
    float maxLog=max(log2(max(maxGainRatio,1.001)),1.0e-6);
    float ratio=clamp((hdrMean+UHDR_OFFSET)/(sdrMean+UHDR_OFFSET),
            1.0,max(maxGainRatio,1.001));
    float encoded=clamp(log2(ratio)/maxLog,0.0,1.0);
    Output=vec4(encoded,encoded,encoded,1.0);
}
