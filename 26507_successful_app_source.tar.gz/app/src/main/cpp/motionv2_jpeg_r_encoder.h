#pragma once
#include <array>
#include <string>
namespace iris26507 {
struct GainmapMetadata { std::array<float,3> ratioMin,ratioMax,gamma,epsilonSdr,epsilonHdr; float displaySdr=1.f,displayHdr=2.f; bool useBaseColorSpace=true; };
bool packageJpegR(const char* base,const char* gain,const char* out,int gamut,const GainmapMetadata& m,std::string* error);
bool isJpegR(const char* path);
}
