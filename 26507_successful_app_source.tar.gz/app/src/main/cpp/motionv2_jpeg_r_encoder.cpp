#include "motionv2_jpeg_r_encoder.h"
#include <cstdio>
#include <limits>
#include <memory>
#include <vector>
#include <ultrahdr_api.h>
namespace iris26507 { namespace {
struct D{void operator()(uhdr_codec_private_t*p)const{if(p)uhdr_release_encoder(p);}}; using H=std::unique_ptr<uhdr_codec_private_t,D>;
bool readFile(const char*p,std::vector<unsigned char>*d){FILE*f=fopen(p,"rb");if(!f)return false;fseek(f,0,SEEK_END);long n=ftell(f);if(n<=0||fseek(f,0,SEEK_SET)){fclose(f);return false;}d->resize((size_t)n);size_t r=fread(d->data(),1,d->size(),f);int c=fclose(f);return r==d->size()&&c==0;}
bool writeFile(const char*p,const void*d,size_t n){FILE*f=fopen(p,"wb");if(!f)return false;size_t w=fwrite(d,1,n,f);int a=fflush(f),b=fclose(f);return w==n&&a==0&&b==0;}
bool status(const uhdr_error_info_t&s,const char*op,std::string*e){if(s.error_code==UHDR_CODEC_OK)return true;if(e){*e=op;if(s.has_detail&&s.detail[0]){*e+=": ";*e+=s.detail;}}return false;}
uhdr_color_gamut_t gamut(int g){switch(g){case UHDR_CG_BT_709:return UHDR_CG_BT_709;case UHDR_CG_DISPLAY_P3:return UHDR_CG_DISPLAY_P3;case UHDR_CG_BT_2100:return UHDR_CG_BT_2100;default:return UHDR_CG_UNSPECIFIED;}}
}
bool packageJpegR(const char*bp,const char*gp,const char*out,int cg,const GainmapMetadata&m,std::string*e){std::vector<unsigned char>b,g;if(!readFile(bp,&b)||!readFile(gp,&g)){if(e)*e="read JPEG failed";return false;}H h(uhdr_create_encoder());if(!h)return false;uhdr_compressed_image_t base{};base.data=b.data();base.data_sz=base.capacity=b.size();base.cg=gamut(cg);base.ct=UHDR_CT_SRGB;base.range=UHDR_CR_FULL_RANGE;uhdr_compressed_image_t gm{};gm.data=g.data();gm.data_sz=gm.capacity=g.size();gm.cg=UHDR_CG_UNSPECIFIED;gm.ct=UHDR_CT_UNSPECIFIED;gm.range=UHDR_CR_UNSPECIFIED;uhdr_gainmap_metadata_t md{};for(int i=0;i<3;i++){md.min_content_boost[i]=m.ratioMin[i];md.max_content_boost[i]=m.ratioMax[i];md.gamma[i]=m.gamma[i];md.offset_sdr[i]=m.epsilonSdr[i];md.offset_hdr[i]=m.epsilonHdr[i];}md.hdr_capacity_min=m.displaySdr;md.hdr_capacity_max=m.displayHdr;md.use_base_cg=m.useBaseColorSpace?1:0;if(!status(uhdr_enc_set_compressed_image(h.get(),&base,UHDR_BASE_IMG),"set base",e)||!status(uhdr_enc_set_gainmap_image(h.get(),&gm,&md),"set gain",e)||!status(uhdr_enc_set_output_format(h.get(),UHDR_CODEC_JPG),"set output",e)||!status(uhdr_encode(h.get()),"encode",e))return false;auto*enc=uhdr_get_encoded_stream(h.get());return enc&&enc->data&&enc->data_sz>0&&enc->data_sz<=(size_t)std::numeric_limits<int>::max()&&is_uhdr_image(enc->data,(int)enc->data_sz)&&writeFile(out,enc->data,enc->data_sz);}
bool isJpegR(const char*p){std::vector<unsigned char>d;return readFile(p,&d)&&d.size()<=(size_t)std::numeric_limits<int>::max()&&is_uhdr_image(d.data(),(int)d.size());}
}
