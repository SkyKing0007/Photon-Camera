#define LAYOUT //
LAYOUT
precision highp float;
precision highp image2D;
uniform highp sampler2D highlightProvenance;
layout(rgba32f,binding=0) uniform highp writeonly image2D outWeight;
uniform ivec2 packedSize;

/* IRIS_26501_SHORT_VALIDATED_SEMANTIC_PHASE_WEIGHT
 * Preserve the existing Short-A validator phase by phase. Each packed texel stores
 * R/G1/G2/B authority independently; a validated red phase can never authorize a
 * neighbouring green or blue phase. Native short RAW is still the only color source.
 */
float phaseDivisor(int q){return q==0?1.0:(q==1?3.0:(q==2?9.0:27.0));}
float phaseState(ivec2 p,int q){
    p=clamp(p,ivec2(0),packedSize-ivec2(1));
    float code=texelFetch(highlightProvenance,p,0).r;
    return mod(floor(code/phaseDivisor(q)),3.0);
}
bool packedHasCensored(ivec2 p){
    for(int q=0;q<4;++q)if(abs(phaseState(p,q)-1.0)<0.25)return true;
    return false;
}
bool packedHasShortValidated(ivec2 p){
    for(int q=0;q<4;++q)if(abs(phaseState(p,q)-2.0)<0.25)return true;
    return false;
}
float neighborhoodCensoredFraction(ivec2 p){
    float censored=0.0,total=0.0;
    for(int oy=-2;oy<=2;++oy){
        for(int ox=-2;ox<=2;++ox){
            ivec2 q=p+ivec2(ox,oy);
            if(any(lessThan(q,ivec2(0)))||any(greaterThanEqual(q,packedSize)))continue;
            total+=1.0;
            if(packedHasCensored(q))censored+=1.0;
        }
    }
    return total>0.0?censored/total:1.0;
}
void main(){
    ivec2 p=ivec2(gl_GlobalInvocationID.xy);
    if(any(greaterThanEqual(p,packedSize)))return;
    float code=texelFetch(highlightProvenance,p,0).r;
    vec4 weight=vec4(0.0);

    /* IRIS_26506_SHORT_A_SPATIAL_PROVENANCE_COHERENCE
     * A partially measured quad may still use Short-A in the helper Bayer to
     * preserve real luminance/headroom, but it cannot inject isolated RGB/chroma
     * into the semantic accumulator. Fully measured quads retain Short-A color,
     * smoothly reduced only when surrounded by unresolved clipped neighbors.
     * This converts dotted SHORT_VALIDATED/CENSORED islands into coherent color
     * transitions without globally relaxing correspondence or inventing detail.
     */
    if(!packedHasCensored(p)){
        /* IRIS_26507_GPU_LOCAL_8_CONNECTED_SHORT_TOPOLOGY */
        float connectedShortNeighbors=0.0;
        float unresolvedNeighbors=0.0;
        for(int oy=-1;oy<=1;++oy){
            for(int ox=-1;ox<=1;++ox){
                if(ox==0&&oy==0)continue;
                ivec2 q=p+ivec2(ox,oy);
                if(any(lessThan(q,ivec2(0)))||any(greaterThanEqual(q,packedSize)))continue;
                if(packedHasCensored(q))unresolvedNeighbors+=1.0;
                else if(packedHasShortValidated(q))connectedShortNeighbors+=1.0;
            }
        }
        float topologyGate=smoothstep(0.5,2.5,connectedShortNeighbors);
        float unresolvedGate=1.0-smoothstep(2.0,6.0,unresolvedNeighbors);
        float boundaryRisk=smoothstep(
                0.04,0.40,neighborhoodCensoredFraction(p));
        float coherence=(1.0-0.85*boundaryRisk)*topologyGate*unresolvedGate;
        for(int q=0;q<4;++q){
            float state=mod(floor(code/phaseDivisor(q)),3.0);
            weight[q]=abs(state-2.0)<0.25?coherence:0.0;
        }
    }
    imageStore(outWeight,p,weight);
}
