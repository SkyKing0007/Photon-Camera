precision highp float;
precision highp int;

uniform highp sampler2D referenceCfa;
uniform ivec2 rawSize;
uniform ivec2 packedSize;
uniform int cfaPattern;
uniform float wbR;
uniform float wbG;
uniform float wbB;
out vec4 Output;

/* IRIS_26505_LOW_SUPPORT_PPG_REFERENCE
 * Motion-local fallback derived from the edge-directed PPG kernel used by the
 * current bjzhou/darktable RCD path. It reads only the immutable Wronski
 * reference CFA. No alternate unaligned frame, temporal blur or generated RGB
 * is permitted. The final normalizer decides whether this observation is used
 * from true local frame-equivalent support.
 */
const int RED=0;
const int GREEN=1;
const int BLUE=2;

int colorAt(ivec2 p){
    int r=p.y&1,c=p.x&1;
    if(cfaPattern==0){
        if(r==0)return c==0?RED:GREEN;
        return c==0?GREEN:BLUE;
    }else if(cfaPattern==1){
        if(r==0)return c==0?GREEN:RED;
        return c==0?BLUE:GREEN;
    }else if(cfaPattern==2){
        if(r==0)return c==0?GREEN:BLUE;
        return c==0?RED:GREEN;
    }
    if(r==0)return c==0?BLUE:GREEN;
    return c==0?GREEN:RED;
}
float rawAt(ivec2 p){
    p=clamp(p,ivec2(0),rawSize-ivec2(1));
    ivec2 q=clamp(p/2,ivec2(0),packedSize-ivec2(1));
    int phase=((p.y&1)<<1)|(p.x&1);
    return max(texelFetch(referenceCfa,q,0)[phase],0.0);
}
float ppgGreenAt(ivec2 center){
    int ownColor=colorAt(center);
    float pc=rawAt(center);
    if(ownColor==GREEN)return pc;
    float pym=rawAt(center+ivec2(0,-1));
    float pym2=rawAt(center+ivec2(0,-2));
    float pym3=rawAt(center+ivec2(0,-3));
    float pyM=rawAt(center+ivec2(0, 1));
    float pyM2=rawAt(center+ivec2(0, 2));
    float pyM3=rawAt(center+ivec2(0, 3));
    float pxm=rawAt(center+ivec2(-1,0));
    float pxm2=rawAt(center+ivec2(-2,0));
    float pxm3=rawAt(center+ivec2(-3,0));
    float pxM=rawAt(center+ivec2( 1,0));
    float pxM2=rawAt(center+ivec2( 2,0));
    float pxM3=rawAt(center+ivec2( 3,0));
    float guessx=(pxm+pc+pxM)*2.0-pxM2-pxm2;
    float diffx=(abs(pxm2-pc)+abs(pxM2-pc)+abs(pxm-pxM))*3.0
            +(abs(pxM3-pxM)+abs(pxm3-pxm))*2.0;
    float guessy=(pym+pc+pyM)*2.0-pyM2-pym2;
    float diffy=(abs(pym2-pc)+abs(pyM2-pc)+abs(pym-pyM))*3.0
            +(abs(pyM3-pyM)+abs(pym3-pym))*2.0;
    return max(diffx>diffy
            ?clamp(guessy*0.25,min(pym,pyM),max(pym,pyM))
            :clamp(guessx*0.25,min(pxm,pxM),max(pxm,pxM)),0.0);
}
vec3 ppgColorAt(ivec2 center){
    int ownColor=colorAt(center);
    float pc=rawAt(center);
    float green=ppgGreenAt(center);
    vec3 color=vec3(0.0,green,0.0);
    if(ownColor==RED||ownColor==BLUE){
        ivec2 nw=center+ivec2(-1,-1),ne=center+ivec2(1,-1);
        ivec2 sw=center+ivec2(-1, 1),se=center+ivec2(1, 1);
        float diff1=abs(rawAt(nw)-rawAt(se))
                +abs(ppgGreenAt(nw)-green)+abs(ppgGreenAt(se)-green);
        float guess1=rawAt(nw)+rawAt(se)+2.0*green
                -ppgGreenAt(nw)-ppgGreenAt(se);
        float diff2=abs(rawAt(ne)-rawAt(sw))
                +abs(ppgGreenAt(ne)-green)+abs(ppgGreenAt(sw)-green);
        float guess2=rawAt(ne)+rawAt(sw)+2.0*green
                -ppgGreenAt(ne)-ppgGreenAt(sw);
        float other=diff1>diff2?guess2*0.5:(diff1<diff2?guess1*0.5:(guess1+guess2)*0.25);
        if(ownColor==RED){color.r=pc;color.b=other;}
        else{color.b=pc;color.r=other;}
    }else{
        color.g=pc;
        if(colorAt(center+ivec2(1,0))==RED){
            color.b=(rawAt(center+ivec2(0,-1))+rawAt(center+ivec2(0,1))
                    +2.0*color.g-ppgGreenAt(center+ivec2(0,-1))
                    -ppgGreenAt(center+ivec2(0,1)))*0.5;
            color.r=(rawAt(center+ivec2(-1,0))+rawAt(center+ivec2(1,0))
                    +2.0*color.g-ppgGreenAt(center+ivec2(-1,0))
                    -ppgGreenAt(center+ivec2(1,0)))*0.5;
        }else{
            color.r=(rawAt(center+ivec2(0,-1))+rawAt(center+ivec2(0,1))
                    +2.0*color.g-ppgGreenAt(center+ivec2(0,-1))
                    -ppgGreenAt(center+ivec2(0,1)))*0.5;
            color.b=(rawAt(center+ivec2(-1,0))+rawAt(center+ivec2(1,0))
                    +2.0*color.g-ppgGreenAt(center+ivec2(-1,0))
                    -ppgGreenAt(center+ivec2(1,0)))*0.5;
        }
    }
    return max(color,vec3(0.0));
}
void main(){
    ivec2 p=ivec2(gl_FragCoord.xy);
    if(any(greaterThanEqual(p,rawSize))){Output=vec4(0.0);return;}
    vec3 sensorRgb=ppgColorAt(p);
    vec3 calculationRgb=sensorRgb*max(vec3(wbR,wbG,wbB),vec3(1.0e-6));
    Output=vec4(max(calculationRgb,vec3(0.0)),1.0);
}
