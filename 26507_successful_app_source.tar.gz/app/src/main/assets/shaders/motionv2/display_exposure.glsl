precision highp float;
precision mediump sampler2D;

uniform sampler2D InputBuffer;
uniform float displayGain;
uniform float shadowRecoveryStrength;
uniform float shadowFloorStop;
uniform float retainedFrames;
out vec3 Output;

/* IRIS_26504_PIXEL_LOCAL_EFFECTIVE_STACK_PERMISSION */
float luminance(vec3 c){
    return dot(c,vec3(0.2126,0.7152,0.0722));
}
vec3 recoverSupportedShadow(
        vec3 displayed,vec3 sensorRgb,float localFrameSupport){
    displayed=max(displayed,vec3(0.0));
    sensorRgb=max(sensorRgb,vec3(0.0));
    float sensorY=max(luminance(sensorRgb),0.0);
    float displayedY=max(luminance(displayed),0.0);
    if(sensorY<=1.0e-8||shadowRecoveryStrength<=0.0)return displayed;

    float floorWidth=max(0.006,1.5*shadowFloorStop);
    float floorGate=smoothstep(
            shadowFloorStop,shadowFloorStop+floorWidth,sensorY);
    float shadowGate=1.0-smoothstep(0.12,0.30,displayedY);

    float frameDenom=max(retainedFrames-1.0,1.0);
    float localRatio=clamp(
            (max(localFrameSupport,1.0)-1.0)/frameDenom,0.0,1.0);
    float localDepth=smoothstep(
            1.5,8.0,max(localFrameSupport,1.0));
    float localPermission=localRatio*(0.30+0.70*localDepth);

    float scale=1.0+clamp(shadowRecoveryStrength,0.0,0.10)
            *floorGate*shadowGate*localPermission;
    return displayed*scale;
}
void main(){
    ivec2 p=ivec2(gl_FragCoord.xy);
    vec4 carrier=max(texelFetch(InputBuffer,p,0),vec4(0.0));
    vec3 c=carrier.rgb;
    vec3 displayed=c*max(displayGain,1.0);
    Output=recoverSupportedShadow(displayed,c,carrier.a);
}
