precision highp float;
precision highp int;

uniform highp sampler2D semanticAccumulator;
uniform highp sampler2D opponentWeightAccumulator;
uniform highp sampler2D fallbackCfa;
uniform highp sampler2D highlightProvenance;
uniform highp sampler2D lensShadingMap;
uniform highp sampler2D frameSupportTexture;
uniform highp sampler2D lowSupportReferenceRgb;
uniform ivec2 rawSize;
uniform ivec2 packedSize;
uniform vec3 cameraDomainScale;
uniform vec3 noiseShotRgb;
uniform vec3 noiseReadRgb;
uniform int useLensShading;
out vec4 Output;

/* IRIS_26504_QUAD_COHERENT_HIGHLIGHT_AUTHORITY
 * The physical trust unit is the exact parent 2x2 Bayer quad. NORMAL (0) and
 * SHORT_VALIDATED (2) are known observations; CENSORED (1) is unknown.
 */
const float SUPPORT_EPS=1.0e-7;
float phaseDivisor(int q){return q==0?1.0:(q==1?3.0:(q==2?9.0:27.0));}
float phaseState(ivec2 packedP,int q){
    packedP=clamp(packedP,ivec2(0),packedSize-ivec2(1));
    float code=texelFetch(highlightProvenance,packedP,0).r;
    return mod(floor(code/phaseDivisor(q)),3.0);
}
bool packedHasCensored(ivec2 packedP){
    for(int q=0;q<4;++q){
        if(abs(phaseState(packedP,q)-1.0)<0.25)return true;
    }
    return false;
}
bool packedHasShortValidated(ivec2 packedP){
    for(int q=0;q<4;++q){
        if(abs(phaseState(packedP,q)-2.0)<0.25)return true;
    }
    return false;
}
bool expandedCensoredDecision(ivec2 packedP){
    for(int oy=-1;oy<=1;++oy){
        for(int ox=-1;ox<=1;++ox){
            ivec2 q=clamp(packedP+ivec2(ox,oy),ivec2(0),packedSize-ivec2(1));
            if(packedHasCensored(q))return true;
        }
    }
    return false;
}
float packedNeutralAt(ivec2 packedP){
    packedP=clamp(packedP,ivec2(0),packedSize-ivec2(1));
    vec4 v=max(texelFetch(fallbackCfa,packedP,0),vec4(0.0));
    return max(max(v.r,v.g),max(v.b,v.a));
}
float neutralFallback(ivec2 rawP){
    vec2 packedPosition=(vec2(rawP)+vec2(0.5))*0.5-vec2(0.25);
    vec2 p=packedPosition-vec2(0.5);
    ivec2 lo=ivec2(floor(p));
    vec2 f=fract(p);
    ivec2 hi=lo+ivec2(1);
    float a=packedNeutralAt(lo);
    float b=packedNeutralAt(ivec2(hi.x,lo.y));
    float c=packedNeutralAt(ivec2(lo.x,hi.y));
    float d=packedNeutralAt(hi);
    return mix(mix(a,b,f.x),mix(c,d,f.x),f.y);
}
vec3 lensShadingRgb(ivec2 rawP){
    if(useLensShading==0)return vec3(1.0);
    vec2 uv=(vec2(rawP)+vec2(0.5))/vec2(rawSize);
    vec4 g=texture(lensShadingMap,clamp(uv,vec2(0.0),vec2(1.0)));
    return max(vec3(g.r,0.5*(g.g+g.b),g.a),vec3(0.0));
}
float opponentSupportQuality(float greenWeight,float opponentWeight){
    if(greenWeight<=SUPPORT_EPS||opponentWeight<=SUPPORT_EPS)return 0.0;
    return clamp(opponentWeight/max(0.30*greenWeight,SUPPORT_EPS),0.0,1.0);
}
void accumulateNeighborOpponent(
        ivec2 q,float centerGreen,float spatialWeight,
        inout vec2 opponentSums,inout vec2 neighborWeightSums){
    if(any(lessThan(q,ivec2(0)))||any(greaterThanEqual(q,rawSize)))return;
    vec4 neighborSemantic=texelFetch(semanticAccumulator,q,0);
    vec2 neighborOpponentWeight=texelFetch(opponentWeightAccumulator,q,0).rg;
    if(neighborSemantic.a<=SUPPORT_EPS)return;
    float neighborGreen=neighborSemantic.r/neighborSemantic.a;
    float sigma=max(0.004,0.035*max(centerGreen,0.02));
    float z=(neighborGreen-centerGreen)/sigma;
    float edgeWeight=exp(-0.5*z*z)*spatialWeight;
    if(neighborOpponentWeight.r>SUPPORT_EPS){
        float qualityR=opponentSupportQuality(
                neighborSemantic.a,neighborOpponentWeight.r);
        float wR=edgeWeight*qualityR;
        opponentSums.r+=(neighborSemantic.g/neighborOpponentWeight.r)*wR;
        neighborWeightSums.r+=wR;
    }
    if(neighborOpponentWeight.g>SUPPORT_EPS){
        float qualityB=opponentSupportQuality(
                neighborSemantic.a,neighborOpponentWeight.g);
        float wB=edgeWeight*qualityB;
        opponentSums.g+=(neighborSemantic.b/neighborOpponentWeight.g)*wB;
        neighborWeightSums.g+=wB;
    }
}
float opponentAgreement(
        float centerOpponent,float localOpponent,float green,float centerQuality){
    float threshold=max(0.010,0.25*max(green,0.02));
    float chromaEdge=smoothstep(
            threshold,2.5*threshold,abs(centerOpponent-localOpponent));
    return 1.0-centerQuality*chromaEdge;
}
float localEvidenceQuality(float neighborWeightSum){
    return smoothstep(0.25,1.75,neighborWeightSum);
}
float frameSupportAt(ivec2 q){
    q=clamp(q,ivec2(0),rawSize-ivec2(1));
    return max(texelFetch(frameSupportTexture,q,0).r,1.0);
}
float localSupportDiscontinuity(ivec2 p,float centerSupport){
    float jump=0.0;
    jump=max(jump,abs(frameSupportAt(p+ivec2(-1, 0))-centerSupport));
    jump=max(jump,abs(frameSupportAt(p+ivec2( 1, 0))-centerSupport));
    jump=max(jump,abs(frameSupportAt(p+ivec2( 0,-1))-centerSupport));
    jump=max(jump,abs(frameSupportAt(p+ivec2( 0, 1))-centerSupport));
    jump=max(jump,abs(frameSupportAt(p+ivec2(-1,-1))-centerSupport));
    jump=max(jump,abs(frameSupportAt(p+ivec2( 1,-1))-centerSupport));
    jump=max(jump,abs(frameSupportAt(p+ivec2(-1, 1))-centerSupport));
    jump=max(jump,abs(frameSupportAt(p+ivec2( 1, 1))-centerSupport));
    return jump;
}
float residualOpponentKeep(
        float opponent,float signalA,float signalB,
        float shotA,float readA,float shotB,float readB,
        float localFrameSupport,float darkGate){
    float n=max(localFrameSupport,1.0);
    float varA=max(shotA*max(signalA,0.0)+readA,0.0)/n;
    float varB=max(shotB*max(signalB,0.0)+readB,0.0)/n;
    float sigma=sqrt(max(varA+varB,1.0e-10));
    float z=abs(opponent)/max(sigma,1.0e-6);
    float noiseLike=1.0-smoothstep(1.50,3.25,z);
    return 1.0-0.82*darkGate*noiseLike;
}
void main(){
    ivec2 p=ivec2(gl_FragCoord.xy);
    if(any(greaterThanEqual(p,rawSize))){Output=vec4(0.0);return;}

    vec4 semantic=texelFetch(semanticAccumulator,p,0);
    vec4 opponentWeights=texelFetch(opponentWeightAccumulator,p,0);
    float gWeight=semantic.a;
    float rWeight=opponentWeights.r;
    float bWeight=opponentWeights.g;
    float green=gWeight>SUPPORT_EPS?semantic.r/gWeight:0.0;
    bool centerRPresent=rWeight>SUPPORT_EPS;
    bool centerBPresent=bWeight>SUPPORT_EPS;
    float centerRg=centerRPresent?semantic.g/rWeight:0.0;
    float centerBg=centerBPresent?semantic.b/bWeight:0.0;
    float centerQr=opponentSupportQuality(gWeight,rWeight);
    float centerQb=opponentSupportQuality(gWeight,bWeight);

    vec2 opponentSums=vec2(0.0);
    vec2 neighborWeightSums=vec2(0.0);
    accumulateNeighborOpponent(p+ivec2(-1, 0),green,1.0,opponentSums,neighborWeightSums);
    accumulateNeighborOpponent(p+ivec2( 1, 0),green,1.0,opponentSums,neighborWeightSums);
    accumulateNeighborOpponent(p+ivec2( 0,-1),green,1.0,opponentSums,neighborWeightSums);
    accumulateNeighborOpponent(p+ivec2( 0, 1),green,1.0,opponentSums,neighborWeightSums);
    accumulateNeighborOpponent(p+ivec2(-1,-1),green,0.70710678,opponentSums,neighborWeightSums);
    accumulateNeighborOpponent(p+ivec2( 1,-1),green,0.70710678,opponentSums,neighborWeightSums);
    accumulateNeighborOpponent(p+ivec2(-1, 1),green,0.70710678,opponentSums,neighborWeightSums);
    accumulateNeighborOpponent(p+ivec2( 1, 1),green,0.70710678,opponentSums,neighborWeightSums);

    bool localRPresent=neighborWeightSums.r>SUPPORT_EPS;
    bool localBPresent=neighborWeightSums.g>SUPPORT_EPS;
    float localRg=localRPresent
            ?opponentSums.r/neighborWeightSums.r:centerRg;
    float localBg=localBPresent
            ?opponentSums.g/neighborWeightSums.g:centerBg;
    float localQr=localEvidenceQuality(neighborWeightSums.r);
    float localQb=localEvidenceQuality(neighborWeightSums.g);

    float neutral=neutralFallback(p);
    float physicalHighlight=max(max(green,neutral),0.0);
    float darkGate=1.0-smoothstep(0.018,0.085,max(green,0.0));

    float rAgreement=opponentAgreement(centerRg,localRg,green,centerQr);
    float bAgreement=opponentAgreement(centerBg,localBg,green,centerQb);
    float rShadowBlend=darkGate*mix(0.70,0.38,centerQr)
            *rAgreement*localQr;
    float bShadowBlend=darkGate*mix(0.70,0.38,centerQb)
            *bAgreement*localQb;
    float rg=centerRPresent
            ?mix(centerRg,localRg,
                    localRPresent?clamp(rShadowBlend,0.0,1.0):0.0)
            :(localRPresent?localRg:0.0);
    float bg=centerBPresent
            ?mix(centerBg,localBg,
                    localBPresent?clamp(bShadowBlend,0.0,1.0):0.0)
            :(localBPresent?localBg:0.0);

    /* IRIS_26504_NOISE_AWARE_OPPONENT_SANITY */
    float localFrameSupport=max(
            texelFetch(frameSupportTexture,p,0).r,1.0);
    float rSignal=max(green+rg,0.0);
    float bSignal=max(green+bg,0.0);
    rg*=residualOpponentKeep(
            rg,rSignal,green,
            noiseShotRgb.r,noiseReadRgb.r,
            noiseShotRgb.g,noiseReadRgb.g,
            localFrameSupport,darkGate);
    bg*=residualOpponentKeep(
            bg,bSignal,green,
            noiseShotRgb.b,noiseReadRgb.b,
            noiseShotRgb.g,noiseReadRgb.g,
            localFrameSupport,darkGate);

    /* IRIS_26506_OPPONENT_CONFIDENCE_REFERENCE_CHROMA
     * Nominal frame count is not color confidence: windy foliage can retain
     * several effective frames while accepted frames disagree in R-G/B-G. Keep
     * temporal green/luminance detail and replace only an unreliable opponent
     * channel with the deterministic immutable-reference CFA reconstruction.
     */
    vec3 lowSupportReference=max(
            texelFetch(lowSupportReferenceRgb,p,0).rgb,vec3(0.0));
    float referenceRg=lowSupportReference.r-lowSupportReference.g;
    float referenceBg=lowSupportReference.b-lowSupportReference.g;
    float lowSupportAuthority=1.0-smoothstep(
            1.50,3.50,max(localFrameSupport,1.0));

    float supportJump=localSupportDiscontinuity(p,localFrameSupport);
    float supportTransitionRisk=smoothstep(1.0,4.0,supportJump)
            *(1.0-smoothstep(8.0,12.0,localFrameSupport));
    float rEvidenceConfidence=clamp(
            centerQr*mix(0.55,1.0,localQr)*rAgreement,0.0,1.0);
    float bEvidenceConfidence=clamp(
            centerQb*mix(0.55,1.0,localQb)*bAgreement,0.0,1.0);
    float rChromaRisk=1.0-smoothstep(0.35,0.75,rEvidenceConfidence);
    float bChromaRisk=1.0-smoothstep(0.35,0.75,bEvidenceConfidence);

    ivec2 parentPacked=clamp(p/2,ivec2(0),packedSize-ivec2(1));
    /* IRIS_26507_NO_STALE_SHORT_CHROMA_IMMUNITY */
    float genericChromaPermission=1.0;
    float effectiveLowSupportAuthority=lowSupportAuthority*genericChromaPermission;
    float rReferenceChromaAuthority=max(
            effectiveLowSupportAuthority,
            0.85*supportTransitionRisk*rChromaRisk*genericChromaPermission);
    float bReferenceChromaAuthority=max(
            effectiveLowSupportAuthority,
            0.85*supportTransitionRisk*bChromaRisk*genericChromaPermission);
    rg=mix(rg,referenceRg,clamp(rReferenceChromaAuthority,0.0,1.0));
    bg=mix(bg,referenceBg,clamp(bReferenceChromaAuthority,0.0,1.0));

    vec3 calculationRgb=max(
            vec3(green+rg,green,green+bg),vec3(0.0));
    calculationRgb=mix(
            calculationRgb,lowSupportReference,
            clamp(effectiveLowSupportAuthority,0.0,1.0));

    /* IRIS_26504_POST_LSC_CHROMA_EXHAUSTION */
    vec3 lsc=lensShadingRgb(p);
    calculationRgb*=lsc;

    bool expandedIncomplete=expandedCensoredDecision(parentPacked);
    float physicalHighlightGate=smoothstep(0.45,0.72,physicalHighlight);
    bool colorIncomplete=physicalHighlightGate>0.001&&expandedIncomplete;

    if(colorIncomplete||gWeight<=SUPPORT_EPS){
        float stableNeutral=max(
                calculationRgb.g,
                max(neutral,green)*max(lsc.g,0.0));
        calculationRgb=vec3(max(stableNeutral,0.0));
    }

    vec3 cameraRgb=calculationRgb*cameraDomainScale;

    /* IRIS_26504_LOCAL_FRAME_EQUIVALENT_SUPPORT_CARRIER */
    Output=vec4(
            max(cameraRgb,vec3(0.0)),
            min(localFrameSupport,65504.0));
}
