#define LAYOUT //
LAYOUT
precision highp float;
precision highp int;
precision highp image2D;

uniform highp sampler2D normalCfa;
/* IRIS_26498_V13_REFERENCE_CFA_CORRESPONDENCE_AUTHORITY */
uniform highp sampler2D referenceCfa;
uniform highp sampler2D shortCfa;
uniform highp sampler2D flowTexture;
layout(rgba32f, binding = 0) uniform highp writeonly image2D outCfa;
layout(r32f, binding = 1) uniform highp writeonly image2D outProvenance;
layout(std430, binding = 2) buffer ShortDiagBuf {
    uint shortDiag[];
};
uniform ivec2 packedSize;
uniform float referenceExposureScale;
uniform float shortToNormalScale;
uniform float physicalClipThreshold;
uniform float shortClipThreshold;
uniform float minimumFlowConfidence;

const float PROVENANCE_NORMAL = 0.0;
const float PROVENANCE_CENSORED = 1.0;
const float PROVENANCE_SHORT_VALIDATED = 2.0;

const uint D_TOTAL_CLIPPED = 0u;
const uint D_SHORT_SAFE = 1u;
const uint D_SHORT_CLIPPED = 2u;
const uint D_FLOW_REJECT = 3u;
const uint D_CORR_REJECT = 4u;
const uint D_RADIOMETRY_REJECT = 5u;
const uint D_VALIDATED = 6u;
const uint D_STILL_CENSORED = 7u;
const uint D_BIN_LT50 = 8u;
const uint D_BIN_50_70 = 9u;
const uint D_BIN_70_85 = 10u;
const uint D_BIN_85_95 = 11u;
const uint D_BIN_95_CLIP = 12u;
const uint D_PHASE_TOTAL = 16u;
const uint D_PHASE_VALIDATED = 20u;
const uint D_PHASE_SHORT_CLIPPED = 24u;
const uint D_PHASE_FLOW_REJECT = 28u;
const uint D_PHASE_CORR_REJECT = 32u;
const uint D_PHASE_RADIOMETRY_REJECT = 36u;
const uint D_PHASE_STILL_CENSORED = 40u;
/* IRIS_26506_SHORT_A_PACK_COHERENCE_DIAGNOSTICS */
const uint D_PACK_SHORT_ANY = 44u;
const uint D_PACK_SHORT_MIXED_CENSORED = 45u;
const uint D_PACK_SHORT_FULLY_KNOWN = 46u;

void addMask(uint totalIndex, uint phaseBase, vec4 mask) {
    for (int i = 0; i < 4; ++i) {
        if (mask[i] > 0.5) {
            atomicAdd(shortDiag[totalIndex], 1u);
            atomicAdd(shortDiag[phaseBase + uint(i)], 1u);
        }
    }
}
void addTotalOnly(uint index, vec4 mask) {
    for (int i = 0; i < 4; ++i) if (mask[i] > 0.5) atomicAdd(shortDiag[index], 1u);
}
void classifyShortSamples(vec4 shortCenter, vec4 clipMask) {
    for (int i = 0; i < 4; ++i) {
        if (clipMask[i] <= 0.5) continue;
        float v = shortCenter[i];
        if (v >= shortClipThreshold) continue;
        if (v < 0.50) atomicAdd(shortDiag[D_BIN_LT50], 1u);
        else if (v < 0.70) atomicAdd(shortDiag[D_BIN_50_70], 1u);
        else if (v < 0.85) atomicAdd(shortDiag[D_BIN_70_85], 1u);
        else if (v < 0.95) atomicAdd(shortDiag[D_BIN_85_95], 1u);
        else atomicAdd(shortDiag[D_BIN_95_CLIP], 1u);
    }
}

float sum4(vec4 v) { return dot(v, vec4(1.0)); }
float encodePhaseStates(vec4 s) { return dot(s, vec4(1.0, 3.0, 9.0, 27.0)); }

vec4 phaseSafeBilinear(vec2 packedCenter) {
    vec2 p = packedCenter - vec2(0.5);
    ivec2 lo = ivec2(floor(p));
    vec2 f = fract(p);
    ivec2 maxP = packedSize - ivec2(1);
    ivec2 p00 = clamp(lo, ivec2(0), maxP);
    ivec2 p10 = clamp(lo + ivec2(1,0), ivec2(0), maxP);
    ivec2 p01 = clamp(lo + ivec2(0,1), ivec2(0), maxP);
    ivec2 p11 = clamp(lo + ivec2(1,1), ivec2(0), maxP);
    vec4 a = texelFetch(shortCfa, p00, 0);
    vec4 b = texelFetch(shortCfa, p10, 0);
    vec4 c = texelFetch(shortCfa, p01, 0);
    vec4 d = texelFetch(shortCfa, p11, 0);
    return mix(mix(a,b,f.x), mix(c,d,f.x), f.y);
}
vec4 shortSafe(vec4 v) { return vec4(1.0) - step(vec4(shortClipThreshold), v); }
vec4 normalSafe(vec4 v) { return vec4(1.0) - step(vec4(0.90), v); }

/* IRIS_26497_SHORT_CORRESPONDENCE_REFINEMENT
 * mfsr_flow_expand.w means interpolation was cancelled and the whole base tile
 * vector was preserved. It does NOT mean the base vector is invalid. 26496
 * incorrectly converted that safe fallback into zero highlight evidence.
 *
 * For clipped sites, refine the predicted short-frame correspondence locally on
 * unsaturated physical CFA evidence. Structured regions require a unique best
 * match. Smooth regions may be accepted only with tighter radiometric agreement,
 * where a subpixel ambiguity cannot create an edge/color displacement.
 */
void evaluateCorrespondence(
        ivec2 p, vec2 source, out float meanRelativeError,
        out float structure, out float supportCount) {
    float errorSum = 0.0;
    supportCount = 0.0;
    float lumaMin = 1.0e20;
    float lumaMax = 0.0;
    float lumaSum = 0.0;
    float lumaCount = 0.0;
    ivec2 maxP = packedSize - ivec2(1);
    for (int oy = -2; oy <= 2; ++oy) {
        for (int ox = -2; ox <= 2; ++ox) {
            if (max(abs(ox), abs(oy)) != 2) continue;
            ivec2 q = p + ivec2(ox, oy);
            if (any(lessThan(q, ivec2(0))) || any(greaterThan(q, maxP))) continue;
            vec2 qs = source + vec2(float(ox), float(oy));
            if (qs.x < 0.0 || qs.y < 0.0 ||
                    qs.x >= float(packedSize.x) || qs.y >= float(packedSize.y)) continue;
            vec4 nSensor = texelFetch(referenceCfa, q, 0) /
                    max(referenceExposureScale, 1.0e-6);
            vec4 sRaw = phaseSafeBilinear(qs);
            vec4 mask = normalSafe(nSensor) * shortSafe(sRaw) *
                    step(vec4(0.010001), nSensor);
            float count = sum4(mask);
            if (count < 1.5) continue;
            vec4 sEquivalent = sRaw * shortToNormalScale;
            vec4 rel = abs(nSensor - sEquivalent) / max(nSensor, vec4(0.04));
            errorSum += dot(rel, mask);
            supportCount += count;
            float luma = dot(nSensor, vec4(0.25));
            lumaMin = min(lumaMin, luma);
            lumaMax = max(lumaMax, luma);
            lumaSum += luma;
            lumaCount += 1.0;
        }
    }
    meanRelativeError = supportCount > 0.0 ? errorSum / supportCount : 1.0e20;
    float lumaMean = lumaCount > 0.0 ? lumaSum / lumaCount : 0.0;
    structure = lumaCount >= 4.0
            ? (lumaMax - lumaMin) / max(lumaMean, 0.03)
            : 0.0;
}

/* IRIS_26503_BOUNDARY_ANCHORED_SHORT_OBSERVABILITY
 * Keep the proven 26502 radius-2 structured/smooth test as Tier 1.  The only
 * new authority is a conservative Tier-2 fallback for the specific case where
 * Tier 1 has too little unsaturated reference support to decide at all.
 *
 * Tier 2 never overrides a local mismatch/ambiguity.  It samples sparse, wider
 * reference-owned anchors at the already-predicted Wronski displacement, requires
 * strong flow coherence, multi-direction support including an opposing pair,
 * tight exposure-normalized radiometry, and zero strong contradictory anchors.
 * The clipped center still cannot certify itself and no new displacement search is
 * invented.  If these conditions fail, output/provenance remain exactly 26502.
 */
ivec2 boundaryDirectionOffset(int direction, int radius) {
    int halfRadius = max(radius / 2, 1);
    if (direction == 0) return ivec2(-radius, 0);
    if (direction == 1) return ivec2( radius, 0);
    if (direction == 2) return ivec2(0, -radius);
    if (direction == 3) return ivec2(0,  radius);
    if (direction == 4) return ivec2(-radius, -radius);
    if (direction == 5) return ivec2( radius,  radius);
    if (direction == 6) return ivec2( radius, -radius);
    if (direction == 7) return ivec2(-radius,  radius);
    if (direction == 8) return ivec2(-halfRadius, -radius);
    if (direction == 9) return ivec2( halfRadius,  radius);
    if (direction == 10) return ivec2( halfRadius, -radius);
    if (direction == 11) return ivec2(-halfRadius,  radius);
    if (direction == 12) return ivec2(-radius, -halfRadius);
    if (direction == 13) return ivec2( radius,  halfRadius);
    if (direction == 14) return ivec2( radius, -halfRadius);
    return ivec2(-radius, halfRadius);
}

bool validateBoundaryAnchoredCorrespondence(
        ivec2 p, vec2 predicted, float flowConfidence,
        out float meanRelativeError, out float supportCount) {
    meanRelativeError = 1.0e20;
    supportCount = 0.0;

    /* Wider authority is deliberately stricter than ordinary Short-A flow use. */
    if (flowConfidence < max(minimumFlowConfidence, 0.85)) return false;

    /* If any center phases remain physically measurable, they are a direct guard
     * against shifting Short-A color across an object boundary.  Only non-clipped,
     * non-dark center phases participate; truly exhausted centers are not guessed. */
    vec4 centerNormal = texelFetch(normalCfa, p, 0) /
            max(referenceExposureScale, 1.0e-6);
    vec4 centerClipMask = step(vec4(physicalClipThreshold), centerNormal);
    vec4 centerShort = phaseSafeBilinear(predicted);
    vec4 centerUsable = (vec4(1.0) - centerClipMask) * normalSafe(centerNormal) *
            shortSafe(centerShort) * step(vec4(0.010001), centerNormal);
    float centerCount = sum4(centerUsable);
    if (centerCount > 0.5) {
        vec4 centerEquivalent = centerShort * shortToNormalScale;
        vec4 centerRel = abs(centerNormal - centerEquivalent) /
                max(centerNormal, vec4(0.04));
        float centerError = dot(centerRel, centerUsable) / centerCount;
        if (centerError > 0.070) return false;
    }

    float errorSum = 0.0;
    float acceptedAnchors = 0.0;
    float strongConflicts = 0.0;
    float seen0 = 0.0, seen1 = 0.0, seen2 = 0.0, seen3 = 0.0;
    float seen4 = 0.0, seen5 = 0.0, seen6 = 0.0, seen7 = 0.0;
    float seen8 = 0.0, seen9 = 0.0, seen10 = 0.0, seen11 = 0.0;
    float seen12 = 0.0, seen13 = 0.0, seen14 = 0.0, seen15 = 0.0;
    ivec2 maxP = packedSize - ivec2(1);

    /* Search outward independently on sixteen spokes.  The FIRST observable
     * unsaturated anchor on a spoke owns that spoke; we never skip nearby
     * contradictory/ambiguous evidence to borrow agreement from a farther object.
     * The half-axis spokes catch sub-radius color/edge displacement that eight
     * cardinal/diagonal anchors alone can miss.  4/8/16/32/64 packed pixels reach
     * 8..128 native RAW pixels while evaluating at most eighty sparse anchors. */
    for (int direction = 0; direction < 16; ++direction) {
        for (int ring = 0; ring < 5; ++ring) {
            int radius = ring == 0 ? 4 : (ring == 1 ? 8 :
                    (ring == 2 ? 16 : (ring == 3 ? 32 : 64)));
            ivec2 offset = boundaryDirectionOffset(direction, radius);
            ivec2 q = p + offset;
            if (any(lessThan(q, ivec2(0))) || any(greaterThan(q, maxP))) continue;
            vec2 qs = predicted + vec2(float(offset.x), float(offset.y));
            if (qs.x < 0.0 || qs.y < 0.0 ||
                    qs.x >= float(packedSize.x) || qs.y >= float(packedSize.y)) continue;

            vec4 nSensor = texelFetch(referenceCfa, q, 0) /
                    max(referenceExposureScale, 1.0e-6);
            vec4 sRaw = phaseSafeBilinear(qs);
            vec4 mask = normalSafe(nSensor) * shortSafe(sRaw) *
                    step(vec4(0.010001), nSensor);
            float count = sum4(mask);
            if (count < 1.5) continue;

            vec4 sEquivalent = sRaw * shortToNormalScale;
            vec4 rel = abs(nSensor - sEquivalent) / max(nSensor, vec4(0.04));
            float anchorError = dot(rel, mask) / count;

            /* First observable boundary on this spoke is decisive. */
            if (anchorError > 0.12) {
                strongConflicts += 1.0;
                break;
            }
            if (anchorError <= 0.055) {
                acceptedAnchors += 1.0;
                supportCount += count;
                errorSum += anchorError * count;
                if (direction == 0) seen0 = 1.0;
                else if (direction == 1) seen1 = 1.0;
                else if (direction == 2) seen2 = 1.0;
                else if (direction == 3) seen3 = 1.0;
                else if (direction == 4) seen4 = 1.0;
                else if (direction == 5) seen5 = 1.0;
                else if (direction == 6) seen6 = 1.0;
                else if (direction == 7) seen7 = 1.0;
                else if (direction == 8) seen8 = 1.0;
                else if (direction == 9) seen9 = 1.0;
                else if (direction == 10) seen10 = 1.0;
                else if (direction == 11) seen11 = 1.0;
                else if (direction == 12) seen12 = 1.0;
                else if (direction == 13) seen13 = 1.0;
                else if (direction == 14) seen14 = 1.0;
                else seen15 = 1.0;
            }
            /* 0.055..0.12 is ambiguous: do not accept and do not look past it. */
            break;
        }
    }

    if (supportCount > 0.0) meanRelativeError = errorSum / supportCount;
    float directionCount = seen0 + seen1 + seen2 + seen3 + seen4 + seen5 +
            seen6 + seen7 + seen8 + seen9 + seen10 + seen11 + seen12 +
            seen13 + seen14 + seen15;
    float opposingPairs =
            (seen0 * seen1 > 0.5 ? 1.0 : 0.0) +
            (seen2 * seen3 > 0.5 ? 1.0 : 0.0) +
            (seen4 * seen5 > 0.5 ? 1.0 : 0.0) +
            (seen6 * seen7 > 0.5 ? 1.0 : 0.0) +
            (seen8 * seen9 > 0.5 ? 1.0 : 0.0) +
            (seen10 * seen11 > 0.5 ? 1.0 : 0.0) +
            (seen12 * seen13 > 0.5 ? 1.0 : 0.0) +
            (seen14 * seen15 > 0.5 ? 1.0 : 0.0);

    /* All-four-phase clipping has no surviving center color guard, so demand a
     * wider geometric proof than partial clipping.  Partial clipping keeps its
     * measured normal phases and therefore needs fewer boundary spokes. */
    bool allCenterPhasesClipped = sum4(centerClipMask) > 3.5;
    float requiredDirections = allCenterPhasesClipped ? 6.0 : 4.0;
    float requiredPairs = allCenterPhasesClipped ? 2.0 : 1.0;
    float requiredSupport = allCenterPhasesClipped ? 18.0 : 12.0;

    return strongConflicts < 0.5 &&
            acceptedAnchors >= requiredDirections &&
            directionCount >= requiredDirections && opposingPairs >= requiredPairs &&
            supportCount >= requiredSupport && meanRelativeError <= 0.045;
}

bool refineObservableCorrespondence(
        ivec2 p, vec2 predicted, float flowConfidence, out vec2 refined,
        out float bestError, out float structure, out float supportCount) {
    bestError = 1.0e20;
    float secondError = 1.0e20;
    refined = predicted;
    structure = 0.0;
    supportCount = 0.0;
    bool found = false;
    for (int sy = -1; sy <= 1; ++sy) {
        for (int sx = -1; sx <= 1; ++sx) {
            vec2 candidate = predicted + 0.5 * vec2(float(sx), float(sy));
            if (candidate.x < 0.0 || candidate.y < 0.0 ||
                    candidate.x >= float(packedSize.x) ||
                    candidate.y >= float(packedSize.y)) continue;
            float e, s, n;
            evaluateCorrespondence(p, candidate, e, s, n);
            if (n < 12.0) continue;
            found = true;
            if (e < bestError) {
                secondError = bestError;
                bestError = e;
                refined = candidate;
                structure = s;
                supportCount = n;
            } else if (e < secondError) {
                secondError = e;
            }
        }
    }

    if (found) {
        /* Exact 26502 Tier-1 decision.  A sufficient local observation that
         * disagrees or is ambiguous is final: Tier 2 is forbidden to override it. */
        if (structure >= 0.08) {
            float margin = secondError - bestError;
            bool exceptionallyGood = bestError <= 0.055;
            return bestError <= 0.12 && (exceptionallyGood || margin >= 0.010);
        }
        return supportCount >= 16.0 && bestError <= 0.060;
    }

    /* No Tier-1 candidate had even 12 usable physical phase samples.  Only this
     * insufficient-observability state is eligible for boundary-anchored proof. */
    refined = predicted;
    structure = 0.0;
    return validateBoundaryAnchoredCorrespondence(
            p, predicted, flowConfidence, bestError, supportCount);
}

void storeState(ivec2 p, vec4 cfa, vec4 state) {
    imageStore(outCfa, p, cfa);
    imageStore(outProvenance, p, vec4(encodePhaseStates(state), 0.0, 0.0, 0.0));
}

/* IRIS_26497_PHYSICAL_SHORT_VALIDATION
 * NORMAL remains measured. SHORT_VALIDATED is granted only after unsaturated
 * short evidence survives corrected flow semantics, local correspondence
 * refinement, and the existing physical radiometry check. CENSORED remains
 * explicitly unknown rather than being promoted by downstream color heuristics.
 */
void main() {
    ivec2 p = ivec2(gl_GlobalInvocationID.xy);
    if (any(greaterThanEqual(p, packedSize))) return;
    vec4 normal = texelFetch(normalCfa, p, 0);
    vec4 normalSensor = normal / max(referenceExposureScale, 1.0e-6);
    vec4 clipMask = step(vec4(physicalClipThreshold), normalSensor);
    if (sum4(clipMask) < 0.5) {
        storeState(p, normal, vec4(PROVENANCE_NORMAL));
        return;
    }
    addMask(D_TOTAL_CLIPPED, D_PHASE_TOTAL, clipMask);

    vec2 uv = (vec2(p) + vec2(0.5)) / vec2(packedSize);
    vec4 flowState = texture(flowTexture, uv);
    float variation = max(flowState.z, 0.0);
    /* flowState.w is interpolation-cancel/base-vector-preserved, not invalid. */
    float flowConfidence = exp(-80.0 * variation);
    vec2 predicted = vec2(p) + vec2(0.5) + flowState.xy;
    if (flowConfidence < minimumFlowConfidence) {
        addMask(D_FLOW_REJECT, D_PHASE_FLOW_REJECT, clipMask);
        addMask(D_STILL_CENSORED, D_PHASE_STILL_CENSORED, clipMask);
        storeState(p, normal, clipMask);
        return;
    }

    vec2 source;
    float meanError;
    float structure;
    float supportCount;
    if (!refineObservableCorrespondence(
            p, predicted, flowConfidence, source, meanError, structure, supportCount)) {
        addMask(D_CORR_REJECT, D_PHASE_CORR_REJECT, clipMask);
        addMask(D_STILL_CENSORED, D_PHASE_STILL_CENSORED, clipMask);
        storeState(p, normal, clipMask);
        return;
    }

    vec4 shortCenter = phaseSafeBilinear(source);
    vec4 recoverMask = clipMask * shortSafe(shortCenter);
    vec4 shortClippedMask = clipMask - recoverMask;
    addTotalOnly(D_SHORT_SAFE, recoverMask);
    addMask(D_SHORT_CLIPPED, D_PHASE_SHORT_CLIPPED, shortClippedMask);
    classifyShortSamples(shortCenter, clipMask);
    if (sum4(recoverMask) < 0.5) {
        addMask(D_STILL_CENSORED, D_PHASE_STILL_CENSORED, clipMask);
        storeState(p, normal, clipMask);
        return;
    }

    vec4 shortEquivalent = shortCenter * shortToNormalScale * referenceExposureScale;
    float requiredScale = 1.0;
    for (int i = 0; i < 4; ++i) {
        if (recoverMask[i] > 0.5) {
            requiredScale = max(requiredScale,
                    normal[i] / max(shortEquivalent[i], 1.0e-6));
        }
    }
    if (requiredScale > 1.25) {
        addMask(D_RADIOMETRY_REJECT, D_PHASE_RADIOMETRY_REJECT, recoverMask);
        addMask(D_STILL_CENSORED, D_PHASE_STILL_CENSORED, clipMask);
        storeState(p, normal, clipMask);
        return;
    }
    shortEquivalent *= requiredScale;

    vec4 recovered = normal;
    vec4 state = clipMask;
    for (int i = 0; i < 4; ++i) {
        if (recoverMask[i] > 0.5) {
            float blend = smoothstep(physicalClipThreshold, 1.0, normalSensor[i]);
            recovered[i] = mix(normal[i], shortEquivalent[i], blend);
            state[i] = PROVENANCE_SHORT_VALIDATED;
        }
    }
    addMask(D_VALIDATED, D_PHASE_VALIDATED, recoverMask);
    /* IRIS_26506_SHORT_A_PACK_COHERENCE_DIAGNOSTICS
     * Track whether recovered Short-A color forms a fully measured quad or a
     * mixed SHORT_VALIDATED/CENSORED boundary. Image math is unchanged here;
     * the semantic-weight shader below consumes this provenance spatially.
     */
    float validatedCount=0.0;
    float censoredCount=0.0;
    for(int i=0;i<4;++i){
        if(abs(state[i]-PROVENANCE_SHORT_VALIDATED)<0.25)validatedCount+=1.0;
        if(abs(state[i]-PROVENANCE_CENSORED)<0.25)censoredCount+=1.0;
    }
    if(validatedCount>0.5){
        atomicAdd(shortDiag[D_PACK_SHORT_ANY],1u);
        if(censoredCount>0.5)atomicAdd(shortDiag[D_PACK_SHORT_MIXED_CENSORED],1u);
        else atomicAdd(shortDiag[D_PACK_SHORT_FULLY_KNOWN],1u);
    }
    if (sum4(shortClippedMask) > 0.5) {
        addMask(D_STILL_CENSORED, D_PHASE_STILL_CENSORED, shortClippedMask);
    }
    storeState(p, recovered, state);
}
