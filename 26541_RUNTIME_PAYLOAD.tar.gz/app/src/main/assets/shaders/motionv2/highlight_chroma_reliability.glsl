precision highp float;
precision highp sampler2D;
uniform sampler2D InputBuffer;
uniform sampler2D ReliabilityMap;
uniform vec3 CameraNeutral;
out vec3 Output;

float lum(vec3 c){ return 0.25*c.r + 0.50*c.g + 0.25*c.b; }
vec2 chr(vec3 c){ return vec2(c.r-c.b, c.g-0.5*(c.r+c.b)); }
vec3 fromYChroma(float y,vec2 q){
    return vec3(y - 0.5*q.y + 0.5*q.x, y + 0.5*q.y, y - 0.5*q.y - 0.5*q.x);
}
float peak3(vec3 c){ return max(c.r,max(c.g,c.b)); }
float min3(vec3 c){ return min(c.r,min(c.g,c.b)); }
float relAt(ivec2 p,ivec2 sz){
    vec2 uv=(vec2(p)+vec2(0.5))/vec2(sz);
    return clamp(texture(ReliabilityMap,uv).r,0.0,1.0);
}
float unclipped(vec3 c){ return 1.0-smoothstep(0.84,0.94,peak3(c)); }

/* Opposed donors must both be real, unclipped, reliable observations on the same luminance surface. */
vec3 opposedPair(ivec2 a,ivec2 b,ivec2 sz,float centerY,out float w){
    vec3 ca=max(texelFetch(InputBuffer,a,0).rgb,vec3(0.0));
    vec3 cb=max(texelFetch(InputBuffer,b,0).rgb,vec3(0.0));
    float ya=lum(ca), yb=lum(cb);
    float meanY=0.5*(ya+yb);
    float surfaceTol=0.012 + 0.080*sqrt(max(meanY,0.0));
    float pairSurface=1.0-smoothstep(surfaceTol,2.5*surfaceTol,abs(ya-yb));
    float centerTol=0.018 + 0.110*sqrt(max(centerY,0.0));
    float centerSurface=1.0-smoothstep(centerTol,2.5*centerTol,abs(meanY-centerY));
    float reliable=smoothstep(0.55,0.82,min(relAt(a,sz),relAt(b,sz)));
    w=unclipped(ca)*unclipped(cb)*pairSurface*centerSurface*reliable;
    return 0.5*(ca+cb);
}

void main(){
    ivec2 xy=ivec2(gl_FragCoord.xy);
    ivec2 sz=textureSize(InputBuffer,0);
    vec3 c=max(texelFetch(InputBuffer,xy,0).rgb,vec3(0.0));
    float y0=lum(c);

    /* Hard 26535-style authority boundary: weak reliability alone never changes ordinary edges. */
    float centerClipGate=smoothstep(0.88,0.985,peak3(c));
    if(centerClipGate<=0.0){ Output=c; return; }

    ivec2 xm=ivec2(0);
    ivec2 xp=sz-ivec2(1);
    ivec2 l=clamp(xy+ivec2(-1,0),xm,xp), r=clamp(xy+ivec2(1,0),xm,xp);
    ivec2 d=clamp(xy+ivec2(0,-1),xm,xp), u=clamp(xy+ivec2(0,1),xm,xp);
    ivec2 dl=clamp(xy+ivec2(-1,-1),xm,xp), ur=clamp(xy+ivec2(1,1),xm,xp);
    ivec2 ul=clamp(xy+ivec2(-1,1),xm,xp), dr=clamp(xy+ivec2(1,-1),xm,xp);

    float yl=lum(max(texelFetch(InputBuffer,l,0).rgb,vec3(0.0)));
    float yr=lum(max(texelFetch(InputBuffer,r,0).rgb,vec3(0.0)));
    float yd=lum(max(texelFetch(InputBuffer,d,0).rgb,vec3(0.0)));
    float yu=lum(max(texelFetch(InputBuffer,u,0).rgb,vec3(0.0)));
    float edge=max(max(abs(yl-y0),abs(yr-y0)),max(abs(yu-y0),abs(yd-y0)));
    float edgeScale=0.012 + 0.060*sqrt(max(y0,0.0));
    float edgeGate=smoothstep(edgeScale,3.2*edgeScale,edge);

    float w0,w1,w2,w3;
    vec3 p0=opposedPair(l,r,sz,y0,w0);
    vec3 p1=opposedPair(d,u,sz,y0,w1);
    vec3 p2=opposedPair(dl,ur,sz,y0,w2);
    vec3 p3=opposedPair(ul,dr,sz,y0,w3);
    float wsum=w0+w1+w2+w3;
    vec2 qTarget=chr(c);
    if(wsum>1.0e-6){
        qTarget=(w0*chr(p0)+w1*chr(p1)+w2*chr(p2)+w3*chr(p3))/wsum;
    }
    float donorConfidence=clamp(wsum/2.0,0.0,1.0);
    vec2 q0=chr(c);
    float chromaDelta=length(q0-qTarget);
    float chromaScale=0.006 + 0.030*sqrt(max(y0,0.0));
    float outlierGate=smoothstep(chromaScale,3.5*chromaScale,chromaDelta);
    float opposedAmount=0.78*centerClipGate*edgeGate*outlierGate*donorConfidence;
    vec3 opposed=fromYChroma(y0,qTarget);
    vec3 repaired=mix(c,opposed,clamp(opposedAmount,0.0,0.78));

    /* IRIS_26541_FULL_CENSOR_CAMERA_NEUTRAL_FALLBACK
     * When all camera-linear channels are censored and opposed donors are insufficient, chroma is
     * unknowable. Move only toward the exact Camera2 neutral axis, never toward an invented hue.
     */
    float fullCensorGate=smoothstep(0.94,0.995,min3(c));
    float neutralNeed=fullCensorGate*(1.0-donorConfidence);
    vec3 neutralDir=max(CameraNeutral,vec3(1.0e-6));
    /* A fully clipped RGB triplet is a lower bound, not an exact color. Scale the camera-neutral
     * direction UP until it is no darker than every censored center channel. */
    float neutralScale=max(c.r/neutralDir.r,max(c.g/neutralDir.g,c.b/neutralDir.b));
    vec3 neutralAxis=neutralDir*max(neutralScale,1.0e-6);
    repaired=mix(repaired,neutralAxis,clamp(neutralNeed,0.0,1.0));

    /* A censored center channel may never be reconstructed below its observed lower bound. */
    if(c.r>=0.985) repaired.r=max(repaired.r,c.r);
    if(c.g>=0.985) repaired.g=max(repaired.g,c.g);
    if(c.b>=0.985) repaired.b=max(repaired.b,c.b);
    repaired=max(repaired,vec3(0.0));
    float repairedY=lum(repaired);
    if(repairedY<y0) repaired+=vec3(y0-repairedY);
    Output=repaired;
}
