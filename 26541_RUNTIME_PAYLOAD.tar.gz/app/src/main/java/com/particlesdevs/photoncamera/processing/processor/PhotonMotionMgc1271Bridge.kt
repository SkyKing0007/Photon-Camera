package com.particlesdevs.photoncamera.processing.processor

import android.graphics.ImageFormat
import android.graphics.Point
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.GLES30
import android.os.Build
import com.hinnka.mycamera.model.SafeImage
import com.hinnka.mycamera.processor.GlesGpuScheduler
import com.hinnka.mycamera.processor.GlesMgcRawFusion
import com.hinnka.mycamera.camera.MultiFrameConfig
import com.hinnka.mycamera.processor.GpuLinearRgbStorage
import com.hinnka.mycamera.processor.MgcMergeMethod
import com.hinnka.mycamera.processor.MgcSpatialOutputMode
import com.hinnka.mycamera.processor.RawBurstFrameRole
import com.hinnka.mycamera.processor.RawNoiseProfileSelection
import com.hinnka.mycamera.processor.RawNoiseModel
import com.hinnka.mycamera.processor.RawStackBufferLayout
import com.hinnka.mycamera.processor.RawStackFrame
import com.hinnka.mycamera.raw.MgcFullResolutionDenoise
import com.hinnka.mycamera.raw.RawMetadata
import com.hinnka.mycamera.raw.RawNoiseProfileLayout
import com.hinnka.mycamera.utils.LargeDirectBuffer
import com.hinnka.mycamera.utils.PLog
import com.particlesdevs.photoncamera.app.PhotonCamera
import com.particlesdevs.photoncamera.processing.ImageFrame
import com.particlesdevs.photoncamera.processing.MotionBatch
import com.particlesdevs.photoncamera.processing.render.Parameters
import com.particlesdevs.photoncamera.util.Allocator
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.io.File
import java.io.RandomAccessFile
import kotlin.math.pow

/**
 * IRIS_26512_MGC1271_SPATIAL_RGB_PARITY_OWNER
 *
 * One deliberately narrow adapter around pinned bjzhou 1.27.1 MGC Spatial RGB.
 * Capture/AE remains Photon 26507. Alignment, rejection, Bento, Long, RGB reconstruction,
 * propagated noise and SPATIAL_DEFAULT denoise remain inside the imported MGC owner.
 */
object PhotonMotionMgc1271Bridge {
    private const val TAG = "Mgc1271Bridge"
    private const val EGL_OPENGL_ES3_BIT_KHR = 0x40
    private const val HALF_ONE: Short = 0x3c00

    init {
        System.loadLibrary("my-native-lib")
    }

    @JvmStatic
    fun reconstruct(
        size: Point,
        inputImages: List<ImageFrame>,
        referenceTimestamp: Long,
        parameters: Parameters,
        shortSlot: MotionBatch.ShortHighlightSlot?,
        /* IRIS_26520_V4_LIVE_MGC_NORMAL_DNG_REQUEST */
        produceNormalStackedDng: Boolean,
    ): MotionV2Merger.Result {
        var shortFrame: ImageFrame? = null
        var longFrame: ImageFrame? = null
        var egl: EglOwner? = null
        var halfBuffer: ByteBuffer? = null
        var resultTexture = 0
        var superResDetailPathForCleanup: String? = null
        var superResLinearRawPathForCleanup: String? = null
        var superResOutputsHandedOff = false
        val iris26535TotalStartNs = System.nanoTime()
        var iris26535FusionMs = -1L
        var iris26535DenoiseMs = -1L
        var iris26535SrGateMs = 0L
        try {
            requireParity(Build.SUPPORTED_ABIS.any { it == "arm64-v8a" },
                "pinned MGC 1.27.1 AOT is arm64-only; device ABIs=${Build.SUPPORTED_ABIS.contentToString()}")
            requireParity(size.x > 1 && size.y > 1 && (size.x and 1) == 0 && (size.y and 1) == 0,
                "invalid RAW geometry ${size.x}x${size.y}")
            requireParity(parameters.cfaPattern.toInt() in 0..3,
                "unsupported CFA=${parameters.cfaPattern}")
            requireParity(inputImages.isNotEmpty(), "no equal-exposure Normal frames")

            val reference = inputImages.firstOrNull { it.timestamp == referenceTimestamp }
                ?: invalid("owned reference is absent timestamp=$referenceTimestamp")
            requireParity(reference.buffer != null, "owned reference buffer is null")

            shortFrame = shortSlot?.takeAndSeal()
            longFrame = shortSlot?.shadowAuxSlot?.takeAndSeal()

            // The pinned 1.27.1 GlesMgcRawFusion contract chooses the first supplied NORMAL
            // as its base, preserves the remaining NORMAL order, then admits valid Long and the
            // one lowest-TET Short. HdrxProcessor has already timestamp-sorted the Normal list.
            // Do not impose the old Wronski nearest-reference ordering here.
            val mgcBase = inputImages.firstOrNull { it.motionV2FrameRole == ImageFrame.MotionV2FrameRole.NORMAL }
                ?: invalid("MGC SHORT/NORMAL base is absent")
            val orderedPhysical = ArrayList<Pair<ImageFrame, RawBurstFrameRole>>()
            inputImages.forEachIndexed { index, frame ->
                val role = when (frame.motionV2FrameRole) {
                    ImageFrame.MotionV2FrameRole.NORMAL -> RawBurstFrameRole.NORMAL
                    ImageFrame.MotionV2FrameRole.SHADOW_LONG -> {
                        requireParity(parameters.irisNightActive,
                            "main-list SHADOW_LONG is Night-only index=$index")
                        RawBurstFrameRole.SHADOW_LONG
                    }
                    ImageFrame.MotionV2FrameRole.HIGHLIGHT_SHORT ->
                        invalid("main-list HIGHLIGHT_SHORT is forbidden; Motion Short keeps isolated slot ownership")
                }
                orderedPhysical += frame to role
            }
            longFrame?.let { orderedPhysical += it to RawBurstFrameRole.SHADOW_LONG }
            shortFrame?.let { orderedPhysical += it to RawBurstFrameRole.HIGHLIGHT_SHORT }

            orderedPhysical.forEachIndexed { index, (frame, role) ->
                validateFrame(frame, size, role, reference.motionV2ExposureEnergy, index)
            }

            // IRIS_26514_STRICT_NOISE_AUTHORITY: no Camera2 base-frame, Pixel, or custom->Camera2 fallback.
            // IRIS_26540_NIGHT_FROZEN_IRIS_SETTINGS
            val irisSettings = if (parameters.irisNightActive) {
                parameters.irisNightSettingsSnapshot
                    ?: throw IllegalStateException("26540 Night missing frozen Iris settings")
            } else {
                IrisMotionSettings.current()
            }
            val noiseSelection: RawNoiseProfileSelection
            val noiseAuthority: String
            if (irisSettings.customNoiseModelEnabled) {
                val profile = IrisNoiseProfileStore.loadSelectedProfile(
                    PhotonCamera.getApplicationContextStatic())
                    ?: throw IllegalStateException(
                        "IRIS_26514 custom noise model selected but stored profile is unavailable")
                orderedPhysical.forEachIndexed { index, (frame, _) ->
                    val iso = frame.motionV2ActualIso
                    val model = profile.evaluate(iso)
                        ?: throw IllegalStateException(
                            "IRIS_26514 custom noise model cannot evaluate frame=$index iso=$iso")
                    if (model.shotNoise.any { !it.isFinite() || it <= 0f } ||
                        model.readNoise.any { !it.isFinite() } || model.readNoise.none { it > 0f }) {
                        throw IllegalStateException(
                            "IRIS_26514 custom noise model invalid at frame=$index iso=$iso")
                    }
                }
                noiseSelection = RawNoiseProfileSelection.Calibrated(profile)
                noiseAuthority = "CUSTOM:" +
                    irisSettings.profileDisplayName.ifBlank { irisSettings.profileId }
            } else {
                orderedPhysical.forEachIndexed { index, (frame, _) ->
                    if (frame.motionV2NoiseProfileSource != "CAMERA2_PER_FRAME") {
                        throw IllegalStateException(
                            "IRIS_26514 strict Camera2 noise requires per-frame metadata; " +
                                "frame=$index source=${frame.motionV2NoiseProfileSource}")
                    }
                    val model = RawNoiseModel.fromCamera2NoiseProfile(frame.motionV2NoiseProfile)
                    if (!model.hasValidCamera2Profile) {
                        throw IllegalStateException(
                            "IRIS_26514 invalid Camera2 SENSOR_NOISE_PROFILE frame=$index")
                    }
                }
                noiseSelection = RawNoiseProfileSelection.Camera2
                noiseAuthority = "CAMERA2_PER_FRAME"
            }
            PLog.i(TAG, "IRIS_26514_NOISE_AUTHORITY source=$noiseAuthority " +
                "frames=${orderedPhysical.size} baseFallback=0 pixelFallback=0 " +
                "crossSourceFallback=false")

            parameters.motionCanonicalExposureGain = 1.0f
            parameters.motionV2ShortHighlightRecoveryExecuted = false
            // Preserve the successful-26507 display-gain sampling contract separately from
            // MGC's logical RAW geometry. ImageFrame.width/height are the exact geometry that
            // computeDisplayGain() received in 26507 (including any RAW row-stride padding).
            val referenceDisplayGain = MotionV2Merger.computeDisplayGain(
                reference.buffer,
                reference.width,
                reference.height,
                parameters,
                reference.motionV2ExposureEnergy,
            )
            parameters.motionV2DisplayGain = 1.0f

            val cfa = parameters.cfaPattern.toInt()
            val masterBlack = canonicalBlack(parameters.blackLevel, cfa)
            val whiteLevel = if (mgcBase.motionV2WhiteLevelValid && mgcBase.motionV2WhiteLevel > 0) {
                mgcBase.motionV2WhiteLevel
            } else {
                parameters.whiteLevel
            }
            requireParity(whiteLevel > 0, "invalid reference white level=$whiteLevel")
            val wb = parameters.motionV2ColorGains?.copyOf()
                ?.takeIf { it.size >= 4 && it.take(4).all { v -> v.isFinite() && v > 0f } }
                ?: floatArrayOf(1f, 1f, 1f, 1f)
            val lsc = parameters.gainMap?.copyOf()?.takeIf { values ->
                parameters.mapSize != null && parameters.mapSize.x > 0 && parameters.mapSize.y > 0 &&
                    values.size == parameters.mapSize.x * parameters.mapSize.y * 4 &&
                    values.all { it.isFinite() && it > 0f }
            }
            val lscWidth = if (lsc != null) parameters.mapSize.x else 0
            val lscHeight = if (lsc != null) parameters.mapSize.y else 0

            val frames = orderedPhysical.map { (frame, role) ->
                RawStackFrame(
                    image = safeImage(frame, size),
                    sensorTimestampNs = frame.motionV2ResultSensorTimestampNs.takeIf { it > 0L }
                        ?: frame.timestamp,
                    frameNumber = frame.motionV2FrameNumber,
                    exposureTimeNs = frame.motionV2ActualExposureNs,
                    sensitivityIso = frame.motionV2ActualIso,
                    exposureProduct = frame.motionV2ExposureEnergy,
                    desiredExposureProduct = null,
                    focusDistanceDiopters = frame.motionV2FocusDistanceDiopters,
                    lensState = frame.motionV2LensState.takeIf { it >= 0 },
                    rollingShutterSkewNs = frame.motionV2RollingShutterSkewNs.takeIf { it > 0L },
                    channelNoiseProfile = if (irisSettings.customNoiseModelEnabled) {
                        null
                    } else {
                        frame.motionV2NoiseProfile.copyOf()
                    },
                    dynamicBlackLevelByCfaPosition = frame.motionV2BlackLevel.copyOf(),
                    role = role,
                )
            }

            /* IRIS_26532_20X_TOTAL_SR_AUTHORITY
             * "20x" is displayed/equivalent FOV, not a 20x output-size multiplier. The selected
             * physical lens owns its optical anchor. Spatial directly reconstructs the requested
             * crop through 20x total; any request above 20x remains a final residual crop.
             */
            val displayedGlobalZoom = parameters.motionV2GlobalZoom
                .takeIf { it.isFinite() }?.coerceAtLeast(1f) ?: 1f
            val localOutputZoom = parameters.motionV2OutputZoom
                .takeIf { it.isFinite() }?.coerceAtLeast(1f) ?: 1f
            val opticalAnchor = parameters.motionV2OpticalZoomAnchor
                .takeIf { it.isFinite() && it > 0f }
                ?: (displayedGlobalZoom / localOutputZoom).coerceAtLeast(0.05f)
            val srTotalZoom = minOf(displayedGlobalZoom, 20.0f)
            val spatialReconstructionZoom = if (localOutputZoom > 1.0001f) {
                (srTotalZoom / opticalAnchor).coerceIn(1f, localOutputZoom)
            } else 1f
            val renderResidualZoom = (localOutputZoom / spatialReconstructionZoom)
                .takeIf { it.isFinite() }?.coerceAtLeast(1f) ?: 1f
            parameters.motionV2SpatialReconstructionZoom = spatialReconstructionZoom
            parameters.motionV2RenderResidualZoom = renderResidualZoom
            requireParity(
                kotlin.math.abs(spatialReconstructionZoom * renderResidualZoom - localOutputZoom)
                    <= 1.0e-3f * maxOf(1f, localOutputZoom),
                "26532 SR geometry identity failed local=$localOutputZoom recon=$spatialReconstructionZoom residual=$renderResidualZoom",
            )
            val fixedOutputScale = if (parameters.motionV2SuperResOutputEnabled) 2f else 1f
            parameters.motionV2SuperResOutputScale = fixedOutputScale
            PLog.i(TAG, "IRIS_26532_20X_TOTAL_SR " +
                "displayedGlobalZoom=$displayedGlobalZoom opticalAnchor=$opticalAnchor " +
                "localOutputZoom=$localOutputZoom srTotalZoom=$srTotalZoom " +
                "spatialReconstructionZoom=$spatialReconstructionZoom " +
                "renderResidualZoom=$renderResidualZoom outputScale=$fixedOutputScale " +
                "srTotalCap=20.0 fixedSuperResScale=2.0")

            egl = EglOwner.create()
            val fusion = GlesMgcRawFusion(
                width = size.x,
                height = size.y,
                cfaPattern = cfa,
                blackLevel = masterBlack,
                whiteLevel = whiteLevel,
                whiteBalanceGains = wb,
                noiseProfileSelection = noiseSelection,
                lensShading = lsc,
                lensShadingWidth = lscWidth,
                lensShadingHeight = lscHeight,
                outputMode = MgcSpatialOutputMode.RGB,
                mergeMethod = MgcMergeMethod.SPATIAL_RGB,
                outputScale = fixedOutputScale,
                reconstructionZoom = spatialReconstructionZoom,
                displayedGlobalZoom = displayedGlobalZoom,
                useCurrentGlContext = true,
                exportGpuLinearRgbSource = true,
                gpuLinearRgbStorage = GpuLinearRgbStorage.RGBA16F,
                exportNormalStackedDng = produceNormalStackedDng,
                superResTempDir = PhotonCamera.getApplicationContextStatic().cacheDir,
                superResWriteLinearRaw = produceNormalStackedDng,
            )
            val iris26535FusionStartNs = System.nanoTime()
            val stacked = fusion.processFrames(frames)
                ?: invalid("pinned Spatial RGB owner returned null")
            iris26535FusionMs = (System.nanoTime() - iris26535FusionStartNs) / 1_000_000L
            val expectedSuperResWidth = MultiFrameConfig.scaledRawOutputDimension(size.x, fixedOutputScale)
            val expectedSuperResHeight = MultiFrameConfig.scaledRawOutputDimension(size.y, fixedOutputScale)
            val expectedOutputWidth = if (fixedOutputScale > 1f) size.x else expectedSuperResWidth
            val expectedOutputHeight = if (fixedOutputScale > 1f) size.y else expectedSuperResHeight
            requireParity(stacked.width == expectedOutputWidth && stacked.height == expectedOutputHeight,
                "base output geometry ${stacked.width}x${stacked.height} != ${expectedOutputWidth}x${expectedOutputHeight}")
            if (fixedOutputScale > 1f) {
                requireParity(
                    stacked.superResWidth == expectedSuperResWidth &&
                        stacked.superResHeight == expectedSuperResHeight,
                    "SR evidence geometry ${stacked.superResWidth}x${stacked.superResHeight} != " +
                        "${expectedSuperResWidth}x$expectedSuperResHeight",
                )
                requireParity(stacked.superResDetailPath != null, "missing streamed 2x detail evidence")
                if (produceNormalStackedDng) {
                    requireParity(stacked.superResLinearRawPath != null, "missing streamed 2x LinearRaw DNG evidence")
                }
            }
            requireParity(stacked.bufferLayout == RawStackBufferLayout.LINEAR_RGB,
                "output layout=${stacked.bufferLayout}")
            requireParity(stacked.isNormalizedSensorData, "output is not normalized sensor data")
            val gpu = stacked.gpuLinearRgbSource
                ?: invalid("missing GPU Linear RGB source")
            requireParity(gpu.storage == GpuLinearRgbStorage.RGBA16F && gpu.samplesPerPixel == 4,
                "unexpected GPU RGB storage=${gpu.storage} samples=${gpu.samplesPerPixel}")
            requireParity(gpu.textureId != 0, "zero GPU RGB texture")
            requireParity(stacked.mergedFrameCount >= 1, "mergedFrameCount=${stacked.mergedFrameCount}")
            val correlation = stacked.mgcDenoiseCorrelation
            val readNoise = stacked.mgcDenoiseReadNoise
            val shotNoise = stacked.mgcDenoiseShotNoise
            val strength = stacked.mgcSpatialStrengthMap
            val referenceSnr = stacked.mgcReferenceSnr
            val tuningSnr = stacked.mgcDenoiseTuningSnr
            requireParity(correlation?.size == 128 && correlation.all { it.isFinite() && it >= 0f },
                "missing/malformed propagated correlation")
            requireParity(readNoise?.size == 3 && readNoise.all { it.isFinite() && it >= 0f },
                "missing/malformed propagated read noise")
            requireParity(shotNoise?.size == 3 && shotNoise.all { it.isFinite() && it >= 0f },
                "missing/malformed propagated shot noise")
            requireParity(strength != null && strength.width == (expectedOutputWidth + 3) / 4 &&
                    strength.height == (expectedOutputHeight + 3) / 4,
                "missing/malformed Spatial strength map")
            requireParity(referenceSnr != null && referenceSnr.isFinite() && referenceSnr >= 0f,
                "missing/malformed MGC reference SNR")
            requireParity(tuningSnr != null && tuningSnr.isFinite() && tuningSnr >= 0f,
                "missing/malformed propagated MGC tuning SNR")
            requireParity(lsc == null || stacked.lensShadingCorrectionApplied,
                "LSC supplied but MGC output did not apply it")
            val iris26535SpatialReliability = publishSpatialReliability(parameters, checkNotNull(strength))

            GLES30.glFinish()
            gpu.stackCompletionTimeline?.releasePending()
            resultTexture = gpu.textureId

            val denoiseMetadata = RawMetadata(
                cfaPattern = cfa,
                whiteBalanceGains = wb,
                lensShadingMap = lsc,
                lensShadingMapWidth = lscWidth,
                lensShadingMapHeight = lscHeight,
                mgcDenoiseCorrelation = correlation,
                mgcDenoiseReadNoise = readNoise,
                mgcDenoiseShotNoise = shotNoise,
                mgcSpatialStrengthMap = strength,
                noiseProfileLayout = if (irisSettings.customNoiseModelEnabled)
                    RawNoiseProfileLayout.CANONICAL_BAYER else RawNoiseProfileLayout.CAMERA2_CFA,
                channelNoiseProfile = if (irisSettings.customNoiseModelEnabled)
                    floatArrayOf() else reference.motionV2NoiseProfile.copyOf(),
            )
            /* IRIS_26540_RESIDUAL_ONLY_DENOISE_AUTHORITY
             * Temporal Spatial-RGB reconstruction is the first noise reducer. Pecan runs only on
             * the residual model exported by the finished stack. Source/reference SNR chooses the
             * Pecan frequency profile; it does NOT create a low-light strength floor. ISO, scene
             * brightness and preview darkness never independently increase denoise strength.
             */
            val requestedLumaScale = irisSettings.lumaDenoise.coerceIn(0f, 2f)
            val noiseEquivalentSupport = stacked.normalStackedDngNoiseEquivalentSupport
            requireParity(noiseEquivalentSupport.isFinite() && noiseEquivalentSupport >= 1f,
                "missing/malformed noise-equivalent temporal support")
            /* IRIS_26541_RESTORE_26535_ZERO_MGC_LUMA
             * The 26536+ low-light/mottle luma experiment did not improve the user's Motion
             * samples. Restore the proven 26531/26535 full-resolution Pecan/MGC luma contract
             * exactly to zero for Motion and Night. Chroma remains user-owned, and the separate
             * >=8x SR temporal-luma weighting inside the reconstruction shader is untouched.
             */
            val userLumaScale = 0f
            val lumaScale = 0f
            val chromaScale = irisSettings.chromaDenoise
            val runFullResolutionDenoise = irisSettings.noiseReductionEnabled &&
                (lumaScale > 0f || chromaScale > 0f)
            if (runFullResolutionDenoise) {
                requireParity(MgcFullResolutionDenoise.ensureInitialized(
                    PhotonCamera.getApplicationContextStatic()),
                    "MGC denoise tuning assets failed initialization")
            }

            var superResDetailPath: String? = stacked.superResDetailPath
            var superResDetailWidth = stacked.superResWidth
            var superResDetailHeight = stacked.superResHeight
            var superResLinearRawPath: String? = stacked.superResLinearRawPath
            var superResLinearRawWidth = stacked.superResWidth
            var superResLinearRawHeight = stacked.superResHeight
            if (fixedOutputScale > 1f) {
                superResDetailPathForCleanup = superResDetailPath
                superResLinearRawPathForCleanup = superResLinearRawPath
                val gateStartNs = System.nanoTime()
                gateSuperResDetailByNativeReliability(
                    checkNotNull(superResDetailPath),
                    superResDetailWidth,
                    superResDetailHeight,
                    checkNotNull(strength),
                    iris26535SpatialReliability,
                )
                iris26535SrGateMs = (System.nanoTime() - gateStartNs) / 1_000_000L
            }
            /* IRIS_26532_MEMORY_SAFE_STREAMED_2X
             * The stacker has already reconstructed/streamed 2x evidence band-by-band and
             * downsampled the base carrier before its native-size chroma pass. Downstream Photon
             * therefore sees the same native-size carrier contract as 26531 in both toggle states.
             */
            val denoiseBuffer = readRgba16f(resultTexture, size.x, size.y)
            halfBuffer = denoiseBuffer
            val iris26535DenoiseStartNs = System.nanoTime()
            if (runFullResolutionDenoise) {
                requireParity(MgcFullResolutionDenoise.denoise(
                    rgba16f = denoiseBuffer,
                    width = size.x,
                    height = size.y,
                    globalOriginX = 0,
                    globalOriginY = 0,
                    fullWidth = size.x,
                    fullHeight = size.y,
                    outputScale = 1f,
                    inputLayout = MgcFullResolutionDenoise.InputLayout.CAMERA_RGBA16F,
                    applyLensShadingInBayerAot = false,
                    metadata = denoiseMetadata,
                    preparedYuvNoiseModel = null,
                    applyLensShadingToDenoiseStrength = false,
                    tuningSnr = tuningSnr!!,
                    pass = MgcFullResolutionDenoise.Pass.SPATIAL_DEFAULT,
                    lumaStrengthScale = lumaScale,
                    chromaStrengthScale = chromaScale,
                ), "MGC SPATIAL_DEFAULT native carrier denoise rejected its propagated state")
            }
            iris26535DenoiseMs = (System.nanoTime() - iris26535DenoiseStartNs) / 1_000_000L
            forceOpaqueHalfAlpha(denoiseBuffer, size.x, size.y)
            /* IRIS_26538_NIGHT_NATIVE_RGBA16F_HANDOFF
             * MGC already owns the finished full-resolution camera RGB as RGBA16F. Motion keeps
             * its established FLOAT32 cross-context contract byte-for-byte, but Night no longer
             * expands the ~96 MiB half-float carrier into a ~192 MiB FLOAT32 carrier only to
             * upload it and immediately process through RGBA16F ping-pong textures.
             */
            val nightNativeHalfCarrier = parameters.irisNightActive
            val output: ByteBuffer = if (nightNativeHalfCarrier) {
                halfBuffer = null // ownership transfers to the returned Night result
                denoiseBuffer.position(0)
                denoiseBuffer
            } else {
                convertHalfRgbaToFloatRgba(denoiseBuffer, size.x, size.y)
            }
            GLES30.glDeleteTextures(1, intArrayOf(resultTexture), 0)
            resultTexture = 0
            checkGl("delete exported MGC RGB")

            PLog.i(TAG, "IRIS_26532_DENOISE_SR_AUTHORITY " +
                "master=${irisSettings.noiseReductionEnabled} " +
                "requestedLuma=$requestedLumaScale automaticLowLightLuma=0.0 " +
                "userLuma=$userLumaScale effectiveMgcLuma=$lumaScale " +
                "zeroLumaRollback=IRIS_26541_RESTORE_26535_ZERO_MGC_LUMA " +
                "profileSnrSource=referencePreMerge referenceSnr=$referenceSnr " +
                "noiseEquivalentSupport=$noiseEquivalentSupport " +
                "pecanProfileTuningSnr=$tuningSnr residualMagnitude=propagatedReadShotCorrelationStrength " +
                "isoStrengthAuthority=false darknessStrengthAuthority=false textureClassifier=false " +
                "structureAuthority=MGC_PECAN_OUTLIER_REVERT_SPATIAL_STRENGTH " +
                "chroma=$chromaScale executed=$runFullResolutionDenoise " +
                "srScale=$spatialReconstructionZoom requestedLocalZoom=$localOutputZoom " +
                "finalFovZoom=$displayedGlobalZoom renderResidual=$renderResidualZoom " +
                "outputScale=$fixedOutputScale banded2x=${fixedOutputScale > 1f} " +
                "fullHighResPostTexture=false baseCarrier=${size.x}x${size.y} " +
                "pass=SPATIAL_DEFAULT legacyPhotonNr=false sabreSelected=false")

            val baselineScale = stacked.baselineExposureEv
                ?.takeIf { it.isFinite() }
                ?.let { 2.0.pow(it.toDouble()).toFloat() }
                ?: 1f
            requireParity(baselineScale.isFinite() && baselineScale > 0f,
                "invalid Bento baseline exposure scale=$baselineScale")
            /* IRIS_26515_SHORT_BASELINE_DOMAIN
             * MGC deliberately stores an accepted-Short result in a darker source domain and
             * returns BaselineExposure to restore reference brightness after MGC denoise.
             * Keep that restoration separate from Photon's scene/display authority.
             */
            parameters.motionV2MgcSourceExposureGain = baselineScale
            parameters.motionV2DisplayGain = 1.0f
            /* IRIS_26516_VIEWFINDER_PRESENTATION_AUTHORITY
             * All legacy RAW p50/p90 display assignments are neutralized. Keep the already-computed
             * referenceDisplayGain only as diagnostic evidence; shutter-time viewfinder matching
             * sets motionV2DisplayGain after DNG/profile color.
             */
            PLog.i(TAG, "IRIS_26516_VIEWFINDER_PRESENTATION_AUTHORITY " +
                "legacyRawDisplayGainDiagnostic=$referenceDisplayGain " +
                "initialPresentationGain=${parameters.motionV2DisplayGain} " +
                "sourceDomainGain=${parameters.motionV2MgcSourceExposureGain} " +
                "legacyAssignmentsNeutralized=2 " +
                "solverAfterProfileColor=true camera2Write=false")
            parameters.motionV2ShortHighlightRecoveryExecuted = stacked.baselineExposureEv != null
            PLog.i(TAG, "IRIS_26515_SHORT_BASELINE_DOMAIN " +
                "baselineEv=${stacked.baselineExposureEv} sourceDomainGain=$baselineScale " +
                "displayGain=${parameters.motionV2DisplayGain} " +
                "shortAccepted=${stacked.baselineExposureEv != null} " +
                "denoiseBeforeSourceRestore=true restorePass=existingDisplayExposure " +
                "rendererSceneWhiteAuthority=referenceDisplayOnly")
            parameters.motionV2EffectiveSupport = stacked.mergedFrameCount.toFloat()

            /* IRIS_26520_V4_LIVE_MGC_NORMAL_DNG_BRIDGE */
            if (produceNormalStackedDng) {
                requireParity(stacked.normalStackedDngRaw16 != null, "requested normal stacked DNG buffer is missing")
                requireParity(stacked.normalStackedDngFrameCount == inputImages.size,
                    "normal stacked DNG population=${stacked.normalStackedDngFrameCount} normals=${inputImages.size}")
                /* IRIS_26522_NORMALIZED16_DNG_METADATA */
                requireParity(stacked.normalStackedDngNoiseProfile?.size == 6,
                    "normalized16 stacked DNG noise profile is missing/invalid")
                requireParity(stacked.normalStackedDngNoiseEquivalentSupport.isFinite() &&
                    stacked.normalStackedDngNoiseEquivalentSupport >= 1f &&
                    stacked.normalStackedDngNoiseEquivalentSupport <= inputImages.size.toFloat() + 0.01f,
                    "normalized16 stacked DNG effective support is invalid")
            } else {
                requireParity(stacked.normalStackedDngRaw16 == null && stacked.normalStackedDngFrameCount == 0,
                    "DNG sidecar produced without request")
                requireParity(stacked.normalStackedDngNoiseProfile == null,
                    "DNG metadata produced without request")
            }

            PLog.i(TAG, "IRIS_26535_SPATIAL_RGB_TIMING " +
                "srEnabled=${fixedOutputScale > 1f} fusionMs=$iris26535FusionMs " +
                "denoiseMs=$iris26535DenoiseMs srReliabilityGateMs=$iris26535SrGateMs " +
                "totalMs=${(System.nanoTime() - iris26535TotalStartNs) / 1_000_000L} " +
                "frames=${frames.size} merged=${stacked.mergedFrameCount}")
            PLog.i(TAG, "IRIS_26512_MGC1271_PARITY_VALID " +
                "normals=${inputImages.size} totalScheduled=${frames.size} " +
                "photonReference=$referenceTimestamp mgcBase=${mgcBase.timestamp} " +
                "long=${if (longFrame != null) 1 else 0} short=${if (shortFrame != null) 1 else 0} " +
                "merged=${stacked.mergedFrameCount} cfa=$cfa " +
                "lsc=${stacked.lensShadingCorrectionApplied} " +
                "denoise=SPATIAL_DEFAULT_ADAPTIVE_LUMA_CHROMA " +
                "baselineEv=${stacked.baselineExposureEv} " +
                "displayGain=${parameters.motionV2DisplayGain} " +
                "crossContext=${if (parameters.irisNightActive) "rgba16f_cpu_night" else "float32_rgba_cpu_motion"} alphaSupport=disabled")

            superResOutputsHandedOff = true
            return MotionV2Merger.Result(
                output,
                mgcBase.timestamp,
                frames.size,
                stacked.mergedFrameCount.toFloat(),
                null,
                stacked.normalStackedDngRaw16,
                stacked.normalStackedDngFrameCount,
                stacked.normalStackedDngNoiseProfile,
                stacked.normalStackedDngSupportMin,
                stacked.normalStackedDngSupportP01,
                stacked.normalStackedDngSupportP10,
                stacked.normalStackedDngSupportMedian,
                stacked.normalStackedDngSupportMean,
                stacked.normalStackedDngSupportMax,
                stacked.normalStackedDngNoiseEquivalentSupport,
                superResDetailPath,
                superResDetailWidth,
                superResDetailHeight,
                superResLinearRawPath,
                superResLinearRawWidth,
                superResLinearRawHeight,
            )
        } catch (error: Throwable) {
            PLog.e(TAG, "MGC PARITY ARCHITECTURE INVALID", error)
            throw if (error is IllegalStateException &&
                error.message?.startsWith("MGC PARITY ARCHITECTURE INVALID") == true) {
                error
            } else {
                IllegalStateException("MGC PARITY ARCHITECTURE INVALID: ${error.message}", error)
            }
        } finally {
            if (resultTexture != 0) runCatching {
                GLES30.glDeleteTextures(1, intArrayOf(resultTexture), 0)
            }
            LargeDirectBuffer.free(halfBuffer)
            if (!superResOutputsHandedOff) {
                superResDetailPathForCleanup?.let { path -> runCatching { File(path).delete() } }
                superResLinearRawPathForCleanup?.let { path -> runCatching { File(path).delete() } }
            }
            egl?.close()
            inputImages.forEach { frame ->
                if (frame.buffer != null) runCatching { frame.close() }
            }
            if (shortFrame?.buffer != null && inputImages.none { it === shortFrame }) {
                runCatching { shortFrame?.close() }
            }
            if (longFrame?.buffer != null && inputImages.none { it === longFrame }) {
                runCatching { longFrame?.close() }
            }
            shortSlot?.sealAndClose()
        }
    }

    private fun validateFrame(
        frame: ImageFrame,
        size: Point,
        role: RawBurstFrameRole,
        referenceEnergy: Double,
        index: Int,
    ) {
        requireParity(frame.buffer != null, "frame[$index] $role buffer is null")
        requireParity(frame.motionV2PlaneLayoutValid,
            "frame[$index] $role RAW plane layout missing")
        requireParity(!frame.motionV2PlaneTransformedByBinning,
            "frame[$index] $role uses transformed/binning RAW layout")
        requireParity(frame.motionV2PlaneFormat == ImageFormat.RAW_SENSOR,
            "frame[$index] $role format=${frame.motionV2PlaneFormat}, RAW_SENSOR required")
        requireParity(frame.motionV2PlaneLogicalWidth == size.x &&
                frame.motionV2PlaneLogicalHeight == size.y,
            "frame[$index] $role logical=${frame.motionV2PlaneLogicalWidth}x${frame.motionV2PlaneLogicalHeight} " +
                "expected=${size.x}x${size.y}")
        requireParity(frame.motionV2PlanePixelStrideBytes == 2,
            "frame[$index] $role pixelStride=${frame.motionV2PlanePixelStrideBytes}, expected=2")
        requireParity(frame.motionV2PlaneRowStrideBytes >= size.x * 2,
            "frame[$index] $role rowStride=${frame.motionV2PlaneRowStrideBytes}")
        requireParity(frame.buffer.capacity() >= frame.motionV2PlaneRowStrideBytes * size.y,
            "frame[$index] $role copied RAW capacity=${frame.buffer.capacity()} stride=${frame.motionV2PlaneRowStrideBytes}")
        requireParity(frame.motionV2ActualExposureNs > 0L && frame.motionV2ActualIso > 0 &&
                frame.motionV2ExposureEnergy.isFinite() && frame.motionV2ExposureEnergy > 0.0,
            "frame[$index] $role exposure metadata invalid")
        requireParity(frame.motionV2NoiseProfileValid && frame.motionV2NoiseProfile.size >= 8 &&
                (0 until 4).all { phase ->
                    val s = frame.motionV2NoiseProfile[phase * 2]
                    val o = frame.motionV2NoiseProfile[phase * 2 + 1]
                    s.isFinite() && s > 0f && o.isFinite() && o >= 0f
                }, "frame[$index] $role Camera2 noise profile invalid")
        requireParity(frame.motionV2BlackLevelValid && frame.motionV2BlackLevel.all {
            it.isFinite() && it >= 0f
        }, "frame[$index] $role dynamic black level invalid")
        if (role == RawBurstFrameRole.SHADOW_LONG) {
            requireParity(frame.motionV2ExposureEnergy > referenceEnergy,
                "Long TET is not above reference")
        }
        if (role == RawBurstFrameRole.HIGHLIGHT_SHORT) {
            requireParity(frame.motionV2ExposureEnergy < referenceEnergy,
                "Short TET is not below reference")
        }
    }

    private fun safeImage(frame: ImageFrame, size: Point): SafeImage {
        val raw = frame.buffer ?: invalid("RAW buffer vanished before SafeImage adapter")
        return SafeImage(
            width = size.x,
            height = size.y,
            format = frame.motionV2PlaneFormat,
            timestamp = frame.timestamp,
            buffer = raw,
            rowStride = frame.motionV2PlaneRowStrideBytes,
            pixelStride = frame.motionV2PlanePixelStrideBytes,
            closeAction = { frame.close() },
        )
    }

    private fun canonicalBlack(positional: FloatArray, cfa: Int): FloatArray {
        requireParity(positional.size >= 4, "master black level has ${positional.size} phases")
        val phaseToCanonical = when (cfa) {
            1 -> intArrayOf(1, 0, 3, 2)
            2 -> intArrayOf(2, 3, 0, 1)
            3 -> intArrayOf(3, 2, 1, 0)
            else -> intArrayOf(0, 1, 2, 3)
        }
        return FloatArray(4).also { out ->
            phaseToCanonical.forEachIndexed { phase, canonical ->
                val value = positional[phase]
                requireParity(value.isFinite() && value >= 0f,
                    "invalid master black phase=$phase value=$value")
                out[canonical] = value
            }
        }
    }

    private fun readRgba16f(texture: Int, width: Int, height: Int): ByteBuffer {
        val bytes = width.toLong() * height * 4L * 2L
        val output = LargeDirectBuffer.allocate(bytes, "MGC1271 RGBA16F black-box input")
            ?: invalid("unable to allocate RGBA16F denoise buffer")
        val fbo = IntArray(1)
        GLES30.glGenFramebuffers(1, fbo, 0)
        requireParity(fbo[0] != 0, "unable to allocate RGBA16F readback FBO")
        try {
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo[0])
            GLES30.glFramebufferTexture2D(
                GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0,
                GLES30.GL_TEXTURE_2D, texture, 0)
            requireParity(GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER) ==
                    GLES30.GL_FRAMEBUFFER_COMPLETE,
                "RGBA16F readback FBO incomplete")
            GLES30.glReadBuffer(GLES30.GL_COLOR_ATTACHMENT0)
            GLES30.glPixelStorei(GLES30.GL_PACK_ALIGNMENT, 8)
            output.position(0)
            GLES30.glReadPixels(0, 0, width, height, GLES30.GL_RGBA, GLES30.GL_HALF_FLOAT, output)
            checkGl("read pinned MGC RGBA16F")
            output.position(0)
            return output
        } catch (error: Throwable) {
            LargeDirectBuffer.free(output)
            throw error
        } finally {
            GLES30.glPixelStorei(GLES30.GL_PACK_ALIGNMENT, 1)
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
            GLES30.glDeleteFramebuffers(1, fbo, 0)
        }
    }

    private fun forceOpaqueHalfAlpha(buffer: ByteBuffer, width: Int, height: Int) {
        val shorts = buffer.duplicate().order(ByteOrder.nativeOrder()).apply { position(0) }.asShortBuffer()
        val pixels = width * height
        requireParity(shorts.capacity() >= pixels * 4, "RGBA16F alpha buffer is short")
        for (pixel in 0 until pixels) shorts.put(pixel * 4 + 3, HALF_ONE)
        buffer.position(0)
    }

    private fun convertHalfRgbaToFloatRgba(half: ByteBuffer, width: Int, height: Int): ByteBuffer {
        val textureIds = IntArray(1)
        val fboIds = IntArray(1)
        GLES30.glGenTextures(1, textureIds, 0)
        GLES30.glGenFramebuffers(1, fboIds, 0)
        requireParity(textureIds[0] != 0 && fboIds[0] != 0,
            "half->float transfer allocation failed")
        val outputBytes = width.toLong() * height * 4L * 4L
        val output = LargeDirectBuffer.allocate(outputBytes, "MGC1271 Photon FLOAT32 RGBA")
            ?: invalid("unable to allocate Photon FLOAT32 carrier")
        try {
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureIds[0])
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
            GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 8)
            half.position(0)
            GLES30.glTexImage2D(
                GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA16F, width, height, 0,
                GLES30.GL_RGBA, GLES30.GL_HALF_FLOAT, half)
            checkGl("upload denoised RGBA16F")
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fboIds[0])
            GLES30.glFramebufferTexture2D(
                GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0,
                GLES30.GL_TEXTURE_2D, textureIds[0], 0)
            requireParity(GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER) ==
                    GLES30.GL_FRAMEBUFFER_COMPLETE,
                "half->float FBO incomplete")
            GLES30.glReadBuffer(GLES30.GL_COLOR_ATTACHMENT0)
            GLES30.glPixelStorei(GLES30.GL_PACK_ALIGNMENT, 4)
            output.position(0)
            GLES30.glReadPixels(0, 0, width, height, GLES30.GL_RGBA, GLES30.GL_FLOAT, output)
            checkGl("read Photon FLOAT32 RGBA")
            output.position(0)
            return output
        } catch (error: Throwable) {
            LargeDirectBuffer.free(output)
            throw error
        } finally {
            GLES30.glPixelStorei(GLES30.GL_PACK_ALIGNMENT, 1)
            GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, 0)
            GLES30.glDeleteFramebuffers(1, fboIds, 0)
            GLES30.glDeleteTextures(1, textureIds, 0)
        }
    }


    /* IRIS_26535_NATIVE_SPATIAL_RELIABILITY_OWNER
     * MGC's Q8 Spatial strength is a native rejection/noise-derived variance multiplier, not a
     * fabricated frame-count map. Convert it monotonically to [0,1] reliability: identity (256)
     * or better remains 1; larger variance multipliers reduce confidence; zero is untrusted.
     */
    private fun publishSpatialReliability(
        parameters: Parameters,
        strength: com.hinnka.mycamera.raw.MgcSpatialStrengthMap,
    ): FloatArray {
        val reliability = FloatArray(strength.q8.size)
        var sum = 0.0
        var low = 0
        var zero = 0
        var minRel = 1f
        var maxRel = 0f
        strength.q8.forEachIndexed { index, sample ->
            val q8 = sample.toInt() and 0xffff
            val value = if (q8 <= 0) 0f else minOf(1f, 256f / q8.toFloat())
            reliability[index] = value
            sum += value.toDouble()
            if (value < 0.65f) low++
            if (q8 == 0) zero++
            minRel = minOf(minRel, value)
            maxRel = maxOf(maxRel, value)
        }
        parameters.motionV2SpatialReliability = reliability
        parameters.motionV2SpatialReliabilityWidth = strength.width
        parameters.motionV2SpatialReliabilityHeight = strength.height
        parameters.motionV2SpatialReliabilityMean =
            if (reliability.isNotEmpty()) (sum / reliability.size).toFloat() else 0f
        parameters.motionV2SpatialReliabilityLowFraction =
            if (reliability.isNotEmpty()) low.toFloat() / reliability.size.toFloat() else 1f
        val gridW = 8
        val gridH = 6
        val grid = StringBuilder()
        var worstGridMean = 1f
        var worstGridX = 0
        var worstGridY = 0
        for (gy in 0 until gridH) {
            val y0 = gy * strength.height / gridH
            val y1 = maxOf(y0 + 1, (gy + 1) * strength.height / gridH)
            for (gx in 0 until gridW) {
                val x0 = gx * strength.width / gridW
                val x1 = maxOf(x0 + 1, (gx + 1) * strength.width / gridW)
                var tileSum = 0.0
                var tileCount = 0
                for (yy in y0 until minOf(y1, strength.height)) {
                    for (xx in x0 until minOf(x1, strength.width)) {
                        tileSum += reliability[yy * strength.width + xx].toDouble()
                        tileCount++
                    }
                }
                val tileMean = if (tileCount > 0) (tileSum / tileCount).toFloat() else 0f
                if (tileMean < worstGridMean) {
                    worstGridMean = tileMean
                    worstGridX = gx
                    worstGridY = gy
                }
                if (grid.isNotEmpty()) grid.append(',')
                grid.append(String.format(java.util.Locale.US, "%.3f", tileMean))
            }
        }
        PLog.i(TAG, "IRIS_26535_NATIVE_SPATIAL_RELIABILITY " +
            "size=${strength.width}x${strength.height} min=$minRel max=$maxRel " +
            "mean=${parameters.motionV2SpatialReliabilityMean} " +
            "lowLt065=${parameters.motionV2SpatialReliabilityLowFraction} zeroQ8=$zero " +
            "worstGrid8x6=$worstGridX,$worstGridY/$worstGridMean " +
            "grid8x6=$grid source=MGC_AOT_REJECTION_NOISE_VARIANCE notFrameCount=true")
        return reliability
    }

    /* IRIS_26535_SR_RELIABILITY_GATE
     * The 2x detail stream is optional enhancement evidence. Attenuate only its deviation from
     * neutral where MGC's own Spatial reliability falls; never modify the native Spatial-RGB base.
     */
    private fun gateSuperResDetailByNativeReliability(
        path: String,
        detailWidth: Int,
        detailHeight: Int,
        strength: com.hinnka.mycamera.raw.MgcSpatialStrengthMap,
        reliability: FloatArray,
    ) {
        requireParity(detailWidth > 0 && detailHeight > 0, "invalid SR detail geometry")
        requireParity(reliability.size == strength.width * strength.height,
            "SR reliability geometry mismatch")
        val file = File(path)
        requireParity(file.length() == detailWidth.toLong() * detailHeight.toLong(),
            "SR detail byte count changed before reliability gate")
        val row = ByteArray(detailWidth)
        var attenuated = 0L
        var neutralized = 0L
        RandomAccessFile(file, "rw").use { raf ->
            for (y in 0 until detailHeight) {
                val rowStart = y.toLong() * detailWidth.toLong()
                raf.seek(rowStart)
                raf.readFully(row)
                val sy = minOf(strength.height - 1,
                    ((y + 0.5f) * strength.height / detailHeight).toInt())
                for (x in 0 until detailWidth) {
                    val sx = minOf(strength.width - 1,
                        ((x + 0.5f) * strength.width / detailWidth).toInt())
                    val conf = reliability[sy * strength.width + sx].coerceIn(0f, 1f)
                    if (conf >= 0.995f) continue
                    val code = row[x].toInt() and 0xff
                    val delta = code - 128
                    val weight = conf * conf
                    val adjusted = (128f + delta.toFloat() * weight).toInt().coerceIn(0, 255)
                    if (adjusted != code) attenuated++
                    if (adjusted == 128 && code != 128) neutralized++
                    row[x] = adjusted.toByte()
                }
                raf.seek(rowStart)
                raf.write(row)
            }
        }
        PLog.i(TAG, "IRIS_26535_SR_RELIABILITY_GATE " +
            "detail=${detailWidth}x$detailHeight attenuated=$attenuated neutralized=$neutralized " +
            "baseCarrierUntouched=true source=MGC_NATIVE_SPATIAL_RELIABILITY")
    }

    private fun checkGl(label: String) {
        val errors = ArrayList<String>()
        while (true) {
            val error = GLES30.glGetError()
            if (error == GLES20.GL_NO_ERROR) break
            errors += "0x${error.toString(16)}"
        }
        requireParity(errors.isEmpty(), "$label GL errors=$errors")
    }

    private fun requireParity(condition: Boolean, reason: String) {
        if (!condition) invalid(reason)
    }

    private fun invalid(reason: String): Nothing =
        throw IllegalStateException("MGC PARITY ARCHITECTURE INVALID: $reason")

    private class EglOwner(
        private val display: EGLDisplay,
        private val context: EGLContext,
        private val surface: EGLSurface,
    ) : AutoCloseable {
        companion object {
            fun create(): EglOwner {
                val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
                requireParity(display != EGL14.EGL_NO_DISPLAY, "eglGetDisplay failed")
                val versions = IntArray(2)
                requireParity(EGL14.eglInitialize(display, versions, 0, versions, 1),
                    "eglInitialize failed error=0x${EGL14.eglGetError().toString(16)}")
                val attrs = intArrayOf(
                    EGL14.EGL_RED_SIZE, 8,
                    EGL14.EGL_GREEN_SIZE, 8,
                    EGL14.EGL_BLUE_SIZE, 8,
                    EGL14.EGL_ALPHA_SIZE, 8,
                    EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                    EGL14.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT_KHR,
                    EGL14.EGL_NONE,
                )
                val configs = arrayOfNulls<EGLConfig>(1)
                val count = IntArray(1)
                requireParity(EGL14.eglChooseConfig(display, attrs, 0, configs, 0, 1, count, 0) &&
                        count[0] > 0 && configs[0] != null,
                    "no GLES3 pbuffer EGLConfig")
                val config = configs[0]!!
                val context = GlesGpuScheduler.createBackgroundContext(display, config, TAG)
                requireParity(context != EGL14.EGL_NO_CONTEXT,
                    "eglCreateContext failed error=0x${EGL14.eglGetError().toString(16)}")
                val surface = EGL14.eglCreatePbufferSurface(
                    display, config,
                    intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
                requireParity(surface != EGL14.EGL_NO_SURFACE,
                    "eglCreatePbufferSurface failed error=0x${EGL14.eglGetError().toString(16)}")
                requireParity(EGL14.eglMakeCurrent(display, surface, surface, context),
                    "eglMakeCurrent failed error=0x${EGL14.eglGetError().toString(16)}")
                PLog.i(TAG, "IRIS_26512_MGC1271_EGL_OWNER " +
                    "version=${GLES30.glGetString(GLES30.GL_VERSION)} " +
                    "renderer=${GLES30.glGetString(GLES30.GL_RENDERER)}")
                return EglOwner(display, context, surface)
            }
        }

        override fun close() {
            runCatching { GLES30.glFinish() }
            runCatching {
                EGL14.eglMakeCurrent(
                    display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            }
            runCatching { EGL14.eglDestroySurface(display, surface) }
            runCatching { EGL14.eglDestroyContext(display, context) }
            runCatching { EGL14.eglTerminate(display) }
        }
    }
}
