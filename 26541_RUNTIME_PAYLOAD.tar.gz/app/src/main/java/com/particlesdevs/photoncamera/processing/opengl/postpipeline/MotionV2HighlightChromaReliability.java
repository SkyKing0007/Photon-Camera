package com.particlesdevs.photoncamera.processing.opengl.postpipeline;

import android.graphics.Point;
import com.particlesdevs.photoncamera.processing.opengl.GLFormat;
import com.particlesdevs.photoncamera.processing.opengl.GLTexture;
import com.particlesdevs.photoncamera.processing.opengl.nodes.Node;
import com.particlesdevs.photoncamera.util.Log;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import static android.opengl.GLES20.GL_CLAMP_TO_EDGE;
import static android.opengl.GLES20.GL_LINEAR;

/**
 * IRIS_26541_HIGHLIGHT_OPPOSED_RECONSTRUCTION
 *
 * Complete the recent RawTherapee-inspired false-color work as a dedicated highlight operation,
 * not a general chroma filter. A non-near-clipped center is returned unchanged. Partially censored
 * highlights may borrow opposed-channel chroma only from reliable, unclipped, same-surface donor
 * pairs. Fully censored highlights may move toward the timestamp-owned Camera2 neutral axis while
 * preserving camera-linear luminance. No RCD/demosaic detour exists.
 */
public final class MotionV2HighlightChromaReliability extends Node {
    public MotionV2HighlightChromaReliability() { super("", "MotionV2HighlightChromaReliability"); }
    @Override public void Compile() {}

    @Override public void Run() {
        if (!(basePipeline.mParameters.motionV2Active || basePipeline.mParameters.irisNightActive))
            throw new IllegalStateException("Highlight reconstruction outside Iris Spatial RGB");
        float[] reliability = basePipeline.mParameters.motionV2SpatialReliability;
        int rw = basePipeline.mParameters.motionV2SpatialReliabilityWidth;
        int rh = basePipeline.mParameters.motionV2SpatialReliabilityHeight;
        if (reliability == null || rw <= 0 || rh <= 0 || reliability.length != rw * rh)
            throw new IllegalStateException("26541 missing native Spatial reliability map");
        float[] neutral = basePipeline.mParameters.whitePoint;
        if (neutral == null || neutral.length < 3
                || !Float.isFinite(neutral[0]) || !Float.isFinite(neutral[1]) || !Float.isFinite(neutral[2])
                || neutral[0] <= 0f || neutral[1] <= 0f || neutral[2] <= 0f)
            throw new IllegalStateException("26541 missing timestamp-owned Camera2 neutral point");

        ByteBuffer rb = ByteBuffer.allocateDirect(reliability.length * 4).order(ByteOrder.nativeOrder());
        for (float v : reliability) rb.putFloat(Float.isFinite(v) ? Math.max(0.0f, Math.min(1.0f, v)) : 0.0f);
        rb.position(0);
        GLTexture reliabilityTex = new GLTexture(new Point(rw, rh),
                new GLFormat(GLFormat.DataType.FLOAT_32, 1), rb, GL_LINEAR, GL_CLAMP_TO_EDGE);
        try {
            glProg.useAssetProgram("motionv2/highlight_chroma_reliability");
            glProg.setTexture("InputBuffer", previousNode.WorkingTexture);
            glProg.setTexture("ReliabilityMap", reliabilityTex);
            glProg.setVar("CameraNeutral", new float[]{neutral[0], neutral[1], neutral[2]});
            WorkingTexture = basePipeline.getMain();
            glProg.drawBlocks(WorkingTexture);
            glProg.closed = true;
            Log.i(Name, "IRIS_26541_HIGHLIGHT_OPPOSED_RECONSTRUCTION"
                    + " lumaLowerBoundPreserved=true centerNearClipRequired=true nonClipActivation=0"
                    + " opposedDonorsUnclipped=true opposedDonorsReliable=true sameSurfacePairs=true edgeGate=true"
                    + " fullCensorNeutral=Camera2_SENSOR_NEUTRAL_COLOR_POINT"
                    + " maxOpposedAmount=0.78 fullCensorNeutralUpTo=1.0"
                    + " nativeSpatialReliability=true rcd=false treeFoliageNonClipProtected=true"
                    + " reliabilityMean=" + basePipeline.mParameters.motionV2SpatialReliabilityMean
                    + " lowReliabilityFraction=" + basePipeline.mParameters.motionV2SpatialReliabilityLowFraction
                    + " stage=beforeProfileColor");
        } finally {
            reliabilityTex.close();
        }
    }
}
