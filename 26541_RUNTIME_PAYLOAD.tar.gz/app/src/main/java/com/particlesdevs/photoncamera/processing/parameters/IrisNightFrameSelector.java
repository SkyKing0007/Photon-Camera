package com.particlesdevs.photoncamera.processing.parameters;

/** IRIS_26541_NIGHT_12_PLUS_3_FRAME_OWNER
 * Dedicated Night is a fixed fresh post-shutter bracket: twelve short/reference-cohort RAWs plus
 * three longer shadow RAWs. It is intentionally independent of the Motion ZSL frame slider/ring.
 */
public final class IrisNightFrameSelector {
    public static final int SHORT_FRAMES = 12;
    public static final int LONG_FRAMES = 3;
    public static final int TOTAL_FRAMES = SHORT_FRAMES + LONG_FRAMES;
    private IrisNightFrameSelector() {}
    public static int getFrames(int requestedMaximum) {
        return TOTAL_FRAMES;
    }
}
